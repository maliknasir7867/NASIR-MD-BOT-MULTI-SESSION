// QR-based session activation (Knight Bot logic)
// Kept intentionally close to the Knight Bot QR flow to preserve behavior.

const fs = require('fs');
const path = require('path');
const pino = require('pino');
const QRCode = require('qrcode');

const {
  makeWASocket,
  useMultiFileAuthState,
  makeCacheableSignalKeyStore,
  Browsers,
  jidNormalizedUser,
  fetchLatestBaileysVersion,
} = require('@whiskeysockets/baileys');

// Function to remove files or directories
function removeFile(FilePath) {
  try {
    if (!fs.existsSync(FilePath)) return false;
    fs.rmSync(FilePath, { recursive: true, force: true });
    return true;
  } catch (e) {
    console.error('Error removing file:', e);
    return false;
  }
}

function ensureDirSync(dirPath) {
  if (!fs.existsSync(dirPath)) fs.mkdirSync(dirPath, { recursive: true });
}

function copyDirRecursive(srcDir, dstDir) {
  ensureDirSync(dstDir);
  for (const entry of fs.readdirSync(srcDir, { withFileTypes: true })) {
    const src = path.join(srcDir, entry.name);
    const dst = path.join(dstDir, entry.name);
    if (entry.isDirectory()) {
      copyDirRecursive(src, dst);
    } else {
      fs.copyFileSync(src, dst);
    }
  }
}

/**
 * Start a temporary QR session, emit QR data URL, then persist creds into sessionDir.
 *
 * opts:
 *  - sessionDir: string (target MultiFileAuthState dir for NASIR-MD Telegram sessions)
 *  - onQRCode: async (qrDataUrl: string) => void
 *  - onConnected: async (jid: string|null) => void
 *  - onError: async (err: any) => void
 */
async function startQrSession(opts = {}) {
  const sessionDir = String(opts.sessionDir || '').trim();
  const onQRCode = typeof opts.onQRCode === 'function' ? opts.onQRCode : null;
  const onConnected = typeof opts.onConnected === 'function' ? opts.onConnected : null;
  const onError = typeof opts.onError === 'function' ? opts.onError : null;

  // Generate unique session for each request to avoid conflicts (Knight Bot)
  const sessionId = Date.now().toString() + Math.random().toString(36).substr(2, 9);
  const dirs = `./qr_sessions/session_${sessionId}`;

  // Ensure qr_sessions directory exists (Knight Bot)
  if (!fs.existsSync('./qr_sessions')) {
    fs.mkdirSync('./qr_sessions', { recursive: true });
  }

  async function initiateSession() {
    // ✅ PERMANENT FIX: Create the session folder before anything (Knight Bot)
    if (!fs.existsSync(dirs)) fs.mkdirSync(dirs, { recursive: true });

    const { state, saveCreds } = await useMultiFileAuthState(dirs);

    try {
      const { version } = await fetchLatestBaileysVersion();

      let qrGenerated = false;
      let responseSent = false;

      // QR Code handling logic (Knight Bot)
      const handleQRCode = async (qr) => {
        if (qrGenerated || responseSent) return;

        qrGenerated = true;
        console.log('🟢 QR Code Generated! Scan it with your WhatsApp app.');
        console.log('📋 Instructions:');
        console.log('1. Open WhatsApp on your phone');
        console.log('2. Go to Settings > Linked Devices');
        console.log('3. Tap "Link a Device"');
        console.log('4. Scan the QR code below');

        try {
          // Generate QR code as data URL (Knight Bot)
          const qrDataURL = await QRCode.toDataURL(qr, {
            errorCorrectionLevel: 'M',
            type: 'image/png',
            quality: 0.92,
            margin: 1,
            color: {
              dark: '#000000',
              light: '#FFFFFF'
            }
          });

          if (!responseSent) {
            responseSent = true;
            console.log('QR Code generated successfully');
            if (onQRCode) {
              await onQRCode(qrDataURL);
            }
          }
        } catch (qrError) {
          console.error('Error generating QR code:', qrError);
          if (!responseSent) {
            responseSent = true;
            if (onError) await onError(qrError);
          }
        }
      };

      // Improved Baileys socket configuration (Knight Bot)
      const socketConfig = {
        version,
        logger: pino({ level: 'silent' }),
        browser: (Browsers && typeof Browsers.windows === 'function') ? Browsers.windows('Chrome') : ['Ubuntu', 'Chrome', '20.0.04'],
        auth: {
          creds: state.creds,
          keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'fatal' }).child({ level: 'fatal' })),
        },
        markOnlineOnConnect: false,
        generateHighQualityLinkPreview: false,
        defaultQueryTimeoutMs: 60000,
        connectTimeoutMs: 60000,
        keepAliveIntervalMs: 30000,
        retryRequestDelayMs: 250,
        maxRetries: 5,
      };

      // Create socket and bind events (Knight Bot)
      let sock = makeWASocket(socketConfig);
      let reconnectAttempts = 0;
      const maxReconnectAttempts = 3;

      // Connection event handler function (Knight Bot)
      const handleConnectionUpdate = async (update) => {
        const { connection, lastDisconnect, qr } = update;
        console.log(`🔄 Connection update: ${connection || 'undefined'}`);

        if (qr && !qrGenerated) {
          await handleQRCode(qr);
        }

        if (connection === 'open') {
          console.log('✅ Connected successfully!');
          console.log('💾 Session saved to:', dirs);
          reconnectAttempts = 0;

          try {
            // Persist session into requested NASIR-MD sessionDir (activation)
            if (sessionDir) {
              ensureDirSync(sessionDir);
              copyDirRecursive(dirs, sessionDir);
            }

            // Get the user's JID from the session (Knight Bot)
            const userJid = Object.keys(sock.authState.creds.me || {}).length > 0
              ? jidNormalizedUser(sock.authState.creds.me.id)
              : null;

            if (onConnected) {
              await onConnected(userJid);
            }
          } catch (error) {
            console.error('Error persisting QR session:', error);
            if (onError) await onError(error);
          }

          // Clean up session after successful connection (Knight Bot)
          setTimeout(() => {
            console.log('🧹 Cleaning up session...');
            const deleted = removeFile(dirs);
            if (deleted) {
              console.log('✅ Session cleaned up successfully');
            } else {
              console.log('❌ Failed to clean up session folder');
            }
            try { sock?.ws?.close?.(); } catch (_) {}
            try { sock?.end?.(); } catch (_) {}
          }, 15000);
        }

        if (connection === 'close') {
          console.log('❌ Connection closed');
          if (lastDisconnect?.error) {
            console.log('❗ Last Disconnect Error:', lastDisconnect.error);
          }

          const statusCode = lastDisconnect?.error?.output?.statusCode;

          // Handle specific error codes (Knight Bot)
          if (statusCode === 401) {
            console.log('🔐 Logged out - need new QR code');
            removeFile(dirs);
          } else if (statusCode === 515 || statusCode === 503) {
            console.log(`🔄 Stream error (${statusCode}) - attempting to reconnect...`);
            reconnectAttempts++;

            if (reconnectAttempts <= maxReconnectAttempts) {
              console.log(`🔄 Reconnect attempt ${reconnectAttempts}/${maxReconnectAttempts}`);
              // Wait a bit before reconnecting (Knight Bot)
              setTimeout(() => {
                try {
                  sock = makeWASocket(socketConfig);
                  sock.ev.on('connection.update', handleConnectionUpdate);
                  sock.ev.on('creds.update', saveCreds);
                } catch (err) {
                  console.error('Failed to reconnect:', err);
                }
              }, 2000);
            } else {
              console.log('❌ Max reconnect attempts reached');
              if (!responseSent) {
                responseSent = true;
                if (onError) await onError(new Error('Connection failed after multiple attempts'));
              }
            }
          } else {
            console.log('🔄 Connection lost - attempting to reconnect...');
            // Let it reconnect automatically
          }
        }
      };

      // Bind the event handler (Knight Bot)
      sock.ev.on('connection.update', handleConnectionUpdate);
      sock.ev.on('creds.update', saveCreds);

      // Set a timeout to clean up if no QR is generated (Knight Bot)
      setTimeout(() => {
        if (!responseSent) {
          responseSent = true;
          if (onError) onError(new Error('QR generation timeout'));
          removeFile(dirs);
        }
      }, 30000);
    } catch (err) {
      console.error('Error initializing session:', err);
      if (onError) await onError(err);
      removeFile(dirs);
    }
  }

  await initiateSession();
}

module.exports = {
  startQrSession,
};
