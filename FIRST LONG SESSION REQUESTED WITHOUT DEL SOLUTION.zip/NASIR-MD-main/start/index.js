/**
 * NASIR-MD — Telegram → WhatsApp Multi‑Session Wrapper
 *
 * Provides:
 *  - startSession(sessionKey, opts)
 *  - getSessions()
 *
 * Each session uses its own MultiFileAuthState directory (sessionDir) so multiple
 * WhatsApp accounts can run in parallel (multi-session handler).
 */

require('../setting/config');

const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  jidDecode,
  jidNormalizedUser,
  makeCacheableSignalKeyStore,
  delay,
} = require('@whiskeysockets/baileys');

const pino = require('pino');
const NodeCache = require('node-cache');

// Reuse NASIR-MD handlers
const { handleMessages, handleGroupParticipantUpdate, handleStatus } = require('../main');
// Anticall
const { handleIncomingCall } = require('../commands/anticall');

// Reuse NASIR-MD lightweight store (singleton)
const store = require('../lib/lightweight_store');
const settings = require('../settings');
const { sendMessageAsChannelForward } = require('../lib/reactions');
const { runWithSession } = require('../lib/sessionContext');
const sessionState = require('../lib/sessionState');

// Keep a per-session keepalive timer
const sessionTimeouts = new Map();
const connectWatchdogs = new Map();
// Keep a per-session restart counter (simple backoff)
const sessionRestartAttempts = new Map();
// Prevent concurrent starts for same session key (avoids double sockets + auth corruption)
const sessionStartLocks = new Map();
// Small heartbeat intervals to keep process alive and detect hung sessions
const sessionHeartbeats = new Map();
// Track last activity per session to recover from "open but dead" sockets
const sessionLastActivity = new Map();

// Multi-session registry (exported via getSessions)
const sessions = new Map();

// Prevent concurrent restarts for the same session label/key
const restartLocks = new Map();

/**
 * Best-effort cleanup for a Baileys socket.
 * Important for panel restarts / connectionLost loops to avoid "zombie" sockets
 * that stay in memory and stop responding to commands.
 */
async function cleanupSocket(sock, label = 'session') {
  if (!sock) return;
  try {
    // Stop any keepalive timers owned by this session label
    if (sessionTimeouts.has(label)) {
      clearTimeout(sessionTimeouts.get(label));
      sessionTimeouts.delete(label);
    }
    if (connectWatchdogs.has(label)) {
      clearTimeout(connectWatchdogs.get(label));
      connectWatchdogs.delete(label);
    }
  } catch (_) {}
  try {
    if (sessionHeartbeats.has(label)) {
      clearInterval(sessionHeartbeats.get(label));
      sessionHeartbeats.delete(label);
    }
  } catch (_) {}

  try { sock.__isCleaningUp = true; } catch (_) {}

  // Remove listeners first (avoid duplicated handlers after restart)
  try { sock?.ev?.removeAllListeners?.(); } catch (_) {}

  // Close websocket if present
  try { sock?.ws?.close?.(); } catch (_) {}

  // End baileys socket
  try { sock?.end?.(); } catch (_) {}

  // Mark as closed
  try { sock.__closed = true; } catch (_) {}
}

function isSocketUsable(sock) {
  if (!sock) return false;
  if (sock.__closed || sock.__isCleaningUp) return false;
  // Baileys keeps ws in sock.ws; OPEN === 1
  const wsState = sock?.ws?.readyState;
  if (typeof wsState === 'number' && wsState !== 1) return false;
  return true;
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

/**
 * Start a single Baileys session.
 *
 * @param {object} opts
 * @param {string} opts.sessionDir
 * @param {string} [opts.phoneNumber]
 * @param {(code: string) => (void|Promise<void>)} [opts.onPairCode]
 * @param {(jid: string) => (void|Promise<void>)} [opts.onConnected]
 * @param {string} [opts.label]
 */
async function createSocket(opts = {}) {
  const sessionDir = opts.sessionDir || './session';
  const phoneFromArgs = opts.phoneNumber ? String(opts.phoneNumber).trim() : '';
  const onPairCode = typeof opts.onPairCode === 'function' ? opts.onPairCode : null;
  const onConnected = typeof opts.onConnected === 'function' ? opts.onConnected : null;
  const label = opts.label ? String(opts.label) : sessionDir;
  const sessionKey = opts.sessionKey ? String(opts.sessionKey) : null;

  // Clear keepalive timer for this label
  if (sessionTimeouts.has(label)) {
    clearTimeout(sessionTimeouts.get(label));
    sessionTimeouts.delete(label);
  }

  const { version } = await fetchLatestBaileysVersion();
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
  const msgRetryCounterCache = new NodeCache();

  const safeSaveCreds = async () => {
    try { await saveCreds(); } catch (e) {
      try { console.error(`[${label}] saveCreds error:`, e?.message || e); } catch (_) {}
    }
  };

  const sock = makeWASocket({
    version,
    logger: pino({ level: 'silent' }),
    printQRInTerminal: false, // Telegram flow uses pairing code
    browser: ['Ubuntu', 'Chrome', '20.0.04'],
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'fatal' }).child({ level: 'fatal' })),
    },
    markOnlineOnConnect: true,
    generateHighQualityLinkPreview: true,
    syncFullHistory: false,
    getMessage: async (key) => {
      try {
        const jid = jidNormalizedUser(key.remoteJid);
        const msg = await store.loadMessage(jid, key.id);
        return msg?.message || '';
      } catch {
        return '';
      }
    },
    msgRetryCounterCache,
    defaultQueryTimeoutMs: 60000,
    connectTimeoutMs: 60000,
    keepAliveIntervalMs: 10000,
  });

  // Activity tracking: helps recover when sessions look "active" in Linked Devices
  // but stop responding to commands after long uptime or a panel freeze.
  const touch = () => {
    try { sessionLastActivity.set(label, Date.now()); } catch (_) {}
  };
  touch();

  // Low-level WS event handling (prevents open-but-dead sockets)
  try {
    const ws = sock?.ws;
    if (ws && !ws.__nasirBound) {
      ws.__nasirBound = true;
      ws.on?.('pong', () => { touch(); });
      ws.on?.('close', () => {
        try { sock.__closed = true; } catch (_) {}
      });
      ws.on?.('error', () => { touch(); });
    }
  } catch (_) {}

  sock.__sessionId = String(label || 'default');
  if (sessionKey) sock.__sessionKey = sessionKey;
  sessionState.ensureSessionSkeleton(sock.__sessionId);
  try { sessionState.ensureOwnerFromSock(sock, sock.__sessionId); } catch (_) {}


  sock.sessionLabel = label;
  sock.sessionDir = sessionDir;

  // bind store + creds
  sock.ev.on('creds.update', safeSaveCreds);
  store.bind(sock.ev);
  // Any creds update means the socket is alive
  try { sock.ev.on('creds.update', () => touch()); } catch (_) {}

  // "Bot Connected Successfully" message controls
  let sawQr = false;
  let connectedMsgSent = false;
  let pendingQrFirstMessageSend = false;

  const formatPkTime = () => {
    const now = new Date();
    const date = new Intl.DateTimeFormat('en-GB', {
      timeZone: 'Asia/Karachi',
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    }).format(now);
    const time = new Intl.DateTimeFormat('en-US', {
      timeZone: 'Asia/Karachi',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    }).format(now);
    return `${date} | ${time} (PKT)`;
  };

  const buildConnectedText = () => {
    return `🤖 *BOT CONNECTED SUCCESSFULLY!*\n\n` +
       `━━━━━━━━━━━━━━━━━━\n` +
       `🕒 *Time:* ${formatPkTime()}\n` +
       `🟢 *Status:* Online & Ready\n` +
       `━━━━━━━━━━━━━━━━━━\n\n` +
       `✅ Your WhatsApp bot is now active\n` +
       `🚀 All systems running smoothly\n\n` +
       `📢 *Important*\n` +
       `Make sure to join the official channel below to receive updates, fixes & new features`
        }

  const sendConnectedMessageToSelf = async () => {
    if (connectedMsgSent) return;
    connectedMsgSent = true;
    try {
      const selfJid = String(sock.user?.id || '').split(':')[0] + '@s.whatsapp.net';
      if (!selfJid || selfJid === '@s.whatsapp.net') return;
      await sendMessageAsChannelForward(sock, selfJid, { text: buildConnectedText() });
    } catch (err) {
      console.error(`[${label}] Connected message send error:`, err?.message || err);
    }
  };

  // helper: decodeJid (same as NASIR-MD)
  sock.decodeJid = (jid) => {
    if (!jid) return jid;
    if (/:\d+@/gi.test(jid)) {
      const decode = jidDecode(jid) || {};
      return (decode.user && decode.server && decode.user + '@' + decode.server) || jid;
    }
    return jid;
  };

  // Message handling
  sock.ev.on('messages.upsert', async (chatUpdate) => {
    try {
      touch();
      const mek = chatUpdate.messages?.[0];
      if (!mek?.message) return;
      mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage')
        ? mek.message.ephemeralMessage.message
        : mek.message;

      if (mek.key?.remoteJid === 'status@broadcast') {
        await runWithSession(sock.__sessionId, sock, async () => {
          sessionState.ensureOwnerFromSock(sock, sock.__sessionId);
          await handleStatus(sock, chatUpdate);
        });
        return;
      }

      // If this session was authenticated via QR, send the connected message
      // on the first incoming message after connection.
      if (pendingQrFirstMessageSend && mek?.key && !mek.key.fromMe) {
        pendingQrFirstMessageSend = false;
        await sendConnectedMessageToSelf();
      }

      try {
        await runWithSession(sock.__sessionId, sock, async () => {
          sessionState.ensureOwnerFromSock(sock, sock.__sessionId);
          await handleMessages(sock, chatUpdate, true);
        });
      } catch (err) {
        console.error(`[${label}] handleMessages error:`, err);
      }
    } catch (err) {
      console.error(`[${label}] messages.upsert error:`, err);
    }
  });

  // Group participant updates
  sock.ev.on('group-participants.update', async (update) => {
    try {
      touch();
      await runWithSession(sock.__sessionId, sock, async () => {
        sessionState.ensureOwnerFromSock(sock, sock.__sessionId);
        await handleGroupParticipantUpdate(sock, update);
      });
    } catch (err) {
      console.error(`[${label}] group update error:`, err);
    }
  });

  // Status updates / reactions
  sock.ev.on('status.update', async (status) => {
    try { touch(); await handleStatus(sock, status); } catch (_) {}
  });
  sock.ev.on('messages.reaction', async (status) => {
    try { touch(); await handleStatus(sock, status); } catch (_) {}
  });

  // Calls (anticall)
  sock.ev.on('call', async (calls) => {
    try {
      touch();
      await runWithSession(sock.__sessionId, sock, async () => {
        sessionState.ensureOwnerFromSock(sock, sock.__sessionId);
        await handleIncomingCall(sock, calls); // supports array OR single
      });
    } catch (err) {
      console.error(`[${label}] ANTICALL ERROR:`, err);
    }
  });

  // keep-alive: presence ping
  const keepAlive = async () => {
    if (!sock?.user) return;
    try {
      try { const ws = sock?.ws; if (typeof ws?.ping === 'function') ws.ping(); } catch (_) {}

      await sock.sendPresenceUpdate('available');
      await sock.sendPresenceUpdate('online');
    } catch (_) {}
    sessionTimeouts.set(label, setTimeout(keepAlive, 60000));
  };

  let pairingRequested = false;

  const autoRestart = async (why, baseDelayMs = 3000) => {
    // Prevent multiple overlapping restarts for the same session
    if (restartLocks.get(label)) {
      console.log(`[${label}] Restart already in progress, skipping (${why})`);
      return;
    }
    restartLocks.set(label, true);

    const attempts = (sessionRestartAttempts.get(label) || 0) + 1;
    sessionRestartAttempts.set(label, attempts);
    const wait = Math.min(baseDelayMs * attempts, 30000);
    console.log(`[${label}] Auto-restart (${why}) in ${wait}ms (attempt ${attempts})`);
    await sleep(wait);
    try {
      // Restart by reconnecting same session directory
      const key = sock.__sessionKey || [...sessions.entries()].find(([, s]) => s === sock)?.[0];
      if (key) {
        sessions.delete(key);
        await cleanupSocket(sock, label);
        await startSession(key, { sessionDir, phoneNumber: phoneFromArgs, label, onPairCode, onConnected });
      } else {
        await cleanupSocket(sock, label);
      }
    } catch (e) {
      console.error(`[${label}] Restart failed:`, e);
    } finally {
      restartLocks.set(label, false);
    }
  };

  // Connection handling + pairing code
  sock.ev.on('connection.update', async (u) => {
    touch();
    const { connection, lastDisconnect, qr } = u;
    const statusCode = lastDisconnect?.error?.output?.statusCode;

    if (qr) {
      sawQr = true;
    }

    if (connection === 'connecting') {
      // If we get stuck in connecting (common after panel stop), force restart.
      if (!connectWatchdogs.has(label)) {
        const t = setTimeout(() => {
          try {
            const wsState = sock?.ws?.readyState;
            const isOpen = (typeof wsState === 'number' ? wsState === 1 : !!sock?.user);
            if (!isOpen && sock?.authState?.creds?.registered) {
              autoRestart('connectTimeout', 1000);
            }
          } catch (_) {}
        }, 60000);
        connectWatchdogs.set(label, t);
      }

      // Request pairing code while connecting (more reliable)
      if (!sock.authState.creds.registered && phoneFromArgs && !pairingRequested) {
        pairingRequested = true;

        (async () => {
          await sleep(2000);
          const phone = String(phoneFromArgs).replace(/[^0-9]/g, '');
          const custom = (global.setPair ? String(global.setPair).trim() : '') || undefined;

          const maxTries = 4;
          for (let i = 1; i <= maxTries; i++) {
            try {
              let code = custom
                ? await sock.requestPairingCode(phone, custom)
                : await sock.requestPairingCode(phone);
              if (code?.match) code = code.match(/.{1,4}/g)?.join('-') || code;
              console.log(`[${label}] Pairing Code: ${code}`);
              if (onPairCode) {
                try { await onPairCode(code); } catch (_) {}
              }
              return;
            } catch (err) {
              const msg = err?.message || String(err);
              console.log(`[${label}] Pair try ${i}/${maxTries} failed: ${msg}`);
              await sleep(2500);
            }
          }
        })();
      }
    }

    if (connection === 'open') {
      const attemptsBeforeReset = sessionRestartAttempts.get(label) || 0;
      sessionRestartAttempts.set(label, 0);
      // Clear any connect watchdog for this label
      if (connectWatchdogs.has(label)) {
        clearTimeout(connectWatchdogs.get(label));
        connectWatchdogs.delete(label);
      }
      console.log(`session_connected [${label}] Connected as ${sock.user?.id}`);
      if (attemptsBeforeReset > 0) {
        console.log(`session_reconnected [${label}] Reconnected (after ${attemptsBeforeReset} restart attempt(s))`);
      }
      keepAlive();
      // Heartbeat: keep panel alive + detect frozen sockets
      if (!sessionHeartbeats.has(label)) {
        const hb = setInterval(async () => {
          try {
            const wsState = sock?.ws?.readyState;
            const isOpen = (typeof wsState === 'number' ? wsState === 1 : !!sock?.user);
            if (!isOpen && sock?.authState?.creds?.registered) {
              autoRestart('heartbeatDisconnected', 1000);
              return;
            }
            // If the session looks "open" but we haven't seen any activity for a while,
            // do a stronger ping and restart if it fails. This fixes the common
            // "Linked device shows online but bot stops responding" state.
            const lastAt = sessionLastActivity.get(label) || Date.now();
            const age = Date.now() - lastAt;
            if (age > 12 * 60 * 1000 && sock?.authState?.creds?.registered) {
              try {
                // stronger ping: presence + onWhatsApp query
                try { const ws = sock?.ws; if (typeof ws?.ping === 'function') ws.ping(); } catch (_) {}

                await sock.sendPresenceUpdate('available');
                const self = String(sock.user?.id || '').split(':')[0];
                if (self) {
                  await sock.onWhatsApp(self);
                }
                touch();
              } catch (_) {
                autoRestart('heartbeatStale', 1000);
                return;
              }
            } else {
              // tiny no-op ping
              await sock.sendPresenceUpdate('available');
              touch();
            }
          } catch (_) {}
        }, 5 * 60 * 1000);
        sessionHeartbeats.set(label, hb);
      }

      // Requirements:
      // - Pairing code sessions: send immediately after connection
      // - QR sessions: send on first incoming message
      if (phoneFromArgs) {
        await sendConnectedMessageToSelf();
      } else if (sawQr) {
        pendingQrFirstMessageSend = true;
      } else {
        // Fallback: if we didn't detect QR, still send immediately
        await sendConnectedMessageToSelf();
      }

      if (onConnected) {
        try { await onConnected(sock.user?.id); } catch (_) {}
      }
    }

    if (connection === 'close') {
      console.log(`session_disconnected [${label}] Disconnected (code: ${statusCode})`);
      // Allow the connection message to be sent again on reconnect.
      connectedMsgSent = false;
      try { sock.__closed = true; } catch (_) {}
      // stop keepalive
      if (sessionTimeouts.has(label)) {
        clearTimeout(sessionTimeouts.get(label));
        sessionTimeouts.delete(label);
      }

      const shouldReconnect = statusCode !== DisconnectReason.loggedOut && statusCode !== 401;

      if (!shouldReconnect) {
        console.log(`[${label}] Logged out / unauthorized. Re-pair required.`);
        return;
      }

      switch (statusCode) {
        case DisconnectReason.connectionClosed:
          return autoRestart('connectionClosed', 2000);
        case DisconnectReason.connectionLost:
          return autoRestart('connectionLost', 3000);
        case DisconnectReason.restartRequired:
          return autoRestart('restartRequired', 1000);
        case DisconnectReason.timedOut:
          return autoRestart('timedOut', 3000);
        default:
          return autoRestart(`close_${statusCode}`, 3000);
      }
    }
  });

  // Persist store periodically (same as original NASIR-MD)
  if (!createSocket._storeIntervalStarted) {
    createSocket._storeIntervalStarted = true;
    try { store.readFromFile(); } catch (_) {}
    setInterval(() => {
      try { store.writeToFile(); } catch (_) {}
    }, settings.storeWriteInterval || 10000);
  }

  // small delay to let socket init
  await delay(1000);

  return sock;
}

/**
 * Start or reuse a session by key.
 *
 * @param {string} sessionKey
 * @param {object} opts
 */
async function startSession(sessionKey, opts = {}) {
  const key = String(sessionKey);

  // Serialize concurrent starts for the same key to avoid double sockets + auth corruption
  if (sessionStartLocks.has(key)) {
    return await sessionStartLocks.get(key);
  }

  const p = (async () => {
    if (sessions.has(key)) {
      const existing = sessions.get(key);
      // If we have a stale/broken socket (common after panel stop), recreate it.
      if (isSocketUsable(existing)) return existing;
      try { await cleanupSocket(existing, existing?.sessionLabel || opts.label || key); } catch (_) {}
      sessions.delete(key);
    }

    const sock = await createSocket({ ...opts, label: opts.label || key, sessionKey: key });
    sessions.set(key, sock);
    return sock;
  })();

  sessionStartLocks.set(key, p);
  try {
    return await p;
  } finally {
    sessionStartLocks.delete(key);
  }
}


function getSessions() {
  return sessions;
}

module.exports = {
  startSession,
  getSessions,
};
