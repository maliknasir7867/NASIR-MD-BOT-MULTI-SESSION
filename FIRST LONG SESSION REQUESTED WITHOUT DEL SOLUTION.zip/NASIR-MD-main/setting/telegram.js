/**
 * Telegram controller config (multi-user session manager)
 *
 * ✅ Recommended: set TELEGRAM_BOT_TOKEN as an environment variable on your panel/host.
 *
 * Example:
 *   TELEGRAM_BOT_TOKEN=123456:ABC-DEF...
 */

module.exports = {
  BOT_TOKEN: process.env.TELEGRAM_BOT_TOKEN || "8307673323:AAFXR0Jfola6jU-ICGZ_tJbDPoGm-UY60sA",

  // Telegram numeric user IDs who can approve/deny users
  ADMIN_TELEGRAM_IDS: [
    // Put your Telegram user ID(s) here
    6505057749
  ],

  // Base folder for per-user WhatsApp auth state
  SESSIONS_BASE_DIR: "sessions",
};
