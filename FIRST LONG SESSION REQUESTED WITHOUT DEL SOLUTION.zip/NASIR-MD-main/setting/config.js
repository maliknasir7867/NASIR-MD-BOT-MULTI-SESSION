require('../lib/session_bootstrap');
const fs = require('fs');

// Custom pairing code used by the Telegram multi-session controller
// (Baileys supports passing a custom pairing code string)
global.setPair = "NASIR777";

// Hot-reload on file changes (optional)
let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
  delete require.cache[file];
  require(file);
});
