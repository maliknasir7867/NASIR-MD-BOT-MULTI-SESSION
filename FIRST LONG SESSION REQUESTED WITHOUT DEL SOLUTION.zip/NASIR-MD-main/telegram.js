/*
 * Telegram → WhatsApp multi-session controller (multi-bot per Telegram user)
 * ULTRA MODERN UI VERSION - COMPLETE (STYLE 8 — WhatsApp Pro Panel)
 */

const fs = require("fs");
const path = require("path");
const TelegramBot = require("node-telegram-bot-api");
const moment = require("moment-timezone"); // Pakistani time

require("./setting/config");
const tgCfg = require("./setting/telegram");
const getStart = () => require("./start/index");
const { startQrSession } = require("./start/qrSession");

const ALLOWED_DB_PATH = path.join(__dirname, "setting", "telegram.allowed.json");

// ===== ULTRA MODERN UI CONFIG =====
const ADMIN_USERNAME = "Trustedhacker78";
const ADMIN_URL = `https://t.me/${ADMIN_USERNAME}`;

// ===== TELEGRAM SAFETY (PREVENT PANEL OFF) =====
const TG_TEXT_LIMIT = 3900; // keep margin under 4096

process.on("unhandledRejection", (err) => {
  console.error("[UNHANDLED_REJECTION]", err?.message || err);
});
process.on("uncaughtException", (err) => {
  console.error("[UNCAUGHT_EXCEPTION]", err?.message || err);
});

// MarkdownV2 escape
function escapeMdV2(text = "") {
  return String(text).replace(/[_*[\]()~`>#+\-=|{}.!\\]/g, "\\$&");
}

// ✅ HTML escape (for parse_mode: "HTML")
function escapeHtml(str = "") {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// Unicode Bold Font (WhatsApp-like bold style, NOT *markdown*)
function toBoldFont(text = "") {
  const map = {
    A:"𝗔",B:"𝗕",C:"𝗖",D:"𝗗",E:"𝗘",F:"𝗙",G:"𝗚",H:"𝗛",I:"𝗜",J:"𝗝",
    K:"𝗞",L:"𝗟",M:"𝗠",N:"𝗡",O:"𝗢",P:"𝗣",Q:"𝗤",R:"𝗥",S:"𝗦",T:"𝗧",
    U:"𝗨",V:"𝗩",W:"𝗪",X:"𝗫",Y:"𝗬",Z:"𝗭",
    a:"𝗮",b:"𝗯",c:"𝗰",d:"𝗱",e:"𝗲",f:"𝗳",g:"𝗴",h:"𝗵",i:"𝗶",j:"𝗷",
    k:"𝗸",l:"𝗹",m:"𝗺",n:"𝗻",o:"𝗼",p:"𝗽",q:"𝗾",r:"𝗿",s:"𝘀",t:"𝘁",
    u:"𝘂",v:"𝘃",w:"𝘄",x:"𝘅",y:"𝘆",z:"𝗺",
    0:"𝟬",1:"𝟭",2:"𝟮",3:"𝟯",4:"𝟰",5:"𝟱",6:"𝟲",7:"𝟳",8:"𝟴",9:"𝟵"
  };
  return String(text).split("").map(c => map[c] || c).join("");
}

// ===== FIX #2: LONG TITLE WRAP (KEEP HEADER CLEAN) =====
function shortenTitle(t, max = 18) {
  const s = String(t || "");
  return s.length > max ? s.slice(0, max - 1) + "…" : s;
}

/**
 * STYLE 8 — WhatsApp Pro Panel (Telegram MarkdownV2 Safe)
 */
function buildProPanel({ emoji = "🤖", title = "NASIR-MD BOT", subtitle = "", lines = [], showTimestamp = true }) {
  const fullTitle = String(title || "");
  const shortTitle = shortenTitle(fullTitle, 18);

  // bold short title for header (prevents ugly wrapping)
  const boldTitle = toBoldFont(shortTitle);
  const safeTitle = escapeMdV2(boldTitle);

  // if title shortened and subtitle not provided -> put full title in subtitle
  const finalSubtitle = subtitle ? subtitle : (shortTitle !== fullTitle ? fullTitle : "");
  const safeSub = finalSubtitle ? escapeMdV2(finalSubtitle) : "";

  const header = `╭━〔 ${emoji} ${safeTitle} 〕━╮`;
  const subBlock = safeSub ? `\n┃ ${safeSub}\n┃` : `\n┃`;

  const body = Array.isArray(lines) && lines.length
    ? lines
        .filter(x => x !== undefined && x !== null && String(x).length)
        .map(l => `┃ ${escapeMdV2(l)}`)
        .join("\n")
    : "";

  const timeBlock = showTimestamp
    ? `\n┃\n┃ 🕐 ${escapeMdV2(moment().tz("Asia/Karachi").format("HH:mm:ss"))}`
    : "";

  const footer = `\n╰━━━━━━━━━━━━━━━━━━━━━━╯`;

  return (header + subBlock + (body ? `\n${body}` : "") + timeBlock + footer).trim();
}

function safeTrimToLimit(text, limit = TG_TEXT_LIMIT) {
  const s = String(text || "");
  if (s.length <= limit) return s;
  return s.slice(0, limit - 20).trimEnd() + "…";
}

function buildProPanelSafe(opts) {
  return safeTrimToLimit(buildProPanel(opts), TG_TEXT_LIMIT);
}

// ===== UI SEND / EDIT (SINGLE MESSAGE UI) =====
async function sendUi(bot, chatId, title, lines = [], options = {}) {
  const { emoji = "🤖", subtitle = "", showTimestamp = true, button = null } = options;

  const message = buildProPanelSafe({ emoji, title, subtitle, lines, showTimestamp });

  const extra = {
    parse_mode: "MarkdownV2",
    ...(button ? { reply_markup: button } : {})
  };

  return bot.sendMessage(chatId, message, extra);
}

// Safe edit: never crash the bot if Telegram rejects editMessageText
async function safeEditMessageText(bot, chatId, messageId, text, extra = {}) {
  const safeText = safeTrimToLimit(text, TG_TEXT_LIMIT);

  try {
    return await bot.editMessageText(safeText, {
      chat_id: chatId,
      message_id: messageId,
      ...extra
    });
  } catch (e) {
    const msg = String(e?.message || e);

    // common non-fatal Telegram errors
    if (
      msg.includes("message is not modified") ||
      msg.includes("MESSAGE_NOT_MODIFIED") ||
      msg.includes("message to edit not found") ||
      msg.includes("query is too old")
    ) {
      // try to only update keyboard (optional)
      try {
        if (extra?.reply_markup) {
          await bot.editMessageReplyMarkup(extra.reply_markup, { chat_id: chatId, message_id: messageId });
        }
      } catch (_) {}
      return null;
    }

    console.error("[UI] editMessageText failed:", msg);
    return null; // IMPORTANT: don't throw, don't crash
  }
}

async function editUi(bot, chatId, messageId, title, lines = [], options = {}) {
  const { emoji = "🤖", subtitle = "", showTimestamp = true, button = null } = options;

  const message = buildProPanelSafe({ emoji, title, subtitle, lines, showTimestamp });

  return safeEditMessageText(bot, chatId, messageId, message, {
    parse_mode: "MarkdownV2",
    ...(button ? { reply_markup: button } : {})
  });
}

// ===== Stylish notification sender (STYLE 8 — WhatsApp Pro Panel) =====
async function sendNotification(bot, chatId, type, message, options = {}) {
  const icons = {
    success: "✅",
    error: "❌",
    warning: "⚠️",
    info: "ℹ️",
    loading: "⏳",
    done: "🎯",
    lock: "🔒",
    unlock: "🔓",
    trash: "🗑️",
    rocket: "🚀",
    shield: "🛡️",
    key: "🔑",
    link: "🔗",
    user: "👤",
    bot: "🤖",
    phone: "📱",
    folder: "📁",
    list: "📋",
    restart: "🔄",
    check: "✔️"
  };

  const { title, subtitle = "", button = null, autoDelete = false } = options;
  const icon = icons[type] || icons.info;
  const actualTitle =
    title ||
    (type === "success" ? "Success" :
    type === "error" ? "Error" :
    type === "warning" ? "Notice" : "Notification");

  const lines = Array.isArray(message) ? message : [message];

  const msg = await sendUi(bot, chatId, actualTitle, lines, {
    emoji: icon,
    subtitle,
    showTimestamp: true,
    button
  });

  if (autoDelete && msg?.message_id) {
    setTimeout(() => {
      bot.deleteMessage(chatId, msg.message_id).catch(() => {});
    }, 5000);
  }

  return msg;
}

// ===== UI STATE (STORE LAST PANEL MESSAGE PER CHAT) =====
const uiState = new Map(); // chatId -> { panelMessageId }

function setPanel(chatId, messageId) {
  uiState.set(chatId, { ...(uiState.get(chatId) || {}), panelMessageId: messageId });
}
function getPanelId(chatId) {
  return uiState.get(chatId)?.panelMessageId || null;
}

/* ============================
   FIX #1 + FIX #2 (NEW STATE)
   ============================ */

// Real connection state cache per sessionKey (prevents false OFFLINE)
const sessionConnState = new Map(); // sessionKey -> { connection, isOnline, isPaired, me, updatedAt }

// Track handlers so we can detach cleanly
const sessionConnHandlers = new Map(); // sessionKey -> fn(update)

// Pair gating: only allow pair codes when /pair explicitly requested
const explicitPairRequestUntil = new Map(); // sessionKey -> timestamp(ms) until allowed
const suppressPairUntil = new Map(); // sessionKey -> timestamp(ms) until suppressed (e.g., after /del)

function nowMs() { return Date.now(); }

function markExplicitPairRequest(sessionKey, ttlMs = 2 * 60 * 1000) {
  explicitPairRequestUntil.set(sessionKey, nowMs() + ttlMs);
}

function isExplicitPairAllowed(sessionKey) {
  const t = explicitPairRequestUntil.get(sessionKey) || 0;
  return nowMs() <= t;
}

function suppressPair(sessionKey, ttlMs = 2 * 60 * 1000) {
  suppressPairUntil.set(sessionKey, nowMs() + ttlMs);
}

function isPairSuppressed(sessionKey) {
  const t = suppressPairUntil.get(sessionKey) || 0;
  return nowMs() <= t;
}

function updateSessionConnState(sessionKey, sock, patch = {}) {
  const prev = sessionConnState.get(sessionKey) || {};
  const me =
    patch.me !== undefined ? patch.me :
    sock?.user?.id ||
    sock?.authState?.creds?.me?.id ||
    sock?.authState?.creds?.me?.jid ||
    prev.me ||
    "";

  const isPaired =
    patch.isPaired !== undefined ? patch.isPaired :
    !!sock?.authState?.creds?.registered ||
    !!prev.isPaired;

  const connection =
    patch.connection !== undefined ? patch.connection :
    prev.connection || "close";

  const isOnline =
    patch.isOnline !== undefined ? patch.isOnline :
    connection === "open";

  sessionConnState.set(sessionKey, {
    ...prev,
    connection,
    isOnline,
    isPaired,
    me,
    updatedAt: nowMs()
  });
}

function attachConnectionTracker(sessionKey, sock) {
  if (!sock || !sock.ev || typeof sock.ev.on !== "function") return;

  // Detach old handler if exists
  if (sessionConnHandlers.has(sessionKey)) {
    try {
      sock.ev.off("connection.update", sessionConnHandlers.get(sessionKey));
    } catch (_) {}
    sessionConnHandlers.delete(sessionKey);
  }

  // Initialize state immediately (best-effort)
  updateSessionConnState(sessionKey, sock, {
    isPaired: !!sock?.authState?.creds?.registered
  });

  const handler = (u) => {
    // Baileys emits: { connection: 'open'|'close'|'connecting' ... }
    const conn = u?.connection;

    if (conn === "open") {
      updateSessionConnState(sessionKey, sock, { connection: "open", isOnline: true });
      return;
    }

    if (conn === "close" || conn === "lost") {
      updateSessionConnState(sessionKey, sock, { connection: "close", isOnline: false });
      return;
    }

    if (conn === "connecting") {
      // Keep online=false but don't force OFFLINE incorrectly; mark connecting
      updateSessionConnState(sessionKey, sock, { connection: "connecting", isOnline: false });
      return;
    }

    // If update doesn't include connection, still refresh paired/me if possible
    updateSessionConnState(sessionKey, sock, {});
  };

  sessionConnHandlers.set(sessionKey, handler);
  sock.ev.on("connection.update", handler);

  // If creds exist, keep paired/me refreshed
  try {
    if (typeof sock.ev.on === "function") {
      sock.ev.on("creds.update", () => {
        updateSessionConnState(sessionKey, sock, { isPaired: !!sock?.authState?.creds?.registered });
      });
    }
  } catch (_) {}
}

// ===== FIX #1: SESSION STATUS (ONLINE/PAIRED/OFFLINE) =====
function getSessionStatus(sock, sessionKey = "") {
  // Prefer cached state (most accurate & instant)
  if (sessionKey && sessionConnState.has(sessionKey)) {
    const st = sessionConnState.get(sessionKey) || {};
    const me = st.me || "";
    const isPaired = !!st.isPaired;
    const isOnline = !!st.isOnline;

    if (isOnline) return { badge: "🟢 Online", isOnline: true, isPaired, me };
    if (isPaired) return { badge: "🟡 Paired", isOnline: false, isPaired: true, me };
    return { badge: "🔴 Offline", isOnline: false, isPaired: false, me };
  }

  // Fallback (best-effort)
  if (!sock) return { badge: "🔴 Offline", isOnline: false, isPaired: false, me: "" };

  const connectionOpen =
    sock?.ws?.readyState === 1 ||
    sock?.ws?.socket?.readyState === 1; // some ws wrappers nest it

  const me =
    sock?.user?.id ||
    sock?.authState?.creds?.me?.id ||
    sock?.authState?.creds?.me?.jid ||
    "";

  const isPaired = !!sock?.authState?.creds?.registered;

  if (connectionOpen) return { badge: "🟢 Online", isOnline: true, isPaired, me };
  if (isPaired) return { badge: "🟡 Paired", isOnline: false, isPaired: true, me };

  return { badge: "🔴 Offline", isOnline: false, isPaired: false, me };
}

// ===== Buttons =====
function homeKeyboard(isAdminUser) {
  return {
    inline_keyboard: [
      [
        { text: "📋 Commands", callback_data: "ui:help" },
        { text: "📊 Stats", callback_data: "ui:stats" }
      ],
      [
        { text: "📱 My Sessions", callback_data: "ui:sessions" },
        { text: "🔄 Refresh", callback_data: "ui:home" }
      ],
      [
        { text: "🔐 Pair", callback_data: "ui:pair" },
        { text: "🧩 QR", callback_data: "ui:qr" }
      ],
      ...(isAdminUser ? [[{ text: "👑 Admin", callback_data: "ui:admin" }]] : []),
      [{ text: "👨‍💼 Contact Admin", url: ADMIN_URL }]
    ]
  };
}

function backHomeKeyboard(isAdminUser) {
  return {
    inline_keyboard: [
      [{ text: "🔙 Back", callback_data: "ui:home" }, { text: "🏠 Home", callback_data: "ui:home" }],
      ...(isAdminUser ? [[{ text: "👑 Admin", callback_data: "ui:admin" }]] : [])
    ]
  };
}

// Modern contact button (kept)
function modernContactButton() {
  return {
    inline_keyboard: [
      [{ text: `👨‍💼 Contact Admin`, url: ADMIN_URL, callback_data: "contact_admin" }],
      [{ text: `📋 View Commands`, callback_data: "ui:help" }]
    ],
    resize_keyboard: true,
    one_time_keyboard: false
  };
}

/* ============================
   FIX #3 (NEW): CUSTOM ACCESS DENIED MESSAGE (HTML)
   ============================ */
async function sendAccessDenied(bot, chatId, userId) {
  return bot.sendMessage(
    chatId,
    "🚫 <b>Access Denied</b>\n\n" +
      "✨ 𝖳𝗈 𝗀𝖾𝗍 𝖺𝖼𝖼𝖾𝗌𝗌 𝗍𝗈 𝗈𝗎𝗋 <b>𝖭𝖠𝖲𝖨𝖱-𝖬𝖣 𝖡𝖮𝖳</b>, 𝗒𝗈𝗎 𝗇𝖾𝖾𝖽 𝗍𝗈 𝗌𝖾𝗇𝖽 𝗒𝗈𝗎𝗋 <b>Chat ID</b> 𝗍𝗈 𝗍𝗁𝖾 𝖺𝖽𝗆𝗂𝗇.\n\n" +
      "📌 <b>Steps:</b>\n" +
      "1️⃣ Click the <b>Chat ID</b> button below — it will open \n" +
      "2️⃣ Copy your Chat ID\n" +
      "3️⃣ Send it to the admin using the <b>Contact Admin</b> button below\n\n" +
      "🆔 <b>Your Chat ID:</b> <code>" + String(chatId) + "</code>\n" +
      "👨‍💻 <b>Admin:</b> @" + ADMIN_USERNAME + "\n" +
      "🔐 Your access will be granted soon after verification.",
    {
      reply_markup: {
        inline_keyboard: [
          [{ text: "🔍 Get Chat ID", url: "https://t.me/chat_id_echo_bot" }],
          [{ text: "👨‍💻 Contact Admin", url: ADMIN_URL }]
        ]
      },
      parse_mode: "HTML"
    }
  ).catch(() => {});
}

// ===== DB HELPERS =====
function readAllowedDb() {
  try {
    if (!fs.existsSync(ALLOWED_DB_PATH)) {
      fs.writeFileSync(ALLOWED_DB_PATH, JSON.stringify({ allowed: [] }, null, 2));
    }
    const data = JSON.parse(fs.readFileSync(ALLOWED_DB_PATH, "utf8"));
    if (!data || !Array.isArray(data.allowed)) return { allowed: [] };
    return data;
  } catch {
    return { allowed: [] };
  }
}

function writeAllowedDb(db) {
  fs.writeFileSync(ALLOWED_DB_PATH, JSON.stringify(db, null, 2));
}

function isAdmin(userId) {
  return tgCfg.ADMIN_TELEGRAM_IDS.map(Number).includes(Number(userId));
}

function isAllowed(userId) {
  const db = readAllowedDb();
  const allowedSet = new Set(db.allowed.map(Number));
  return allowedSet.has(Number(userId)) || isAdmin(userId);
}

function ensureDir(p) {
  fs.mkdirSync(p, { recursive: true });
}

function safeRmDir(dirPath) {
  try {
    fs.rmSync(dirPath, { recursive: true, force: true });
  } catch (_) {}
}

function normalizePhone(input) {
  return String(input || "").replace(/[^0-9]/g, "").trim();
}

function normalizeAlias(input) {
  const a = String(input || "main").trim().toLowerCase();
  const cleaned = a.replace(/[^a-z0-9_-]/g, "");
  return cleaned || "main";
}

function getUserBaseDir(chatId) {
  return path.join(__dirname, tgCfg.SESSIONS_BASE_DIR, `telegram_${chatId}`);
}

function getSessionKey(chatId, alias) {
  return `telegram_${chatId}:${alias}`;
}

async function stopRunningSession(sessionKey) {
  const sessions = getStart().getSessions();
  const sock = sessions.get(sessionKey);
  if (!sock) {
    // ensure cached state becomes OFFLINE if it existed
    if (sessionConnState.has(sessionKey)) {
      sessionConnState.set(sessionKey, {
        ...(sessionConnState.get(sessionKey) || {}),
        connection: "close",
        isOnline: false,
        updatedAt: nowMs()
      });
    }
    return false;
  }

  // detach connection tracker
  if (sessionConnHandlers.has(sessionKey)) {
    try { sock.ev.off("connection.update", sessionConnHandlers.get(sessionKey)); } catch (_) {}
    sessionConnHandlers.delete(sessionKey);
  }

  try {
    if (sock?.ws && typeof sock.ws.close === "function") sock.ws.close();
  } catch (_) {}

  try {
    if (typeof sock?.end === "function") sock.end();
  } catch (_) {}

  sessions.delete(sessionKey);

  // mark state offline instantly
  updateSessionConnState(sessionKey, sock, { connection: "close", isOnline: false });

  return true;
}

function listUserAliases(chatId) {
  const base = getUserBaseDir(chatId);
  if (!fs.existsSync(base)) return [];
  try {
    return fs
      .readdirSync(base, { withFileTypes: true })
      .filter((d) => d.isDirectory())
      .map((d) => d.name)
      .sort();
  } catch {
    return [];
  }
}

// ===== SESSION RESTORATION FUNCTIONS =====
function getAllSessionDirs() {
  const sessionsBase = path.join(__dirname, tgCfg.SESSIONS_BASE_DIR);
  if (!fs.existsSync(sessionsBase)) return [];

  const allSessions = [];

  try {
    const userDirs = fs
      .readdirSync(sessionsBase, { withFileTypes: true })
      .filter((d) => d.isDirectory() && d.name.startsWith("telegram_"))
      .map((d) => d.name);

    for (const userDir of userDirs) {
      const userPath = path.join(sessionsBase, userDir);
      const chatId = userDir.replace("telegram_", "");

      const aliasDirs = fs
        .readdirSync(userPath, { withFileTypes: true })
        .filter((d) => d.isDirectory())
        .map((d) => d.name);

      for (const alias of aliasDirs) {
        const sessionPath = path.join(userPath, alias);
        if (hasAuthFiles(sessionPath)) {
          allSessions.push({ chatId, alias, sessionPath });
        }
      }
    }
  } catch (error) {
    console.error("[SESSION-RESTORE] Error scanning sessions:", error);
  }

  return allSessions;
}

function hasAuthFiles(sessionPath) {
  try {
    const files = fs.readdirSync(sessionPath);
    return files.includes("creds.json");
  } catch {
    return false;
  }
}

// ===== Disconnection Notification System =====
let sessionDisconnectHandlers = new Map();
let restoreHealthTimers = new Map();

function setupDisconnectNotification(sessionKey, chatId, alias, botInstance) {
  const sessions = getStart().getSessions();
  const sock = sessions.get(sessionKey);

  if (!sock || !sock.ev) return;

  const disconnectHandler = (update) => {
    // also update status cache instantly (FIX #1)
    try {
      const conn = update?.connection;
      if (conn === "open") updateSessionConnState(sessionKey, sock, { connection: "open", isOnline: true });
      if (conn === "close" || conn === "lost") updateSessionConnState(sessionKey, sock, { connection: "close", isOnline: false });
      if (conn === "connecting") updateSessionConnState(sessionKey, sock, { connection: "connecting", isOnline: false });
    } catch (_) {}

    if (
      update.connection === "close" ||
      update.connection === "lost" ||
      (update.lastDisconnect &&
        update.lastDisconnect.error &&
        (update.lastDisconnect.error.output?.statusCode === 401 ||
          update.lastDisconnect.error.output?.statusCode === 403))
    ) {
      console.log(`[DISCONNECT] Session ${sessionKey} disconnected/expired`);

      sendNotification(botInstance, chatId, "error", [
        `Session: ${alias}`,
        "",
        "Your WhatsApp session has been disconnected",
        "Reason: Session expired or device unlinked",
        "",
        "Please reconnect using:",
        `/pair ${alias} <your-number>`
      ], {
        title: "Session Expired",
        subtitle: "Reconnection Required"
      }).catch(() => {});

      if (sessionDisconnectHandlers.has(sessionKey)) {
        try {
          sock.ev.off("connection.update", sessionDisconnectHandlers.get(sessionKey));
        } catch (_) {}
        sessionDisconnectHandlers.delete(sessionKey);
      }
    }
  };

  sessionDisconnectHandlers.set(sessionKey, disconnectHandler);
  sock.ev.on("connection.update", disconnectHandler);

  // attach tracker (FIX #1)
  attachConnectionTracker(sessionKey, sock);

  console.log(`[DISCONNECT] Monitoring setup for ${sessionKey}`);
}

async function restoreSession(sessionInfo, botInstance) {
  const { chatId, alias, sessionPath } = sessionInfo;
  const sessionKey = getSessionKey(chatId, alias);

  console.log(`[SESSION-RESTORE] Restoring: ${sessionKey}`);

  try {
    const sock = await getStart().startSession(sessionKey, {
      sessionDir: sessionPath,
      onConnected: async (jid) => {
        console.log(`[SESSION-RESTORE] Successfully restored: ${sessionKey} -> ${jid}`);
        setupDisconnectNotification(sessionKey, chatId, alias, botInstance);
      }
    });

    // attach tracker immediately (FIX #1)
    attachConnectionTracker(sessionKey, sock);
    updateSessionConnState(sessionKey, sock, { isPaired: !!sock?.authState?.creds?.registered });

    if (sock?.authState?.creds?.registered) {
      setTimeout(() => {
        setupDisconnectNotification(sessionKey, chatId, alias, botInstance);
      }, 3000);
    }

    try {
      if (restoreHealthTimers.has(sessionKey)) {
        clearTimeout(restoreHealthTimers.get(sessionKey));
        restoreHealthTimers.delete(sessionKey);
      }

      const ht = setTimeout(async () => {
        try {
          const sessions = getStart().getSessions();
          const current = sessions.get(sessionKey);

          // Use cached state first (FIX #1)
          const cached = sessionConnState.get(sessionKey);
          const isOpen =
            cached ? !!cached.isOnline :
            (current?.ws?.readyState === 1 || current?.ws?.socket?.readyState === 1 || !!current?.user);

          if (!isOpen && current?.authState?.creds?.registered) {
            console.log(`[SESSION-RESTORE] Health-check restart: ${sessionKey}`);
            const sock2 = await getStart().startSession(sessionKey, {
              sessionDir: sessionPath,
              onConnected: async (jid) => {
                console.log(`[SESSION-RESTORE] Recovered: ${sessionKey} -> ${jid}`);
                setupDisconnectNotification(sessionKey, chatId, alias, botInstance);
              }
            });

            attachConnectionTracker(sessionKey, sock2);
          }
        } catch (e) {
          console.error(`[SESSION-RESTORE] Health-check failed ${sessionKey}:`, e?.message || e);
        }
      }, 70000);

      restoreHealthTimers.set(sessionKey, ht);
    } catch (_) {}

    return sock;
  } catch (error) {
    console.error(`[SESSION-RESTORE] Failed to restore ${sessionKey}:`, error.message);
    return null;
  }
}

async function restoreAllSessionsOnStartup(botInstance) {
  console.log("[SESSION-RESTORE] Scanning for existing sessions to restore...");

  const allSessions = getAllSessionDirs();
  console.log(`[SESSION-RESTORE] Found ${allSessions.length} sessions to restore`);

  for (let i = 0; i < allSessions.length; i += 3) {
    const batch = allSessions.slice(i, i + 3);
    await Promise.allSettled(batch.map((session) => restoreSession(session, botInstance)));
    if (i + 3 < allSessions.length) {
      await new Promise((resolve) => setTimeout(resolve, 2000));
    }
  }

  console.log("[SESSION-RESTORE] Session restoration completed");
}

// ===== TELEGRAM BOT INIT =====
const token = tgCfg.BOT_TOKEN;
if (!token) {
  console.error("[TELEGRAM] Missing bot token.");
  console.error("Set TELEGRAM_BOT_TOKEN env OR put it in setting/telegram.js");
  process.exit(1);
}

const bot = new TelegramBot(token, {
  polling: {
    interval: 1000,
    autoStart: true,
    params: { timeout: 10 }
  }
});

console.log("[TELEGRAM] Bot is running (polling enabled)");

setTimeout(() => {
  restoreAllSessionsOnStartup(bot).catch((error) => {
    console.error("[SESSION-RESTORE] Error during startup restoration:", error);
  });
}, 5000);

// ===== UI PAGES (TELEGRAM PANEL COMMANDS ONLY) =====
function getUptimeText() {
  const s = Math.floor(process.uptime());
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return `${h}h ${m}m ${sec}s`;
}

function getBotModeText() {
  return "Public";
}

// ONLY TELEGRAM PANEL COMMANDS (FROM THIS FILE)
function buildHelpLines(isAdminUser) {
  return [
    "📌 Telegram Panel Commands:",
    "",
    "🔐 Pairing / Linking:",
    "• /pair <number>",
    "• /pair <alias> <number>",
    "• /qr",
    "• /qr <alias>",
    "",
    "📱 Sessions:",
    "• /list",
    "• /del <alias>",
    "• /resetall",
    "• /restartall",
    "",
    isAdminUser ? "👑 Admin:" : "",
    isAdminUser ? "• /approve <id>" : "",
    isAdminUser ? "• /deny <id>" : "",
    isAdminUser ? "• /sessions" : "",
    isAdminUser ? "• /restoreall" : "",
    "",
    "⚠️ Notes:",
    "• Use aliases to manage multiple sessions",
    "• You will be notified if session expires"
  ].filter(Boolean);
}

function buildHomeLines(chatId, userId, isAdminUser) {
  const aliases = listUserAliases(chatId);
  const sessions = getStart().getSessions();

  let online = 0;
  for (const a of aliases) {
    const sessionKey = getSessionKey(chatId, a);
    const sock = sessions.get(sessionKey);
    if (getSessionStatus(sock, sessionKey).isOnline) online++;
  }

  return [
    `👤 User ID: ${userId}`,
    `💬 Chat ID: ${chatId}`,
    "",
    `⚡ Status: Connected & Ready`,
    `🕒 Uptime: ${getUptimeText()}`,
    `📦 Version: Ultra 2.0`,
    `🔰 Mode: ${getBotModeText()}`,
    "",
    `📱 Sessions: ${aliases.length} total • ${online} online`,
    "",
    "✨ NASIR-MD Telegram Panel",
    "Manage WhatsApp multi-sessions",
    "easily",
    "",
    "━━━━━━━━━━━━━━━━━━━",
    "Select Option Below 👇",
    "",
    isAdminUser ? "👑 Admin Access: Enabled" : ""
  ].filter(Boolean);
}

function buildStatsLines(chatId) {
  const aliases = listUserAliases(chatId);
  const sessions = getStart().getSessions();

  let online = 0;
  let paired = 0;

  for (const a of aliases) {
    const sessionKey = getSessionKey(chatId, a);
    const sock = sessions.get(sessionKey);
    const st = getSessionStatus(sock, sessionKey);
    if (st.isOnline) online++;
    if (st.isPaired) paired++;
  }

  const db = readAllowedDb();
  const totalAllowed = Array.isArray(db.allowed) ? db.allowed.length : 0;

  return [
    "📊 Live Panel Stats",
    "",
    `🕒 Uptime: ${getUptimeText()}`,
    `📦 Version: Ultra 2.0`,
    `🔰 Mode: ${getBotModeText()}`,
    "",
    `📱 Your Sessions: ${aliases.length}`,
    `🟢 Online: ${online}`,
    `🟡 Paired: ${paired}`,
    `🔴 Offline: ${Math.max(0, aliases.length - online - (paired - online))}`,
    "",
    `👥 Allowed Users: ${totalAllowed}`,
    `🧠 RAM: ${(process.memoryUsage().rss / 1024 / 1024).toFixed(1)} MB`
  ];
}

function buildSessionsLines(chatId) {
  const aliases = listUserAliases(chatId);
  const sessions = getStart().getSessions();

  if (!aliases.length) {
    return [
      "No sessions found",
      "",
      "Create your first session:",
      "• /pair 92xxxxxxxxx",
      "• or press 🔐 Pair button"
    ];
  }

  const lines = [`Found ${aliases.length} session(s):`, ""];
  aliases.forEach((alias, index) => {
    const sessionKey = getSessionKey(chatId, alias);
    const sock = sessions.get(sessionKey);
    const st = getSessionStatus(sock, sessionKey);

    const jid = st.me || "";
    const number = jid ? String(jid).split("@")[0] : "Not Connected";
    const numberDisplay = number === "Not Connected" ? number : `+${number}`;

    lines.push(`${index + 1}. ${alias} • ${st.badge}`);
    lines.push(`   📱 WhatsApp: ${numberDisplay}`);
    lines.push("");
  });

  lines.push("Manage: /del <alias>");
  lines.push("Restart: /restartall");
  return lines;
}

// ===== COMMAND HANDLERS =====

// /start
bot.onText(/\/start$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from?.id;

  if (!isAllowed(userId)) {
    return sendAccessDenied(bot, chatId, userId);
  }

  const isAdminUser = isAdmin(userId);

  const sent = await sendUi(bot, chatId, "NASIR-MD BOT", buildHomeLines(chatId, userId, isAdminUser), {
    emoji: "👑",
    subtitle: "Premium Gold + Royal Black",
    showTimestamp: true,
    button: homeKeyboard(isAdminUser)
  });

  if (sent?.message_id) setPanel(chatId, sent.message_id);
});

// /help (ONLY TELEGRAM PANEL COMMANDS)
bot.onText(/\/help$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from?.id;

  if (!isAllowed(userId)) {
    return sendAccessDenied(bot, chatId, userId);
  }

  const isAdminUser = isAdmin(userId);
  const panelId = getPanelId(chatId);

  if (panelId) {
    return editUi(bot, chatId, panelId, "PANEL COMMANDS", buildHelpLines(isAdminUser), {
      emoji: "📋",
      subtitle: "Telegram Panel Usage",
      showTimestamp: true,
      button: backHomeKeyboard(isAdminUser)
    });
  }

  const sent = await sendUi(bot, chatId, "PANEL COMMANDS", buildHelpLines(isAdminUser), {
    emoji: "📋",
    subtitle: "Telegram Panel Usage",
    showTimestamp: true,
    button: backHomeKeyboard(isAdminUser)
  });

  if (sent?.message_id) setPanel(chatId, sent.message_id);
});

// /pair
bot.onText(/\/pair\s+(.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from?.id;

  if (!isAllowed(userId)) {
    return sendAccessDenied(bot, chatId, userId);
  }

  const raw = String(match[1] || "").trim();
  const parts = raw.split(/\s+/).filter(Boolean);

  let alias = "main";
  let phone = "";

  if (parts.length === 1) {
    phone = normalizePhone(parts[0]);
  } else {
    alias = normalizeAlias(parts[0]);
    phone = normalizePhone(parts.slice(1).join(" "));
  }

  if (!phone || phone.length < 8) {
    return sendNotification(bot, chatId, "warning", [
      "Invalid phone number format",
      "",
      "Correct usage:",
      "• /pair 923xxxxxxxxx",
      "• /pair work 923xxxxxxxxx",
      "",
      "Examples:",
      "/pair 923123456789",
      "/pair business 923987654321"
    ], { title: "Format Error" });
  }

  const sessionKey = getSessionKey(chatId, alias);
  const sessionDir = path.join(getUserBaseDir(chatId), alias);
  ensureDir(sessionDir);

  // FIX #2: Explicit gate (pair codes only allowed when /pair invoked)
  markExplicitPairRequest(sessionKey, 3 * 60 * 1000);

  const sessions = getStart().getSessions();
  const existingSock = sessions.get(sessionKey);

  if (existingSock?.authState?.creds?.registered) {
    const st = getSessionStatus(existingSock, sessionKey);
    if (st.isOnline) {
      return sendNotification(bot, chatId, "info", [
        `Session '${alias}' is already active`,
        "",
        "To restart this session:",
        `1. /restartall  (reconnect all)`,
        `2. /del ${alias}  (delete + re-pair)`
      ], { title: "Session Exists" });
    }
    try { await stopRunningSession(sessionKey); } catch (_) {}
  }

  try {
    await sendNotification(bot, chatId, "loading", [
      `Initializing session: ${alias}`,
      `Phone: ${phone}`,
      "",
      "Generating pairing code..."
    ], { title: "Starting Session", autoDelete: true });

    let codeSent = false;
    let deployedSent = false;

    const announceConnected = async (jid) => {
      if (deployedSent) return;
      deployedSent = true;

      const number = jid ? jid.split("@")[0] : phone;
      setupDisconnectNotification(sessionKey, chatId, alias, bot);

      await sendNotification(bot, chatId, "success", [
        `Session: ${alias}`,
        `WhatsApp: ${number}`,
        "",
        "Status: Connected ✅",
        "This session will auto-reconnect",
        "on bot restart",
        "",
        "⚠️ You'll be notified if session expires"
      ], { title: "Connected Successfully", subtitle: "WhatsApp Session Active" });
    };

    const sock = await getStart().startSession(sessionKey, {
      sessionDir,
      phoneNumber: phone,

      onPairCode: async (code) => {
  // FIX #2: Block any pairing code unless explicitly requested by /pair,
  // and also suppress after delete/restart windows.
  if (!isExplicitPairAllowed(sessionKey) || isPairSuppressed(sessionKey)) {
    return;
  }

  codeSent = true;

  const copyButton = {
    inline_keyboard: [
      [{ text: "📋 Copy Pairing Code", callback_data: `copy_code_${code}` }],
      [{ text: "ℹ️ How to Pair", callback_data: "how_to_pair" }],
      [{ text: "🏠 Home", callback_data: "ui:home" }]
    ]
  };

  const timeNow = moment().tz("Asia/Karachi").format("HH:mm:ss");

  // ✅ SAME stylish box, but HTML + <code> inside (easy copy)
  const box =
    `╭━〔 🔑 <b>Pairing Code Ready</b> 〕━╮\n` +
    `┃ ${escapeHtml("Enter in WhatsApp")}\n` +
    `┃\n` +
    `┃ 📌 <b>Session:</b> ${escapeHtml(alias)}\n` +
    `┃\n` +
    `┃ 🔐 <b>Your Pairing Code:</b>\n` +
    `┃ <code>${escapeHtml(code)}</code>\n` +
    `┃\n` +
    `┃ 📲 <b>To pair (Steps):</b>\n` +
    `┃ 1️⃣ Open WhatsApp\n` +
    `┃ 2️⃣ Go to Settings → Linked Devices\n` +
    `┃ 3️⃣ Tap 'Link a Device'\n` +
    `┃ 4️⃣ Enter the code above ✅\n` +
    `┃\n` +
    `┃ ⏳ <b>Important:</b> ⚠️ Code expires in <b>5 minutes</b>\n` +
    `┃\n` +
    `┃ 🕐 ${escapeHtml(timeNow)}\n` +
    `╰━━━━━━━━━━━━━━━━━━━━━━╯`;

  await bot.sendMessage(chatId, box, {
    parse_mode: "HTML",
    reply_markup: copyButton
  }).catch(() => {});
},



      onConnected: async (jid) => {
        await announceConnected(jid);
      }
    });

    // FIX #1: attach tracker immediately
    attachConnectionTracker(sessionKey, sock);
    updateSessionConnState(sessionKey, sock, { isPaired: !!sock?.authState?.creds?.registered });

    if (sock?.authState?.creds?.registered) {
      await sendNotification(bot, chatId, "info", [
        `Session '${alias}' is already paired`,
        "Reconnecting now..."
      ], { title: "Restoring Session", autoDelete: true });

      try {
        const jid = sock?.user?.id || sock?.authState?.creds?.me?.id || "";
        if (jid) await announceConnected(jid);
      } catch (_) {}
    }

    try {
      if (sock?.ev?.on) {
        sock.ev.on("connection.update", async (u) => {
          if (u?.connection === "open") {
            try {
              const jid = sock?.user?.id || sock?.authState?.creds?.me?.id || "";
              await announceConnected(jid);
            } catch (_) {}
          }
        });
      }
    } catch (_) {}

    await sendNotification(bot, chatId, "loading", [
      `Waiting for pairing completion...`,
      `Session: ${alias}`,
      `Phone: ${phone}`,
      "",
      "Complete pairing in WhatsApp to continue"
    ], { title: "Awaiting Pairing", autoDelete: true });

    await new Promise((r) => setTimeout(r, 12000));

    if (!sock?.authState?.creds?.registered && !codeSent) {
      await sendNotification(bot, chatId, "warning", [
        `Pairing code not generated for ${alias}`,
        "",
        "Possible reasons:",
        "• Invalid phone number",
        "• WhatsApp not installed",
        "• Network issues",
        "",
        "Try again:",
        `/pair ${alias} ${phone}`
      ], { title: "Pairing Failed" });
    }
  } catch (err) {
    console.error("[TELEGRAM] /pair error:", err);

    await sendNotification(bot, chatId, "error", [
      `Error: ${err?.message || "Unknown error"}`,
      "",
      "Session: " + alias,
      "Phone: " + phone,
      "",
      "Please try again or contact support"
    ], { title: "Connection Error" });
  }
});

// /qr
bot.onText(/\/qr(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from?.id;

  if (!isAllowed(userId)) {
    return sendAccessDenied(bot, chatId, userId);
  }

  const raw = String((match && match[1]) || "").trim();
  const alias = raw ? normalizeAlias(raw.split(/\s+/)[0]) : "main";

  const sessionKey = getSessionKey(chatId, alias);
  const sessionDir = path.join(getUserBaseDir(chatId), alias);
  ensureDir(sessionDir);

  const sessions = getStart().getSessions();
  const existingSock = sessions.get(sessionKey);

  if (existingSock?.authState?.creds?.registered) {
    const st = getSessionStatus(existingSock, sessionKey);
    if (st.isOnline) {
      return sendNotification(bot, chatId, "info", [
        `Session '${alias}' is already active`,
        "",
        "To restart this session:",
        `1. /restartall  (reconnect all)`,
        `2. /del ${alias}  (delete + re-link)`
      ], { title: "Session Exists" });
    }
    try { await stopRunningSession(sessionKey); } catch (_) {}
  }

  try {
    await sendNotification(bot, chatId, "loading", [
      `Initializing QR session: ${alias}`,
      "",
      "Generating QR code..."
    ], { title: "Starting QR", autoDelete: true });

    let deployedSent = false;

    const announceConnected = async (jid) => {
      if (deployedSent) return;
      deployedSent = true;

      const number = jid ? String(jid).split("@")[0] : "";
      setupDisconnectNotification(sessionKey, chatId, alias, bot);

      await sendNotification(bot, chatId, "success", [
        `Session: ${alias}`,
        number ? `WhatsApp: ${number}` : "WhatsApp: Connected",
        "",
        "Status: Connected ✅",
        "This session will auto-reconnect",
        "on bot restart",
        "",
        "⚠️ You'll be notified if session expires"
      ], { title: "Connected Successfully", subtitle: "WhatsApp Session Active" });
    };

    await startQrSession({
      sessionDir,

      onQRCode: async (qrDataURL) => {
        try {
          const base64 = String(qrDataURL || "").split(",")[1] || "";
          const buffer = Buffer.from(base64, "base64");

          await bot.sendPhoto(chatId, buffer, {
            caption:
              `Scan this QR in WhatsApp to activate your session\n\n` +
              `Session: ${alias}\n\n` +
              `Steps:\n` +
              `1) WhatsApp → Settings → Linked Devices\n` +
              `2) Link a Device\n` +
              `3) Scan the QR\n\n` +
              `⚠️ QR expires quickly — if it expires, send /qr again.`
          });
        } catch (e) {
          console.error("[TELEGRAM] sendPhoto /qr error:", e);
          await sendNotification(bot, chatId, "error", [
            `Failed to send QR image`,
            `Error: ${e?.message || "Unknown error"}`
          ], { title: "QR Send Failed" });
        }
      },

      onConnected: async (jid) => {
        setTimeout(async () => {
          try {
            const sock = await getStart().startSession(sessionKey, {
              sessionDir,
              onConnected: async (jid2) => {
                await announceConnected(jid2);
              }
            });

            // FIX #1: attach tracker
            attachConnectionTracker(sessionKey, sock);
            updateSessionConnState(sessionKey, sock, { isPaired: !!sock?.authState?.creds?.registered });

            if (sock?.authState?.creds?.registered) {
              try {
                const jidNow = sock?.user?.id || sock?.authState?.creds?.me?.id || "";
                if (jidNow) await announceConnected(jidNow);
              } catch (_) {}
            } else {
              await announceConnected(jid);
            }
          } catch (err) {
            console.error("[TELEGRAM] /qr startSession error:", err);
            await sendNotification(bot, chatId, "error", [
              `QR scanned but session start failed`,
              `Error: ${err?.message || "Unknown error"}`
            ], { title: "Activation Failed" });
          }
        }, 16000);
      },

      onError: async (err) => {
        await sendNotification(bot, chatId, "error", [
          `QR Error: ${err?.message || "Unknown error"}`,
          "",
          `Session: ${alias}`,
          "",
          "Try again:",
          `/qr ${alias}`
        ], { title: "QR Failed" });
      }
    });

    await sendNotification(bot, chatId, "loading", [
      `Waiting for QR scan...`,
      `Session: ${alias}`,
      "",
      "Scan the QR in WhatsApp to continue"
    ], { title: "Awaiting Scan", autoDelete: true });
  } catch (err) {
    console.error("[TELEGRAM] /qr error:", err);
    await sendNotification(bot, chatId, "error", [
      `Error: ${err?.message || "Unknown error"}`,
      "",
      "Please try again or contact support"
    ], { title: "QR Error" });
  }
});

// /list
bot.onText(/\/list$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from?.id;

  if (!isAllowed(userId)) {
    return sendAccessDenied(bot, chatId, userId);
  }

  await sendNotification(bot, chatId, "list", buildSessionsLines(chatId), {
    title: "Your Sessions",
    subtitle: "Telegram Panel"
  });
});

// /del
bot.onText(/\/del\s+(.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from?.id;

  if (!isAllowed(userId)) {
    return sendAccessDenied(bot, chatId, userId);
  }

  const alias = normalizeAlias(match[1]);
  const sessionKey = getSessionKey(chatId, alias);
  const sessionDir = path.join(getUserBaseDir(chatId), alias);

  // FIX #2: suppress any unexpected pairing output for this sessionKey after deletion
  suppressPair(sessionKey, 3 * 60 * 1000);

  // FIX #1 (DELETE BUG): cancel any pending health timers that can recreate the session
  if (restoreHealthTimers.has(sessionKey)) {
    try { clearTimeout(restoreHealthTimers.get(sessionKey)); } catch (_) {}
    restoreHealthTimers.delete(sessionKey);
  }

  if (sessionDisconnectHandlers.has(sessionKey)) {
    try {
      const sessions = getStart().getSessions();
      const sock = sessions.get(sessionKey);
      if (sock?.ev) {
        sock.ev.off("connection.update", sessionDisconnectHandlers.get(sessionKey));
      }
    } catch (_) {}
    sessionDisconnectHandlers.delete(sessionKey);
  }

  // Detach cached connection handler (if any)
  if (sessionConnHandlers.has(sessionKey)) {
    try {
      const sessions = getStart().getSessions();
      const sock = sessions.get(sessionKey);
      if (sock?.ev) sock.ev.off("connection.update", sessionConnHandlers.get(sessionKey));
    } catch (_) {}
    sessionConnHandlers.delete(sessionKey);
  }

  await stopRunningSession(sessionKey);

  // Remove on-disk session folder (so /list cannot see it)
  safeRmDir(sessionDir);

  // Clean caches so status/list can't show ghost sessions
  sessionConnState.delete(sessionKey);
  explicitPairRequestUntil.delete(sessionKey);
  suppressPairUntil.delete(sessionKey);

  await sendNotification(bot, chatId, "trash", [
    `Session deleted: ${alias}`,
    "",
    "To recreate:",
    `/pair ${alias} <number>`
  ], { title: "Session Removed" });
});

// /resetall
bot.onText(/\/resetall$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from?.id;

  if (!isAllowed(userId)) {
    return sendAccessDenied(bot, chatId, userId);
  }

  const base = getUserBaseDir(chatId);
  const aliases = listUserAliases(chatId);

  if (!aliases.length) {
    return sendNotification(bot, chatId, "info", ["No sessions found to reset"], {
      title: "No Sessions"
    });
  }

  aliases.forEach((alias) => {
    const sessionKey = getSessionKey(chatId, alias);
    if (sessionDisconnectHandlers.has(sessionKey)) {
      sessionDisconnectHandlers.delete(sessionKey);
    }

    if (restoreHealthTimers.has(sessionKey)) {
      try { clearTimeout(restoreHealthTimers.get(sessionKey)); } catch (_) {}
      restoreHealthTimers.delete(sessionKey);
    }

    // FIX #2: suppress any unexpected pairing output after reset
    suppressPair(sessionKey, 3 * 60 * 1000);

    // clear cached states
    sessionConnState.delete(sessionKey);
    explicitPairRequestUntil.delete(sessionKey);
    suppressPairUntil.delete(sessionKey);

    if (sessionConnHandlers.has(sessionKey)) {
      sessionConnHandlers.delete(sessionKey);
    }
  });

  for (const a of aliases) {
    await stopRunningSession(getSessionKey(chatId, a));
  }
  safeRmDir(base);

  await sendNotification(bot, chatId, "trash", [
    `All sessions deleted: ${aliases.length}`,
    "",
    "All data has been cleared",
    "Start fresh with /pair"
  ], { title: "Complete Reset" });
});

// /restartall
bot.onText(/\/restartall$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from?.id;

  if (!isAllowed(userId)) {
    return sendAccessDenied(bot, chatId, userId);
  }

  const aliases = listUserAliases(chatId);

  if (!aliases.length) {
    return sendNotification(bot, chatId, "info", [
      "No sessions found to restart",
      "",
      "Create your first session:",
      "/pair 92xxxxxxxxx"
    ], { title: "No Sessions" });
  }

  await sendNotification(bot, chatId, "restart", [
    `Restarting ${aliases.length} session(s)...`,
    "",
    "Please wait while all sessions",
    "are reconnecting"
  ], { title: "Restarting Sessions", autoDelete: true });

  aliases.forEach((alias) => {
    const sessionKey = getSessionKey(chatId, alias);
    if (sessionDisconnectHandlers.has(sessionKey)) {
      sessionDisconnectHandlers.delete(sessionKey);
    }

    if (restoreHealthTimers.has(sessionKey)) {
      try { clearTimeout(restoreHealthTimers.get(sessionKey)); } catch (_) {}
      restoreHealthTimers.delete(sessionKey);
    }

    // FIX #2: restarting must NOT trigger pairing output
    suppressPair(sessionKey, 3 * 60 * 1000);
  });

  let restoredCount = 0;
  let failedCount = 0;

  for (const alias of aliases) {
    const sessionDir = path.join(getUserBaseDir(chatId), alias);
    const sessionKey = getSessionKey(chatId, alias);

    await stopRunningSession(sessionKey);
    await new Promise((resolve) => setTimeout(resolve, 500));

    try {
      const sock = await getStart().startSession(sessionKey, { sessionDir });
      if (sock) {
        setupDisconnectNotification(sessionKey, chatId, alias, bot);

        // FIX #1: attach tracker
        attachConnectionTracker(sessionKey, sock);

        restoredCount++;
      }
    } catch (error) {
      failedCount++;
    }

    await new Promise((resolve) => setTimeout(resolve, 1000));
  }

  await sendNotification(bot, chatId, "done", [
    `Sessions restart completed`,
    "",
    `✅ Successful: ${restoredCount}`,
    `❌ Failed: ${failedCount}`,
    `📊 Total: ${aliases.length}`,
    "",
    "All sessions should be online now"
  ], { title: "Restart Complete" });
});

// /approve
bot.onText(/\/approve\s+(\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const adminId = msg.from?.id;

  if (!isAdmin(adminId)) {
    return sendNotification(bot, chatId, "error", "Admin only command");
  }

  const id = Number(match[1]);
  const db = readAllowedDb();
  const set = new Set(db.allowed.map(Number));

  if (set.has(id)) {
    return sendNotification(bot, chatId, "info", [`User ${id} is already approved`], {
      title: "Already Approved"
    });
  }

  set.add(id);
  db.allowed = Array.from(set);
  writeAllowedDb(db);

  await sendNotification(bot, chatId, "success", [
    `User approved successfully`,
    `ID: ${id}`,
    "",
    "User can now access the bot"
  ], { title: "User Approved" });
});

// /deny
bot.onText(/\/deny\s+(\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const adminId = msg.from?.id;

  if (!isAdmin(adminId)) {
    return sendNotification(bot, chatId, "error", "Admin only command");
  }

  const id = Number(match[1]);
  const db = readAllowedDb();
  db.allowed = db.allowed.map(Number).filter((x) => x !== id);
  writeAllowedDb(db);

  await sendNotification(bot, chatId, "trash", [
    `User access removed`,
    `ID: ${id}`,
    "",
    "User can no longer access the bot"
  ], { title: "Access Denied" });
});

// /sessions
bot.onText(/\/sessions$/, async (msg) => {
  const chatId = msg.chat.id;
  const adminId = msg.from?.id;

  if (!isAdmin(adminId)) {
    return sendNotification(bot, chatId, "error", "Admin only command");
  }

  const sessions = getStart().getSessions();
  const keys = Array.from(sessions.keys()).sort();

  const lines = [`Total active sessions: ${keys.length}`, ""];

  if (keys.length) {
    keys.forEach((key, index) => {
      const [user, alias] = key.split(":");
      const userId = user.replace("telegram_", "");
      const sock = sessions.get(key);

      const st = getSessionStatus(sock, key);
      const jid = st.me || "";
      const phoneNumber = jid ? String(jid).split("@")[0] : "Not Connected";
      const phoneDisplay = phoneNumber === "Not Connected" ? phoneNumber : `+${phoneNumber}`;

      lines.push(`${index + 1}. ${alias} • User: ${userId} • ${st.badge}`);
      lines.push(`   📱 WhatsApp: ${phoneDisplay}`);
    });
  } else {
    lines.push("No active sessions in memory");
  }

  await sendNotification(bot, chatId, "list", lines, {
    title: "Active Sessions",
    subtitle: "RAM Memory"
  });
});

// /restoreall
bot.onText(/\/restoreall$/, async (msg) => {
  const chatId = msg.chat.id;
  const adminId = msg.from?.id;

  if (!isAdmin(adminId)) {
    return sendNotification(bot, chatId, "error", "Admin only command");
  }

  await sendNotification(bot, chatId, "loading", [
    "Initiating restoration of all saved sessions..."
  ], { title: "Restoring Sessions", autoDelete: true });

  try {
    await restoreAllSessionsOnStartup(bot);
    await sendNotification(bot, chatId, "success", [
      "All saved sessions have been restored!",
      "",
      "Check /sessions to see running sessions."
    ], { title: "Sessions Restored" });
  } catch (error) {
    await sendNotification(bot, chatId, "error", [
      `Restoration failed: ${error.message}`
    ], { title: "Restoration Failed" });
  }
});

// Polling error handler
bot.on("polling_error", (e) => {
  console.error("[TELEGRAM] polling_error:", e?.message || e);
});

// ===== Callback query handler (SINGLE MESSAGE UI) =====
bot.on("callback_query", async (callbackQuery) => {
  const chatId = callbackQuery.message?.chat?.id;
  const userId = callbackQuery.from?.id;
  const data = callbackQuery.data || "";
  const messageId = callbackQuery.message?.message_id;

  try { await bot.answerCallbackQuery(callbackQuery.id); } catch (_) {}

  if (!chatId || !messageId) return;

  if (!isAllowed(userId)) {
    return sendAccessDenied(bot, chatId, userId);
  }

  const isAdminUser = isAdmin(userId);
  setPanel(chatId, messageId);

  if (data === "ui:home") {
    return editUi(bot, chatId, messageId, "NASIR-MD BOT", buildHomeLines(chatId, userId, isAdminUser), {
      emoji: "👑",
      subtitle: "Premium Gold + Royal Black",
      showTimestamp: true,
      button: homeKeyboard(isAdminUser)
    });
  }

  if (data === "ui:help") {
    return editUi(bot, chatId, messageId, "PANEL COMMANDS", buildHelpLines(isAdminUser), {
      emoji: "📋",
      subtitle: "Telegram Panel Usage",
      showTimestamp: true,
      button: backHomeKeyboard(isAdminUser)
    });
  }

  if (data === "ui:stats") {
    return editUi(bot, chatId, messageId, "LIVE STATS", buildStatsLines(chatId), {
      emoji: "📊",
      subtitle: "Runtime & Sessions",
      showTimestamp: true,
      button: backHomeKeyboard(isAdminUser)
    });
  }

  if (data === "ui:sessions") {
    return editUi(bot, chatId, messageId, "YOUR SESSIONS", buildSessionsLines(chatId), {
      emoji: "📱",
      subtitle: "Manage Aliases",
      showTimestamp: true,
      button: backHomeKeyboard(isAdminUser)
    });
  }

  if (data === "ui:pair") {
    return editUi(bot, chatId, messageId, "PAIR SESSION", [
      "Use:",
      "• /pair 923xxxxxxxxx",
      "• /pair <alias> 923xxxxxxxxx",
      "",
      "Example:",
      "/pair main 923123456789"
    ], {
      emoji: "🔐",
      subtitle: "Pairing Guide",
      showTimestamp: true,
      button: backHomeKeyboard(isAdminUser)
    });
  }

  if (data === "ui:qr") {
    return editUi(bot, chatId, messageId, "QR SESSION", [
      "Use:",
      "• /qr",
      "• /qr <alias>",
      "",
      "Example:",
      "/qr main"
    ], {
      emoji: "🧩",
      subtitle: "QR Linking Guide",
      showTimestamp: true,
      button: backHomeKeyboard(isAdminUser)
    });
  }

  if (data === "ui:admin") {
    if (!isAdminUser) {
      return editUi(bot, chatId, messageId, "ACCESS DENIED", [
        "Admin only panel",
        "",
        "Contact admin to request access."
      ], {
        emoji: "🔒",
        subtitle: "Permission Required",
        showTimestamp: true,
        button: backHomeKeyboard(isAdminUser)
      });
    }

    return editUi(bot, chatId, messageId, "ADMIN PANEL", [
      "Admin Commands:",
      "",
      "• /approve <id>",
      "• /deny <id>",
      "• /sessions",
      "• /restoreall"
    ], {
      emoji: "👑",
      subtitle: "Owner Controls",
      showTimestamp: true,
      button: backHomeKeyboard(isAdminUser)
    });
  }

  // ✅ CHANGE ONLY THIS: Copy button now sends NEW message as HTML (copy-friendly code)
  if (data.startsWith("copy_code_")) {
    const code = data.replace("copy_code_", "");

    await bot.sendMessage(
      chatId,
      "📋 <b>Pairing Code:</b>\n\n" +
        `<code>${escapeHtml(code)}</code>\n\n` +
        "✅ <b>Tip:</b> Tap to copy or select & copy manually ✨",
      {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [[{ text: "✅ Code Copied", callback_data: "code_copied" }]]
        }
      }
    ).catch(() => {});
    return;
  }

  // ✅ SAME AS YOUR OLD FLOW
  if (data === "code_copied") {
    await bot.sendMessage(chatId, "✅ Great! Now enter this code in WhatsApp to complete pairing.", {
      reply_markup: { inline_keyboard: [[{ text: "🔄 Need New Code?", callback_data: "need_new_code" }]] }
    }).catch(() => {});
    return;
  }

  // ✅ SAME AS YOUR OLD FLOW
  if (data === "need_new_code") {
    await bot.sendMessage(chatId, "To get a new pairing code, use the /pair command again with your phone number.", {
      reply_markup: { inline_keyboard: [[{ text: "📖 How to Pair", callback_data: "how_to_pair" }]] }
    }).catch(() => {});
    return;
  }

  if (data === "how_to_pair") {
    return editUi(bot, chatId, messageId, "PAIRING INSTRUCTIONS", [
      "1. Open WhatsApp on your phone",
      "2. Tap ⋮ → Linked Devices",
      "3. Tap 'Link a Device'",
      "4. Enter the code",
      "5. Wait for confirmation",
      "",
      "⚠️ Code expires in 5 minutes",
      "🔄 Use /pair to generate new code"
    ], {
      emoji: "ℹ️",
      subtitle: "Step-by-Step",
      showTimestamp: true,
      button: backHomeKeyboard(isAdminUser)
    });
  }

  if (data === "contact_admin") {
    return bot.sendMessage(chatId, `Contact admin: @${ADMIN_USERNAME}\n\nPlease include your Telegram ID: ${userId}`, {
      reply_markup: {
        inline_keyboard: [
          [{ text: "📨 Message Admin", url: ADMIN_URL }],
          [{ text: "🏠 Home", callback_data: "ui:home" }]
        ]
      }
    }).catch(() => {});
  }
});
