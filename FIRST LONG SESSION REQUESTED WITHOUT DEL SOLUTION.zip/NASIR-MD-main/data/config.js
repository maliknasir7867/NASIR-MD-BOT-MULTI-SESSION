module.exports = {
    owner: "923206939553",   // your number option A
    botname: "NASIR-MD BOT"
};
