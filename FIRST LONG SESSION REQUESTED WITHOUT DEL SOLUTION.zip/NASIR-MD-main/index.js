/**
 * NASIR-MD BOT entrypoint
 *
 * If TELEGRAM_BOT_TOKEN is set, start the Telegram multi-session controller.
 * Otherwise, start the single WhatsApp session (legacy behaviour).
 */

/**
 * Global safety: prevent Optiklink panel restarts / transient Baileys errors
 * from killing the whole process. We log and keep running so sessions can
 * auto-recover.
 */
process.on('unhandledRejection', (reason) => {
  try { console.error('[FATAL] unhandledRejection:', reason); } catch (_) {}
});
process.on('uncaughtException', (err) => {
  try { console.error('[FATAL] uncaughtException:', err); } catch (_) {}
});
process.on('SIGTERM', () => process.exit(0));
process.on('SIGINT', () => process.exit(0));


// Panel heartbeat: keep process active and visible in Optiklink logs
setInterval(() => {
  try { console.log(`[HEARTBEAT] NASIR-MD alive ${new Date().toISOString()}`); } catch (_) {}
}, 10 * 60 * 1000);

if (process.env.TELEGRAM_BOT_TOKEN) {
  require('./telegram');
} else {
  require('./wa');
}
