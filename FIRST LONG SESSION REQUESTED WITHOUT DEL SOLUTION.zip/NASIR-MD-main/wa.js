/**
 * NASIR MD BOT - A WhatsApp Bot
 * Copyright (c) 2024 Professor
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the MIT License.
 * 
 * Credits:
 * - Baileys Library by @adiwajshing
 * - Pair Code implementation inspired by TechGod143 & DGXEON
 */
 process.env.TZ = "Asia/Karachi";
require('./settings')
const { handleIncomingCall } = require('./commands/anticall');
require('./lib/session_bootstrap')
const { runWithSession } = require('./lib/sessionContext')
const sessionState = require('./lib/sessionState')
const { Boom } = require('@hapi/boom')
const fs = require('fs')
const chalk = require('chalk')
const FileType = require('file-type')
const path = require('path')
const axios = require('axios')
const { handleMessages, handleGroupParticipantUpdate, handleStatus } = require('./main');
const PhoneNumber = require('awesome-phonenumber')
const { imageToWebp, videoToWebp, writeExifImg, writeExifVid } = require('./lib/exif')
const { smsg, isUrl, generateMessageTag, getBuffer, getSizeMedia, fetch, await, sleep, reSize } = require('./lib/myfunc')
const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    generateForwardMessageContent,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    generateMessageID,
    downloadContentFromMessage,
    jidDecode,
    proto,
    jidNormalizedUser,
    makeCacheableSignalKeyStore,
    delay
} = require("@whiskeysockets/baileys")
const NodeCache = require("node-cache")
// Using a lightweight persisted store instead of makeInMemoryStore (compat across versions)
const pino = require("pino")
const readline = require("readline")
const { parsePhoneNumber } = require("libphonenumber-js")
const { PHONENUMBER_MCC } = require('@whiskeysockets/baileys/lib/Utils/generics')
const { rmSync, existsSync } = require('fs')
const { join } = require('path')

// Import lightweight store
const store = require('./lib/lightweight_store')

// =========================
// Robust socket lifecycle & reconnect guards
// =========================
let __NASIR_ACTIVE_SOCK__ = null
let __NASIR_STARTING__ = false
let __NASIR_RECONNECT_SCHEDULED__ = false
let __NASIR_RECONNECT_ATTEMPTS__ = 0

// Connection health tracking (zombie-session protection)
let __nasirConnState = 'close'
let __nasirLastEventAt = Date.now()
let __nasirLastIncomingAt = Date.now()
let __nasirLastOpenAt = 0

function __nasirCleanupSock(sock) {
    try {
        if (!sock) return
        try { sock.ev?.removeAllListeners?.() } catch (_) {}
        try { sock.ws?.removeAllListeners?.() } catch (_) {}
        try { sock.ws?.close?.() } catch (_) {}
        try { sock.end?.() } catch (_) {}
        try { sock.logout?.() } catch (_) {}
    } catch (_) {}
}

function __nasirScheduleRestart(reason, delayMs = 5000) {
    if (__NASIR_RECONNECT_SCHEDULED__) return
    __NASIR_RECONNECT_SCHEDULED__ = true
    const attempt = (++__NASIR_RECONNECT_ATTEMPTS__)
    const extra = Math.min(60_000, attempt * 2000)
    const wait = Math.max(1000, delayMs + extra)
    try { console.log(`🔁 [RECONNECT] scheduled in ${wait}ms | attempt=${attempt} | reason=${reason || 'unknown'}`) } catch (_) {}
    setTimeout(() => {
        __NASIR_RECONNECT_SCHEDULED__ = false
        try { startNasirBotInc() } catch (e) { try { console.error('Reconnect start error:', e) } catch (_) {} }
    }, wait)
}

// Initialize store
store.readFromFile()
const settings = require('./settings')
setInterval(() => store.writeToFile(), settings.storeWriteInterval || 10000)

// Memory optimization - Force garbage collection if available
setInterval(() => {
    if (global.gc) {
        global.gc()
        console.log('🧹 Garbage collection completed')
    }
}, 60_000) // every 1 minute

// Memory monitoring - Restart if RAM gets too high
setInterval(() => {
    const used = process.memoryUsage().rss / 1024 / 1024
    // IMPORTANT:
    // Older builds hard-exited around ~400MB which caused long-running sessions to
    // break frequently (sessions looked "active" in Linked Devices but stopped
    // responding after restarts). Instead, try GC first and only hard-exit at a
    // much higher threshold.
    if (used > 400) {
        try { console.log(`⚠️ RAM high (${used.toFixed(0)}MB). Trying cleanup...`) } catch (_) {}
        try { if (global.gc) global.gc() } catch (_) {}
        try { if (__NASIR_ACTIVE_SOCK__?.msgRetryCounterCache?.clear) __NASIR_ACTIVE_SOCK__.msgRetryCounterCache.clear() } catch (_) {}
    }
    if (used > (Number(process.env.NASIR_RAM_HARD_EXIT_MB) || 950)) {
        console.log(`🛑 RAM extremely high (${used.toFixed(0)}MB). Restarting process to protect panel...`)
        process.exit(1) // Panel will auto-restart
    }
}, 30_000) // check every 30 seconds

let phoneNumber = "923206939553"
let owner = JSON.parse(fs.readFileSync('./data/owner.json'))

global.botname = "NASIR MD BOT"
global.themeemoji = "•"
const pairingCode = !!phoneNumber || process.argv.includes("--pairing-code")
const useMobile = process.argv.includes("--mobile")

// Only create readline interface if we're in an interactive environment
const rl = process.stdin.isTTY ? readline.createInterface({ input: process.stdin, output: process.stdout }) : null
const question = (text) => {
    if (rl) {
        return new Promise((resolve) => rl.question(text, resolve))
    } else {
        // In non-interactive environment, use ownerNumber from settings
        return Promise.resolve(settings.ownerNumber || phoneNumber)
    }
}


async function startNasirBotInc() {
    if (__NASIR_STARTING__) {
        return __NASIR_ACTIVE_SOCK__
    }
    __NASIR_STARTING__ = true
    try {
        let { version, isLatest } = await fetchLatestBaileysVersion()
        const { state, saveCreds } = await useMultiFileAuthState(`./session`)
        const msgRetryCounterCache = new NodeCache()

        // Ensure only one active socket instance at a time (prevents "active but not responding" states)
        try {
            if (__NASIR_ACTIVE_SOCK__) {
                __nasirCleanupSock(__NASIR_ACTIVE_SOCK__)
            }
        } catch (_) {}

        const safeSaveCreds = async () => {
            try {
                await saveCreds()
            } catch (e) {
                try { console.error('Error saving creds:', e?.message || e) } catch (_) {}
            }
        }

        // Connection health tracking (helps recover from Optiklink panel restarts/network freezes)
// Use shared globals so watchdogs survive restarts without shadowing.
__nasirConnState = 'init'
__nasirLastOpenAt = 0
__nasirLastEventAt = Date.now()
__nasirLastIncomingAt = Date.now()
const __nasirTouch = (kind = 'event') => {
    const now = Date.now()
    __nasirLastEventAt = now
    if (kind === 'incoming') __nasirLastIncomingAt = now
}

if (__NASIR_ACTIVE_SOCK__) {
    __nasirCleanupSock(__NASIR_ACTIVE_SOCK__)
    __NASIR_ACTIVE_SOCK__ = null
}
        const NasirBotInc = makeWASocket({
            version,
            logger: pino({ level: 'silent' }),
            printQRInTerminal: !pairingCode,
            browser: ["Ubuntu", "Chrome", "20.0.04"],
            auth: {
                creds: state.creds,
                keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "fatal" }).child({ level: "fatal" })),
            },
            markOnlineOnConnect: true,
            generateHighQualityLinkPreview: true,
            syncFullHistory: false,
            getMessage: async (key) => {
                let jid = jidNormalizedUser(key.remoteJid)
                let msg = await store.loadMessage(jid, key.id)
                return msg?.message || ""
            },
            msgRetryCounterCache,
            defaultQueryTimeoutMs: 60000,
            connectTimeoutMs: 60000,
            keepAliveIntervalMs: 10000,
        })

        // Mark this socket as the active instance
        __NASIR_ACTIVE_SOCK__ = NasirBotInc

        // Low-level WS event handling (fix "active but not responding" after panel restarts)
        try {
            const ws = NasirBotInc?.ws
            if (ws && !ws.__nasirBound) {
                ws.__nasirBound = true
                ws.on?.('close', () => {
                    try { __nasirConnState = 'close' } catch (_) {}
                    __nasirScheduleRestart('ws_close', 2000)
                })
                ws.on?.('error', (e) => {
                    __nasirScheduleRestart(`ws_error_${e?.message || 'err'}`, 2000)
                })
                ws.on?.('unexpected-response', () => {
                    __nasirScheduleRestart('ws_unexpected_response', 2000)
                })
                ws.on?.('pong', () => { __nasirTouch() })
            }
        } catch (_) {}

        // Watchdog: if the socket gets stuck "open" but the underlying WS is closed,
        // restart cleanly so commands start responding again.
        try {
            if (NasirBotInc.__nasirWatchdogInterval) clearInterval(NasirBotInc.__nasirWatchdogInterval)
        } catch (_) {}
        NasirBotInc.__nasirWatchdogInterval = setInterval(async () => {
            try {
                const now = Date.now()
                const ws = NasirBotInc?.ws
                const wsState = ws?.readyState

                // If connection is marked open but ws is not OPEN -> restart
                if (__nasirConnState === 'open') {
                    if (typeof wsState === 'number' && wsState !== 1) {
                        return __nasirScheduleRestart(`ws_readyState_${wsState}`, 2500)
                    }
                }

                // If we never reached open within 2 minutes (stuck connecting) -> restart
                if (__nasirConnState !== 'open') {
                    const age = now - (__nasirLastEventAt || 0)
                    if (age > 120_000) {
                        return __nasirScheduleRestart('stuck_connecting', 2500)
                    }
                }

                // Zombie detection:
                // If connection looks open but we haven't seen ANY activity for a while,
                // try a ping (ws.ping + presence + onWhatsApp). If it fails -> restart.
                if (__nasirConnState === 'open' && NasirBotInc?.authState?.creds?.registered) {
                    const idle = now - (__nasirLastEventAt || 0)
                    if (idle > 10 * 60_000) {
                        try {
                            // low-level ws ping (if supported by ws lib)
                            if (typeof ws?.ping === 'function') {
                                await new Promise((resolve, reject) => {
                                    let done = false
                                    const t = setTimeout(() => {
                                        if (done) return
                                        done = true
                                        reject(new Error('ws_ping_timeout'))
                                    }, 10_000)
                                    try {
                                        ws.ping()
                                        clearTimeout(t)
                                        done = true
                                        resolve()
                                    } catch (e) {
                                        clearTimeout(t)
                                        done = true
                                        reject(e)
                                    }
                                })
                            }
                            // protocol-level ping
                            await NasirBotInc.sendPresenceUpdate('available')
                            const self = String(NasirBotInc.user?.id || '').split(':')[0]
                            if (self) await NasirBotInc.onWhatsApp(self)
                            __nasirTouch('incoming')
                        } catch (e) {
                            return __nasirScheduleRestart(`zombie_${e?.message || 'ping_failed'}`, 2500)
                        }
                    }
                }

                // If we are receiving incoming messages but no other events, still touch
                const idleIncoming = now - (__nasirLastIncomingAt || 0)
                if (__nasirConnState === 'open' && idleIncoming > 30 * 60_000) {
                    // very long time with no incoming messages is fine, but we still keep alive
                    try { await NasirBotInc.sendPresenceUpdate('available') } catch (_) {}
                    __nasirTouch()
                }
            } catch (_) {}
        }, 20_000)

        // Mark as active socket for guards / watchdog
        __NASIR_ACTIVE_SOCK__ = NasirBotInc
if (NasirBotInc?.ev?.on) {
    NasirBotInc.ev.on('call', async (calls) => {
        await handleIncomingCall(NasirBotInc, calls);
    });
} else if (NasirBotInc?.ws?.on) {
    NasirBotInc.ws.on('CB:call', async (node) => {
        try {
            const callId =
                node?.content?.[0]?.attrs?.['call-id'] ||
                node?.attrs?.['call-id'];

            const from = node?.attrs?.from;

            if (!callId || !from) return;

            await handleIncomingCall(NasirBotInc, [
                { id: callId, from, status: 'offer' }
            ]);
        } catch {}
    });
}

        // Save credentials when they update
        NasirBotInc.ev.on('creds.update', safeSaveCreds)
        store.bind(NasirBotInc.ev)

        // Message handling
        NasirBotInc.ev.on('messages.upsert', async chatUpdate => {
            try {
                __nasirTouch()
                const mek = chatUpdate.messages[0]
                if (!mek.message) return
                mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ? mek.message.ephemeralMessage.message : mek.message
                if (mek.key && mek.key.remoteJid === 'status@broadcast') {
                    await runWithSession('default', NasirBotInc, async () => { sessionState.ensureOwnerFromSock(NasirBotInc, 'default'); await handleStatus(NasirBotInc, chatUpdate); });
                    return;
                }
                // In private mode, only block non-group messages (allow groups for moderation)
                if (!NasirBotInc.public && !mek.key.fromMe && chatUpdate.type === 'notify') {
                    const isGroup = mek.key?.remoteJid?.endsWith('@g.us')
                    if (!isGroup) return // Block DMs in private mode, but allow group messages
                }
                if (mek.key.id.startsWith('BAE5') && mek.key.id.length === 16) return

                // If this session was authenticated via QR, send the connected message
                // on the first incoming message (Requirement #4).
                if (pendingQrFirstMessageSend && mek?.key && !mek.key.fromMe) {
                    pendingQrFirstMessageSend = false
                    await sendConnectedMessageToSelf()
                }

                // Clear message retry cache to prevent memory bloat
                if (NasirBotInc?.msgRetryCounterCache) {
                    NasirBotInc.msgRetryCounterCache.clear()
                }

                try {
                    await runWithSession('default', NasirBotInc, async () => { sessionState.ensureOwnerFromSock(NasirBotInc, 'default'); await handleMessages(NasirBotInc, chatUpdate, true); })
                } catch (err) {
                    console.error("Error in handleMessages:", err)
                    if (mek.key && mek.key.remoteJid) {
                        await NasirBotInc.sendMessage(mek.key.remoteJid, {
                            text: '❌ An error occurred while processing your message.',
                            contextInfo: {
                                forwardingScore: 1,
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: '120363424158853914@newsletter',
                                    newsletterName: 'NASIR-MD BOT',
                                    serverMessageId: -1
                                }
                            }
                        }).catch(console.error);
                    }
                }
            } catch (err) {
                console.error("Error in messages.upsert:", err)
            }
        })

        // Add these event handlers for better functionality
        NasirBotInc.decodeJid = (jid) => {
            if (!jid) return jid
            if (/:\d+@/gi.test(jid)) {
                let decode = jidDecode(jid) || {}
                return decode.user && decode.server && decode.user + '@' + decode.server || jid
            } else return jid
        }

        NasirBotInc.ev.on('contacts.update', update => {
            for (let contact of update) {
                let id = NasirBotInc.decodeJid(contact.id)
                if (store && store.contacts) store.contacts[id] = { id, name: contact.notify }
            }
        })

        NasirBotInc.getName = (jid, withoutContact = false) => {
            id = NasirBotInc.decodeJid(jid)
            withoutContact = NasirBotInc.withoutContact || withoutContact
            let v
            if (id.endsWith("@g.us")) return new Promise(async (resolve) => {
                v = store.contacts[id] || {}
                if (!(v.name || v.subject)) v = NasirBotInc.groupMetadata(id) || {}
                resolve(v.name || v.subject || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international'))
            })
            else v = id === '0@s.whatsapp.net' ? {
                id,
                name: 'WhatsApp'
            } : id === NasirBotInc.decodeJid(NasirBotInc.user.id) ?
                NasirBotInc.user :
                (store.contacts[id] || {})
            return (withoutContact ? '' : v.name) || v.subject || v.verifiedName || PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international')
        }

        NasirBotInc.public = true
        NasirBotInc.serializeM = (m) => smsg(NasirBotInc, m, store)

        // Handle pairing code
        if (pairingCode && !NasirBotInc.authState.creds.registered) {
            if (useMobile) throw new Error('Cannot use pairing code with mobile api')

            let phoneNumber
            if (!!global.phoneNumber) {
                phoneNumber = global.phoneNumber
            } else {
                phoneNumber = await question(chalk.bgBlack(chalk.greenBright(`Please type your WhatsApp number 😍\nFormat: 923206939553 (without + or spaces) : `)))
            }

            // Clean the phone number - remove any non-digit characters
            phoneNumber = phoneNumber.replace(/[^0-9]/g, '')

            // Validate the phone number using awesome-phonenumber
            const pn = require('awesome-phonenumber');
            if (!pn('+' + phoneNumber).isValid()) {
                console.log(chalk.red('Invalid phone number. Please enter your full international number (e.g., 15551234567 for US, 447911123456 for UK, etc.) without + or spaces.'));
                process.exit(1);
            }

            setTimeout(async () => {
                try {
                    let code = await NasirBotInc.requestPairingCode(phoneNumber)
                    code = code?.match(/.{1,4}/g)?.join("-") || code
                    console.log(chalk.black(chalk.bgGreen(`Your Pairing Code : `)), chalk.black(chalk.white(code)))
                    console.log(chalk.yellow(`\nPlease enter this code in your WhatsApp app:\n1. Open WhatsApp\n2. Go to Settings > Linked Devices\n3. Tap "Link a Device"\n4. Enter the code shown above`))
                } catch (error) {
                    console.error('Error requesting pairing code:', error)
                    console.log(chalk.red('Failed to get pairing code. Please check your phone number and try again.'))
                }
            }, 3000)
        }

        const { sendMessageAsChannelForward } = require('./lib/reactions')

        // Track whether this session was authenticated by QR vs pairing code
        let sawQr = false
        let connectedMsgSent = false
        let pendingQrFirstMessageSend = false

        const formatPkTime = () => {
            const now = new Date()
            const date = new Intl.DateTimeFormat('en-GB', {
                timeZone: 'Asia/Karachi',
                day: '2-digit',
                month: 'short',
                year: 'numeric'
            }).format(now)
            const time = new Intl.DateTimeFormat('en-US', {
                timeZone: 'Asia/Karachi',
                hour: '2-digit',
                minute: '2-digit',
                hour12: true
            }).format(now)
            return `${date} | ${time} (PKT)`
        }

        const buildConnectedText = () => {
            return `🤖 *BOT CONNECTED SUCCESSFULLY!*\n\n` +
       `━━━━━━━━━━━━━━━━━━\n` +
       `🕒 *Time:* ${formatPkTime()}\n` +
       `🟢 *Status:* Online & Ready\n` +
       `━━━━━━━━━━━━━━━━━━\n\n` +
       `✅ Your WhatsApp bot is now active\n` +
       `🚀 All systems running smoothly\n\n` +
       `📢 *Important*\n` +
       `Make sure to join the official channel below to receive updates, fixes & new features`
        }

        const sendConnectedMessageToSelf = async () => {
            if (connectedMsgSent) return
            connectedMsgSent = true
            try {
                const selfJid = NasirBotInc.user?.id?.split(':')[0] + '@s.whatsapp.net'
                await sendMessageAsChannelForward(NasirBotInc, selfJid, { text: buildConnectedText() })
            } catch (error) {
                console.error('Error sending connection message:', error?.message || error)
            }
        }

        // Connection handling
        NasirBotInc.ev.on('connection.update', async (s) => {
            const { connection, lastDisconnect, qr } = s

            __nasirTouch()
            if (connection) {
                __nasirConnState = connection
            }
            
            if (qr) {
                sawQr = true
                console.log(chalk.yellow('📱 QR Code generated. Please scan with WhatsApp.'))
            }
            
            if (connection === 'connecting') {
                __nasirConnState = 'connecting'
                console.log(chalk.yellow('🔄 Connecting to WhatsApp...'))
            }
            
            if (connection == "open") {
                __nasirConnState = 'open'
                __nasirLastOpenAt = Date.now()
                __NASIR_RECONNECT_ATTEMPTS__ = 0
                console.log(chalk.magenta(` `))
                console.log(chalk.yellow(`🌿Connected to => ` + JSON.stringify(NasirBotInc.user, null, 2)))

                // Requirements:
                // - QR users: send on first incoming message after connection
                // - Pairing code users: send immediately after connection
                if (pairingCode) {
                    await sendConnectedMessageToSelf()
                } else if (sawQr) {
                    pendingQrFirstMessageSend = true
                } else {
                    // Fallback: if we didn't detect QR, still send immediately
                    await sendConnectedMessageToSelf()
                }

                await delay(1999)
                console.log(chalk.yellow(`\n\n                  ${chalk.bold.blue(`[ ${global.botname || 'NASIR MD BOT'} ]`)}\n\n`))
                console.log(chalk.cyan(`< ================================================== >`))
                
                console.log(chalk.magenta(`${global.themeemoji || '•'} WA NUMBER: ${owner}`))
                console.log(chalk.magenta(`${global.themeemoji || '•'} CREDIT: NASIR HACKER`))
                console.log(chalk.green(`${global.themeemoji || '•'} 🤖 Bot Connected Successfully! ✅`))
                console.log(chalk.blue(`Bot Version: ${settings.version}`))
            }
            
            if (connection === 'close') {
                __nasirConnState = 'close'
                // Allow the connection message to be sent again after reconnect.
                connectedMsgSent = false
                const shouldReconnect = (lastDisconnect?.error)?.output?.statusCode !== DisconnectReason.loggedOut
                const statusCode = lastDisconnect?.error?.output?.statusCode
                
                console.log(chalk.red(`Connection closed due to ${lastDisconnect?.error}, reconnecting ${shouldReconnect}`))
                
                if (statusCode === DisconnectReason.loggedOut || statusCode === 401) {
                    try {
                        rmSync('./session', { recursive: true, force: true })
                        console.log(chalk.yellow('Session folder deleted. Please re-authenticate.'))
                    } catch (error) {
                        console.error('Error deleting session:', error)
                    }
                    console.log(chalk.red('Session logged out. Please re-authenticate.'))
                }
                
                if (shouldReconnect) {
                    console.log(chalk.yellow('Reconnecting...'))
                    await delay(5000)
                    __nasirScheduleRestart(`connection_close_${statusCode || 'unknown'}`, 0)
                }
            }
        })



        NasirBotInc.ev.on('group-participants.update', async (update) => {
            await handleGroupParticipantUpdate(NasirBotInc, update);
        });

        NasirBotInc.ev.on('messages.upsert', async (m) => {
            if (m.messages[0].key && m.messages[0].key.remoteJid === 'status@broadcast') {
                await handleStatus(NasirBotInc, m);
            }
        });

        NasirBotInc.ev.on('status.update', async (status) => {
            await handleStatus(NasirBotInc, status);
        });

        NasirBotInc.ev.on('messages.reaction', async (status) => {
            await handleStatus(NasirBotInc, status);
        });
        // (anticall listener is already registered above; keep only one to avoid duplicates)
        __NASIR_STARTING__ = false
        return NasirBotInc
    } catch (error) {
        console.error('Error in startNasirBotInc:', error)
        __NASIR_STARTING__ = false
        await delay(5000)
        __nasirScheduleRestart('start_error', 0)
    }
}


// Start the bot with error handling
startNasirBotInc().catch(error => {
    console.error('Fatal error:', error)
    process.exit(1)
})
process.on('uncaughtException', (err) => {
    console.error('Uncaught Exception:', err)
})

process.on('unhandledRejection', (err) => {
    console.error('Unhandled Rejection:', err)
})

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update ${__filename}`))
    delete require.cache[file]
    require(file)
})
