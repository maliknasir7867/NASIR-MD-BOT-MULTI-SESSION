const settings = {
  packname: 'NASIR HACKER',
  author: '‎',
  botName: "𝐍𝐀𝐒𝐈𝐑-𝐌𝐃 𝐁𝐎𝐓",
  botOwner: '𝐍𝐀𝐒𝐈𝐑 𝐇𝐀𝐂𝐊𝐄𝐑', // Your name
  ownerNumber: '923206939553', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  maxStoreMessages: 20, 
  storeWriteInterval: 10000,
  description: "This is a bot for managing group commands and automating tasks.",
  version: "2.0.4",
  updateZipUrl: "https://github.com/mruniquehacker/Knightbot-MD/archive/refs/heads/main.zip",

  // Channel link shown in the "Bot Connected Successfully" message.
  // Set via env CHANNEL_LINK to avoid hard-coding.
  channelLink: process.env.CHANNEL_LINK || '[Channel Link]',
};

module.exports = settings;
