// encrypt.js
// Command: .encrypt <type> <message>
// Supported: base64, hex, url, rot13, binary, reverse
// Channel Forwarded Appearance Enabled

module.exports = async function encryptCommand(sock, chatId, message, rawText) {
    try {
        const args = rawText.trim().split(/\s+/).slice(1);

        if (args.length < 2) {
            return await sock.sendMessage(chatId, {
                text: `🔐 *Encryption Usage Guide*

✨ *Correct Format:*
.encrypt base64 <your_message>

⚠️ Example:
.encrypt base64 hello world`,
                contextInfo: {
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: "120363404049028072@newsletter",
                        newsletterName: "NASIR-MD BOT",
                        serverMessageId: -1
                    }
                }
            }, { quoted: message });
        }

        const type = args.shift().toLowerCase();
        const input = args.join(" ");
        let encoded = "";

        // BASE64
        if (type === "base64") {
            encoded = Buffer.from(input, "utf8").toString("base64");
        }

        // HEX
        else if (type === "hex") {
            encoded = Buffer.from(input, "utf8").toString("hex");
        }

        // URL ENCODE
        else if (type === "url") {
            encoded = encodeURIComponent(input);
        }

        // ROT13
        else if (type === "rot13") {
            encoded = input.replace(/[a-zA-Z]/g, c =>
                String.fromCharCode(
                    (c <= 'Z' ? 90 : 122) >= (c = c.charCodeAt(0) + 13)
                        ? c
                        : c - 26
                )
            );
        }

        // BINARY
        else if (type === "binary") {
            encoded = input
                .split('')
                .map(c => c.charCodeAt(0).toString(2).padStart(8, '0'))
                .join(' ');
        }

        // REVERSE
        else if (type === "reverse") {
            encoded = input.split('').reverse().join('');
        }

        // UNSUPPORTED
        else {
            return await sock.sendMessage(chatId, {
                text: `❌ *Unsupported encryption type*

👉 Supported: base64, hex, url, rot13, binary, reverse

Try:
.encrypt base64 hello world`,
                contextInfo: {
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: "120363404049028072@newsletter",
                        newsletterName: "NASIR-MD BOT",
                        serverMessageId: -1
                    }
                }
            }, { quoted: message });
        }

        // SUCCESS MESSAGE (with channel forwarded look)
        return await sock.sendMessage(chatId, {
            text: `🔐 *Encryption Successful!*

📄 *Original:* ${input}
🔒 *Encrypted:* ${encoded}

✨ Use *.decrypt* to decode it back!`,
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: "120363404049028072@newsletter",
                    newsletterName: "NASIR-MD BOT",
                    serverMessageId: -1
                }
            }
        }, { quoted: message });

    } catch (err) {
        console.error("ENCRYPT ERROR:", err);
        return await sock.sendMessage(chatId, {
            text: "⚠️ Encryption failed due to an internal error.",
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: "120363404049028072@newsletter",
                    newsletterName: "NASIR-MD BOT",
                    serverMessageId: -1
                }
            }
        }, { quoted: message });
    }
};
