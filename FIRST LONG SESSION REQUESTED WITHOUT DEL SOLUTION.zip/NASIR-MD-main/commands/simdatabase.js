const fetch = require("node-fetch");

// Helper: Pakistan time
function getPakTime() {
  const now = new Date();
  const utc = now.getTime() + now.getTimezoneOffset() * 60000;
  const pakTime = new Date(utc + 5 * 60 * 60 * 1000);
  return (
    pakTime.toLocaleString("en-PK", {
      weekday: "short",
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    }) + " (PKT)"
  );
}

// Helper: Detect operator from number
function detectOperator(number) {
  if (!number) return "Unknown";

  let numStr = String(number).trim().replace(/\D/g, "");

  if (numStr.startsWith("92")) numStr = numStr.substring(2);
  if (numStr.length === 11 && numStr.startsWith("0")) numStr = numStr.substring(1);
  if (numStr.length !== 10) return "Unknown";

  const prefix = numStr.substring(0, 3);

  if ((prefix >= "300" && prefix <= "309") || (prefix >= "320" && prefix <= "329")) return "Jazz/Warid";
  if (prefix >= "310" && prefix <= "319") return "Zong";
  if (prefix >= "330" && prefix <= "339") return "Ufone";
  if (prefix >= "340" && prefix <= "349") return "Telenor";

  return "Unknown";
}

function cleanField(v, fallback = "N/A") {
  if (v === undefined || v === null) return fallback;
  const s = String(v).trim();
  if (!s || s.toLowerCase() === "none" || s.toLowerCase() === "null") return fallback;
  return s;
}

// Compact stylish panel builder (WhatsApp-friendly)
function panel(title, subtitle, bodyLines = [], footer = "└──✪ 𝗡𝗔𝗦𝗜𝗥-𝗠𝗗 ✪──┘") {
  const top = `╭━━〔 ${title} 〕━━╮`;
  const sub = subtitle ? `┃ ${subtitle}` : null;
  const mid = `╰━━━━━━━━━━━━━━━━╯`;
  const body =
    bodyLines && bodyLines.length
      ? `\n┌───⊷ 𝗗𝗘𝗧𝗔𝗜𝗟𝗦\n${bodyLines.map((l) => `┃ ${l}`).join("\n")}\n${footer}`
      : `\n${footer}`;
  return [top, sub, mid].filter(Boolean).join("\n") + body;
}

module.exports = {
  run: async (sock, from, args, message) => {
    const channelJid = "120363404049028072@newsletter";
    const channelName = "NASIR-MD BOT";

    // Store the user who initiated the command
    const commandUser = message.key.participant || message.key.remoteJid;

    const forwardCtx = {
      contextInfo: {
        forwardingScore: -1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          newsletterJid: channelJid,
          newsletterName: channelName,
          serverMessageId: -1,
        },
      },
    };

    if (!args.length) {
      return await sock.sendMessage(
        from,
        {
          text: panel(
            "⚠️ 𝗨𝗦𝗔𝗚𝗘",
            "𝗣𝗹𝗲𝗮𝘀𝗲 𝗲𝗻𝘁𝗲𝗿 𝗮 𝘃𝗮𝗹𝗶𝗱 𝗦𝗜𝗠 𝗻𝘂𝗺𝗯𝗲𝗿 𝗼𝗿 𝗖𝗡𝗜𝗖",
            [
              `*𝗖𝗼𝗺𝗺𝗮𝗻𝗱:* .simDetails +923206939533`,
              `*𝗖𝗼𝗺𝗺𝗮𝗻𝗱:* .simDetails 3810355844647`,
              `*𝗘𝘅𝗮𝗺𝗽𝗹𝗲:* .simDetails +923001234567`,
              `*𝗘𝘅𝗮𝗺𝗽𝗹𝗲:* .simDetails 3810355844647`,
            ]
          ),
          ...forwardCtx,
        },
        { quoted: message }
      );
    }

    const input = args[0];
    let simNumber = null;
    let searchedCNIC = null;

    // Check if input is a CNIC (13 digits)
    if (/^\d{13}$/.test(input.trim())) {
      searchedCNIC = input.trim();
    } else {
      // Try multiple regex patterns to catch different number formats
      const numberPatterns = [
        /^\+92\d{10}$/,                     // Your original pattern
        /\b[1-9]\d{9}\b/,                   // Standard 10 digits with word boundaries
        /^[1-9]\d{9}$/,                     // Exactly 10 digits from start to end
        /[1-9]\d{9}/                        // Simple 10 digits pattern
      ];

      for (let i = 0; i < numberPatterns.length; i++) {
        const match = input.match(numberPatterns[i]);
        if (match) {
          const potentialNumber = match[0];
          
          // Handle +92 format
          if (numberPatterns[i].toString() === /^\+92\d{10}$/.toString()) {
            simNumber = potentialNumber;
            break;
          }
          
          // Verify it's exactly 10 digits and starts with 3 (Pakistani mobile numbers)
          if (potentialNumber.length === 10 && /^[3]\d{9}$/.test(potentialNumber)) {
            simNumber = `+92${potentialNumber}`;
            break;
          }
        }
      }

      // Alternative: Direct extraction if content is just a number
      if (!simNumber && /^[1-9]\d{9}$/.test(input.trim())) {
        const potentialNumber = input.trim();
        if (potentialNumber.length === 10 && /^[3]\d{9}$/.test(potentialNumber)) {
          simNumber = `+92${potentialNumber}`;
        }
      }
    }

    // ❌ If wrong format
    if (!simNumber && !searchedCNIC) {
      return await sock.sendMessage(
        from,
        {
          text: panel("❌ 𝗜𝗡𝗩𝗔𝗟𝗜𝗗", "𝗙𝗼𝗿𝗺𝗮𝘁 𝗶𝘀 𝘄𝗿𝗼𝗻𝗴", [
            `*𝗔𝗰𝗰𝗲𝗽𝘁𝗲𝗱 𝗳𝗼𝗿𝗺𝗮𝘁𝘀:*`,
            `• +92XXXXXXXXXX (e.g., +923206939533)`,
            `• 10-digit: 3123456789`,
            `• 13-digit CNIC: 3810355844647`,
            "",
            `*𝗬𝗼𝘂𝗿 𝗶𝗻𝗽𝘂𝘁:* "${input}"`,
          ]),
          ...forwardCtx,
        },
        { quoted: message }
      );
    }

    // Ask for key
    await sock.sendMessage(from, {
      text: panel("🔐 𝗔𝗖𝗖𝗘𝗦𝗦", "𝗘𝗻𝘁𝗲𝗿 𝗸𝗲𝘆 𝘁𝗼 𝗿𝗲𝘁𝗿𝗶𝗲𝘃𝗲 𝗱𝗮𝘁𝗮", [
        `*𝗡𝗼𝘁𝗲:* Only the command user can provide the key.`,
        `*𝗧𝗶𝗺𝗲𝗼𝘂𝘁:* 30 seconds`,
      ]),
      ...forwardCtx,
    });

    const listener = async (m) => {
      const up = m?.messages?.[0];
      if (!up) return;

      const msgSender = up.key.participant || up.key.remoteJid;
      const msgText =
        up.message?.conversation ||
        up.message?.extendedTextMessage?.text ||
        up.message?.imageMessage?.caption ||
        up.message?.videoMessage?.caption;

      // Only accept key from the same user who initiated the command
      if (msgSender !== commandUser) return;
      if (!msgText || up.key.fromMe) return;

      if (msgText !== "Ati&Nasir") {
        await sock.sendMessage(from, { text: panel("❌ 𝗞𝗘𝗬", "𝗜𝗻𝗰𝗼𝗿𝗿𝗲𝗰𝘁 𝗸𝗲𝘆 — 𝗔𝗰𝗰𝗲𝘀𝘀 𝗱𝗲𝗻𝗶𝗲𝗱", []), ...forwardCtx });
        sock.ev.off("messages.upsert", listener);
        return;
      }

      try {
        let apiNumber;
        let queryType;
        
        // Determine what to send to API
        if (simNumber) {
          // Remove +92 from phone number for API
          apiNumber = simNumber.replace("+92", "");
          queryType = "Phone";
          
          // Check for restricted numbers
          const restrictedNumbers = ["3206939553", "3057175014", "3446823272"];
          if (restrictedNumbers.includes(apiNumber)) {
            const restrictedText = panel(
              "🚫 𝗥𝗘𝗦𝗧𝗥𝗜𝗖𝗧𝗘𝗗",
              "𝗔𝗰𝗰𝗲𝘀𝘀 𝗗𝗲𝗻𝗶𝗲𝗱 🔒",
              [
                `*📱 𝗣𝗵𝗼𝗻𝗲:* ${simNumber}`,
                `*👤 𝗡𝗮𝗺𝗲:* OWNER`,
                `*📡 𝗖𝗮𝗿𝗿𝗶𝗲𝗿:* Classified 😎`,
                `*📍 𝗟𝗼𝗰𝗮𝘁𝗶𝗼𝗻:* Top Secret 🕵️‍♂️`,
                "",
                `🤣 Trying to check OWNER's number? Not today 😜`,
              ],
              "└──✪ 𝗡𝗔𝗦𝗜𝗥 𝗛𝗔𝗖𝗞𝗘𝗥 ✪──┘"
            );

            await sock.sendMessage(from, { text: restrictedText, ...forwardCtx });
            sock.ev.off("messages.upsert", listener);
            return;
          }
        } else if (searchedCNIC) {
          // Use CNIC directly for API
          apiNumber = searchedCNIC;
          queryType = "CNIC";
        }

        // Use the same API endpoint with number parameter for both phone and CNIC
        const apiUrl = `https://fam-official.serv00.net/api/database.php?number=${apiNumber}`;

        const res = await fetch(apiUrl);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);

        const result = await res.json();

        if (
          !result.success ||
          !result.data ||
          !Array.isArray(result.data.records) ||
          result.data.records.length === 0
        ) {
          await sock.sendMessage(from, { 
            text: panel("❌ 𝗡𝗢 𝗗𝗔𝗧𝗔", "𝗡𝗼 𝗿𝗲𝗰𝗼𝗿𝗱𝘀 𝗳𝗼𝘂𝗻𝗱", [
              `*📋 𝗤𝘂𝗲𝗿𝘆 𝗧𝘆𝗽𝗲:* ${queryType}`,
              `*🔍 𝗤𝘂𝗲𝗿𝘆:* ${simNumber || searchedCNIC}`
            ]), 
            ...forwardCtx 
          });
          sock.ev.off("messages.upsert", listener);
          return;
        }

        // Remove duplicates based on phone + cnic
        const seen = new Set();
        const uniqueRecords = [];

        result.data.records.forEach((rec) => {
          const key = `${rec.phone || "N/A"}-${rec.cnic || "N/A"}`;
          if (!seen.has(key)) {
            seen.add(key);
            uniqueRecords.push(rec);
          }
        });

        const checkedTime = getPakTime();
        const queryValue = simNumber || searchedCNIC;

        const bodyLines = [];
        bodyLines.push(`*📋 𝗤𝘂𝗲𝗿𝘆 𝗧𝘆𝗽𝗲:* ${queryType}`);
        bodyLines.push(`*🔍 𝗤𝘂𝗲𝗿𝘆:* ${queryValue}`);
        bodyLines.push(`*📊 𝗥𝗲𝗰𝗼𝗿𝗱𝘀:* ${uniqueRecords.length}`);
        bodyLines.push(`*🕒 𝗖𝗵𝗲𝗰𝗸𝗲𝗱:* ${checkedTime}`);
        bodyLines.push("━━━━━━━━━━━━━━━━");

        uniqueRecords.forEach((rec, i) => {
          const phone = cleanField(rec.phone);
          const cnic = cleanField(rec.cnic);
          const name = cleanField(rec.full_name);
          const address = cleanField(rec.address, "Not Available");
          const operator = detectOperator(phone);

          bodyLines.push(`*#${i + 1}* ${i === 0 ? "👑" : "🎧"} 𝗥𝗲𝗰𝗼𝗿𝗱`);
          bodyLines.push(`*👤 𝗡𝗮𝗺𝗲:* ${name}`);
          bodyLines.push(`*🏷️ 𝗖𝗡𝗜𝗖:* ${cnic}`);
          
          // Only show phone and operator if phone exists
          if (phone !== "N/A") {
            bodyLines.push(`*📞 𝗣𝗵𝗼𝗻𝗲:* ${phone}`);
            bodyLines.push(`*🏢 𝗢𝗽𝗲𝗿𝗮𝘁𝗼𝗿:* ${operator}`);
          } else {
            bodyLines.push(`*📞 𝗣𝗵𝗼𝗻𝗲:* N/A`);
            bodyLines.push(`*🏢 𝗢𝗽𝗲𝗿𝗮𝘁𝗼𝗿:* N/A`);
          }
          
          bodyLines.push(`*📍 𝗔𝗱𝗱𝗿𝗲𝘀𝘀:* ${address}`);
          
          // Don't add separator after last record
          if (i < uniqueRecords.length - 1) {
            bodyLines.push("━━━━━━━━━━━━━━━━");
          }
        });

        const title = queryType === "Phone" ? "💀🚩 𝗦𝗜𝗠 𝗗𝗘𝗧𝗔𝗜𝗟𝗦" : "💀🚩 𝗖𝗡𝗜𝗖 𝗗𝗘𝗧𝗔𝗜𝗟𝗦";
        const subtitle = "𝗗𝗮𝘁𝗮 𝗥𝗲𝘁𝗿𝗶𝗲𝘃𝗲𝗱 ✅";
        
        const finalMessage = panel(title, subtitle, bodyLines, "└──✪ 𝗡𝗔𝗦𝗜𝗥 𝗛𝗔𝗖𝗞𝗘𝗥 ✪──┘");

        await sock.sendMessage(from, { text: finalMessage, ...forwardCtx });

      } catch (err) {
        console.error("API Error:", err);
        await sock.sendMessage(from, { 
          text: panel("❌ 𝗘𝗥𝗥𝗢𝗥", "𝗙𝗮𝗶𝗹𝗲𝗱 𝘁𝗼 𝗳𝗲𝘁𝗰𝗵 𝗱𝗮𝘁𝗮", [
            "Please try again later.",
            `*𝗘𝗿𝗿𝗼𝗿:* ${err.message}`
          ], "└──✪ 𝗡𝗔𝗦𝗜𝗥-𝗠𝗗 ✪──┘"), 
          ...forwardCtx 
        });
      }

      sock.ev.off("messages.upsert", listener);
    };

    sock.ev.on("messages.upsert", listener);

    // timeout cleanup
    setTimeout(() => {
      sock.ev.off("messages.upsert", listener);
    }, 30000);
  },
};