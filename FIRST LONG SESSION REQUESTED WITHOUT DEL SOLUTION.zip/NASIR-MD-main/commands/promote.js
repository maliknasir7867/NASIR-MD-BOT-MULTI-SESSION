const { isAdmin } = require('../lib/isAdmin');

// Set Pakistani time (UTC+5)
const PAKISTAN_TIME_OPTIONS = {
    timeZone: 'Asia/Karachi',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: true
};

// Get current Pakistani time
function getPakistanTime() {
    return new Date().toLocaleString('en-PK', PAKISTAN_TIME_OPTIONS);
}

// TEMPLATE OPTIONS - Choose the one you like
const TEMPLATES = {
    // Template 1: Minimal Modern
    MINIMAL: (usernames, promoter, count, participants, authorJid) => 
        `🌟 *Promotion Update*\n\n` +
        `👥 *New Admin${count > 1 ? 's' : ''}:*\n` +
        `${usernames.map(name => `• ${name}`).join('\n')}\n\n` +
        `👑 *Promoted By:* ${promoter}\n` +
        `📅 *Date:* ${getPakistanTime()}`,

    // Template 2: Stylish Box Design
    BOX_DESIGN: (usernames, promoter, count, participants, authorJid) => 
        `╔═══════════════════╗\n` +
        `║   🚀 PROMOTION    ║\n` +
        `╚═══════════════════╝\n\n` +
        `📌 *New Admin${count > 1 ? 's' : ''}:*\n` +
        `${usernames.map(name => `  └─ ${name}`).join('\n')}\n\n` +
        `👤 *Promoted By:* ${promoter}\n` +
        `🕐 *Time:* ${getPakistanTime()}\n` +
        `📅 *Date:* ${new Date().toLocaleDateString('en-PK', { timeZone: 'Asia/Karachi' })}`,

    // Template 3: Professional
    PROFESSIONAL: (usernames, promoter, count, participants, authorJid) => 
        `📢 *Administrative Promotion*\n\n` +
        `**New Administrator${count > 1 ? 's' : ''}:**\n` +
        `${usernames.map(name => `✓ ${name}`).join('\n')}\n\n` +
        `**Promoted By:** ${promoter}\n` +
        `**Promotion Date:** ${getPakistanTime()}\n\n` +
        `_Congratulations on your new role!_`,

    // Template 4: Decorative
    DECORATIVE: (usernames, promoter, count, participants, authorJid) => 
        `✧･ﾟ: *✧･ﾟ:* PROMOTION *:･ﾟ✧:･ﾟ✧*\n\n` +
        `🎖️ *New Admin${count > 1 ? 's' : ''}:*\n` +
        `${usernames.map(name => `» ${name}`).join('\n')}\n\n` +
        `👑 *Promoted By:* ${promoter}\n` +
        `⏰ *Pakistan Time:* ${getPakistanTime()}\n\n` +
        `✨ _New powers unlocked!_ ✨`,

    // Template 5: Simple Clean
    SIMPLE: (usernames, promoter, count, participants, authorJid) => 
        `*Promotion Notification*\n\n` +
        `📋 *Users Promoted:* ${count}\n` +
        `👥 *Promoted Users:*\n${usernames.map(name => `- ${name}`).join('\n')}\n\n` +
        `👤 *Promoted By:* ${promoter}\n` +
        `⏳ *Time (PKT):* ${getPakistanTime()}\n` +
        `✅ *Status:* Successfully Promoted`
};

// Current template - CHANGE THIS TO YOUR PREFERRED TEMPLATE
const CURRENT_TEMPLATE = 'BOX_DESIGN'; // ← Change this to your preferred template

// Function to handle manual promotions via command
async function promoteCommand(sock, chatId, mentionedJids, message) {
    let userToPromote = [];
    
    // Check for mentioned users
    if (mentionedJids && mentionedJids.length > 0) {
        userToPromote = mentionedJids;
    }
    // Check for replied message
    else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
        userToPromote = [message.message.extendedTextMessage.contextInfo.participant];
    }
    
    // If no user found through either method
    if (userToPromote.length === 0) {
        await sock.sendMessage(chatId, { 
            text: 'Please mention the user or reply to their message to promote!'
        });
        return;
    }

    try {
        await sock.groupParticipantsUpdate(chatId, userToPromote, "promote");
        
        // Get usernames for each promoted user
        const usernames = await Promise.all(userToPromote.map(async jid => {
            try {
                const contact = await sock.onWhatsApp(jid);
                if (contact && contact[0] && contact[0].exists) {
                    return `@${jid.split('@')[0]}`;
                }
                return `@${jid.split('@')[0]}`;
            } catch (error) {
                return `@${jid.split('@')[0]}`;
            }
        }));

        // Get promoter's name (admin who used the command)
        const promoterJid = sock.user.id;
        const promoterName = `@${promoterJid.split('@')[0]}`;

        // Get template message
        const promotionMessage = TEMPLATES[CURRENT_TEMPLATE](
            usernames,
            promoterName,
            userToPromote.length,
            userToPromote,
            promoterJid
        );

        await sock.sendMessage(chatId, { 
            text: promotionMessage,
            mentions: [...userToPromote, promoterJid]
        });
    } catch (error) {
        console.error('Error in promote command:', error);
        await sock.sendMessage(chatId, { 
            text: 'Failed to promote user(s)!' 
        });
    }
}

// Function to handle automatic promotion detection
async function handlePromotionEvent(sock, groupId, participants, author) {
    try {
        // Safety check for participants
        if (!Array.isArray(participants) || participants.length === 0) {
            return;
        }

        // Get usernames for promoted participants
        const promotedUsernames = await Promise.all(participants.map(async jid => {
            const jidString = typeof jid === 'string' ? jid : (jid.id || jid.toString());
            try {
                return `@${jidString.split('@')[0]}`;
            } catch (error) {
                return `@${jidString.split('@')[0]}`;
            }
        }));

        let promotedBy = 'System';
        let mentionList = participants.map(jid => {
            return typeof jid === 'string' ? jid : (jid.id || jid.toString());
        });

        // FIXED: Properly extract the admin who promoted
        if (author) {
            const authorJid = typeof author === 'string' ? author : (author.id || author.toString());
            
            try {
                // Try to get user info to display proper name
                const [contact] = await sock.onWhatsApp(authorJid);
                if (contact && contact.exists) {
                    // Try to get pushname (display name)
                    const metadata = await sock.groupMetadata(groupId);
                    const participant = metadata.participants.find(p => p.id === authorJid);
                    
                    if (participant && participant.notify) {
                        promotedBy = `@${authorJid.split('@')[0]}`; // Display with @mention
                    } else {
                        promotedBy = `@${authorJid.split('@')[0]}`;
                    }
                } else {
                    promotedBy = `@${authorJid.split('@')[0]}`;
                }
                
                // Add author to mention list if not already
                if (!mentionList.includes(authorJid)) {
                    mentionList.push(authorJid);
                }
            } catch (error) {
                console.error('Error getting promoter info:', error);
                promotedBy = `@${author.split('@')[0]}`;
            }
        }

        // Get template message
        const promotionMessage = TEMPLATES[CURRENT_TEMPLATE](
            promotedUsernames,
            promotedBy,
            participants.length,
            participants,
            author
        );

        await sock.sendMessage(groupId, {
            text: promotionMessage,
            mentions: mentionList
        });
    } catch (error) {
        console.error('Error handling promotion event:', error);
    }
}

module.exports = { promoteCommand, handlePromotionEvent };