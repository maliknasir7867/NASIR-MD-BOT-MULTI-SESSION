const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

async function viewonceCommand(sock, chatId, message) {
    try {
        const channelJid = "120363404049028072@newsletter";
        const channelName = "NASIR-MD BOT";

        const botName =
            (global?.settings && global.settings.botName) ||
            (typeof settings !== 'undefined' && settings?.botName) ||
            "NASIR-MD";

        const quoted =
            message?.message?.extendedTextMessage?.contextInfo?.quotedMessage;

        const unwrapViewOnce = (msg) => {
            if (!msg) return null;
            return (
                msg?.viewOnceMessage?.message ||
                msg?.viewOnceMessageV2?.message ||
                msg?.viewOnceMessageV2Extension?.message ||
                msg
            );
        };

        const unwrapped = unwrapViewOnce(quoted);

        const quotedImage = unwrapped?.imageMessage;
        const quotedVideo = unwrapped?.videoMessage;
        const quotedAudio = unwrapped?.audioMessage;

        const forwardedCtx = {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: channelJid,
                newsletterName: channelName,
                serverMessageId: -1
            }
        };

        const downloadToBuffer = async (mediaMsg, type) => {
            const stream = await downloadContentFromMessage(mediaMsg, type);
            let buffer = Buffer.from([]);
            for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
            return buffer;
        };

        const COMMON_CAPTION =
"╭━━━〔 🔓 *ONCE VIEW UNLOCKED* 〕━━━┈⊷\n" +
"╔═══════◇◆◇═══════╗\n" +
"『 ✨ 𝗠𝗘𝗗𝗜𝗔 𝗣𝗥𝗢𝗖𝗘𝗦𝗦𝗘𝗗 ✨ 』\n" +
"╚═══════◇◆◇═══════╝\n" +
"⟬★⟭────────────────\n" +
"⟬★⟭ 𝗦𝗧𝗔𝗧𝗨𝗦 𝗥𝗘𝗣𝗢𝗥𝗧\n" +
"⟬★⟭────────────────\n" +
"│ 🔓  Type » *View Once*\n" +
"│ ⚡  State » *Bypassed*\n" +
"│ 🧠  Bot   » *NASIR-MD*\n" +
"⟬★⟭─────────────────\n\n" +
"╔═══◇◆◇════════════╗\n" +
"『 🔐 𝗦𝗘𝗖𝗨𝗥𝗜𝗧𝗬 𝗡𝗢𝗧𝗜𝗖𝗘 』\n" +
"╚═══◇◆◇════════════╝\n" +
"│ ⚡ 𝗩𝗶𝗲𝘄-𝗼𝗻𝗰𝗲 𝗹𝗶𝗺𝗶𝘁𝘀\n" +
"│ ⚡ 𝗮𝗿𝗲 𝗻𝗼𝘁 𝗮 𝗯𝗮𝗿𝗿𝗶𝗲𝗿\n" +
"│ ⚡ 𝗳𝗼𝗿 𝗼𝘂𝗿 𝗕𝗼𝘁\n" +
"───────────────────\n\n" +
"╔════◇◆◇══════════╗\n" +
"『 🕶️ 𝗦𝗬𝗦𝗧𝗘𝗠 𝗜𝗗𝗘𝗡𝗧𝗜𝗧𝗬 』\n" +
"╚════◇◆◇══════════╝\n" +
"│ 🕶️ 𝗪𝗲 𝗼𝗽𝗲𝗿𝗮𝘁𝗲 𝘀𝗶𝗹𝗲𝗻𝘁𝗹𝘆\n" +
"│ 🌐 𝗪𝗲 𝗮𝗿𝗲 𝗮𝗹𝘄𝗮𝘆𝘀 𝗽𝗿𝗲𝘀𝗲𝗻𝘁\n" +
"│ ⚡ 𝗪𝗲 𝗲𝘅𝗲𝗰𝘂𝘁𝗲 𝗽𝗲𝗿𝗳𝗲𝗰𝘁𝗹𝘆\n" +
"───────────────────\n\n" +
"╔═══════◇◆◇═══════╗\n" +
"『 🖤 𝗘𝗫𝗣𝗘𝗖𝗧 𝗨𝗦 』\n" +
"╚═══════◇◆◇═══════╝\n" +
"> *Powered by " + botName + "*";

        // ✅ IMAGE
        if (quotedImage) {
            const buffer = await downloadToBuffer(quotedImage, 'image');

            await sock.sendMessage(
                chatId,
                {
                    image: buffer,
                    caption: COMMON_CAPTION.replace('𝗠𝗘𝗗𝗜𝗔', '𝗜𝗠𝗔𝗚𝗘'),
                    contextInfo: forwardedCtx
                },
                { quoted: message }
            );
            return;
        }

        // ✅ VIDEO (same caption style as image)
        if (quotedVideo) {
            const buffer = await downloadToBuffer(quotedVideo, 'video');

            await sock.sendMessage(
                chatId,
                {
                    video: buffer,
                    caption: COMMON_CAPTION.replace('𝗠𝗘𝗗𝗜𝗔', '𝗩𝗜𝗗𝗘𝗢'),
                    contextInfo: forwardedCtx
                },
                { quoted: message }
            );
            return;
        }

        // ✅ VIEW ONCE VOICE
        if (quotedAudio) {
            const buffer = await downloadToBuffer(quotedAudio, 'audio');

            await sock.sendMessage(
                chatId,
                {
                    audio: buffer,
                    mimetype: quotedAudio?.mimetype || 'audio/ogg; codecs=opus',
                    ptt: true,
                    caption: '🎤✅ View-once voice unlocked.',
                    contextInfo: forwardedCtx
                },
                { quoted: message }
            );
            return;
        }

        await sock.sendMessage(
            chatId,
            {
                text: '❌ Please reply to a view-once image, video, or voice note.',
                contextInfo: forwardedCtx
            },
            { quoted: message }
        );

    } catch (err) {
        console.error("Error in viewonceCommand:", err);
        await sock.sendMessage(
            chatId,
            {
                text: "⚠️ Error processing view-once media.",
                contextInfo: {
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: "120363404049028072@newsletter",
                        newsletterName: "NASIR-MD BOT",
                        serverMessageId: -1
                    }
                }
            },
            { quoted: message }
        );
    }
}

module.exports = viewonceCommand;
