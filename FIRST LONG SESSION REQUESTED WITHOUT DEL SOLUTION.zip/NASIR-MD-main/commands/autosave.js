// commands/autosave.js
const fs = require('fs');
const path = require('path');
const { downloadMediaMessage } = require('@whiskeysockets/baileys');

let autoSaveEnabled = false;

module.exports = {
    name: 'autosave',
    description: 'Auto-save all status updates to bot inbox',
    
    async execute(sock, chatId, message, isGroup) {
        try {
            // Toggle the auto-save mode
            autoSaveEnabled = !autoSaveEnabled;
            
            if (autoSaveEnabled) {
                await sock.sendMessage(chatId, {
                    text: '✅ *Auto-Save Mode:* ENABLED\n\nAll status updates will be automatically saved to my inbox.'
                });
                
                // Start listening for status updates
                await startStatusListener(sock);
            } else {
                await sock.sendMessage(chatId, {
                    text: '❌ *Auto-Save Mode:* DISABLED\n\nStatus auto-saving has been turned off.'
                });
            }
            
        } catch (error) {
            console.error('Error in autosave command:', error);
            await sock.sendMessage(chatId, {
                text: '❌ An error occurred while toggling auto-save mode.'
            });
        }
    }
};

async function startStatusListener(sock) {
    console.log('Status Auto-Save listener started');
    
    // Listen for incoming status updates
    sock.ev.on('messages.upsert', async ({ messages }) => {
        const msg = messages[0];
        
        // Check if it's a status update
        if (msg.key.remoteJid === 'status@broadcast' && autoSaveEnabled) {
            try {
                await processAndForwardStatus(sock, msg);
            } catch (error) {
                console.error('Error processing status:', error);
            }
        }
    });
}

async function processAndForwardStatus(sock, msg) {
    const statusSender = msg.key.participant || 'Unknown';
    const uploadTime = new Date(msg.messageTimestamp * 1000).toLocaleString();
    
    let mediaBuffer = null;
    let caption = '';
    let mimeType = '';
    let messageType = '';
    
    // Extract message content
    const msgContent = msg.message;
    
    // Determine message type
    if (msgContent?.imageMessage) {
        const img = msgContent.imageMessage;
        caption = img.caption || '';
        mimeType = img.mimetype || 'image/jpeg';
        messageType = 'image';
    } else if (msgContent?.videoMessage) {
        const vid = msgContent.videoMessage;
        caption = vid.caption || '';
        mimeType = vid.mimetype || 'video/mp4';
        messageType = 'video';
    } else if (msgContent?.conversation) {
        caption = msgContent.conversation;
        messageType = 'text';
    } else if (msgContent?.extendedTextMessage?.text) {
        caption = msgContent.extendedTextMessage.text;
        messageType = 'text';
    }
    
    // Download media if available
    if (messageType === 'image' || messageType === 'video') {
        try {
            mediaBuffer = await downloadMediaMessage(
                msg,
                'buffer',
                {},
                { 
                    reuploadRequest: sock.updateMediaMessage
                }
            );
        } catch (downloadError) {
            console.error('Failed to download media:', downloadError);
        }
    }
    
    // Create detailed caption
    const details = `👤 *Status Owner:* ${statusSender.split('@')[0]}\n` +
                   `📞 *Phone:* ${statusSender}\n` +
                   `⏰ *Upload Time:* ${uploadTime}\n` +
                   `📝 *Caption:* ${caption || 'No caption'}`;
    
    const finalCaption = `${details}\n\n*🚀 Powered by Nasir-MD Bot*`;
    
    // Send to bot's own inbox
    const botInboxJid = sock.user.id;
    
    if (mediaBuffer && mediaBuffer.length > 0) {
        if (messageType === 'image') {
            await sock.sendMessage(botInboxJid, {
                image: mediaBuffer,
                caption: finalCaption,
                mimetype: mimeType
            });
        } else if (messageType === 'video') {
            await sock.sendMessage(botInboxJid, {
                video: mediaBuffer,
                caption: finalCaption,
                mimetype: mimeType
            });
        }
    } else if (caption) {
        // Send as text message
        await sock.sendMessage(botInboxJid, {
            text: finalCaption
        });
    }
    
    console.log(`Status from ${statusSender} forwarded to bot inbox`);
}