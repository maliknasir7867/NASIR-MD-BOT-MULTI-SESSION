const fs = require('fs');
const path = require('path');
const sessionState = require('../lib/sessionState');

function readJsonSafe(path, fallback) {
    try {
        const txt = fs.readFileSync(path, 'utf8');
        return JSON.parse(txt);
    } catch (_) {
        return fallback;
    }
}

const isOwnerOrSudo = require('../lib/isOwner');

async function settingsCommand(sock, chatId, message) {
    try {
        const senderId = message.key.participant || message.key.remoteJid;
        const isOwner = await isOwnerOrSudo(senderId, sock, chatId);
        
        if (!message.key.fromMe && !isOwner) {
            await sock.sendMessage(chatId, { 
                text:
`╭━━〔 ❌ 𝗔𝗖𝗖𝗘𝗦𝗦 𝗗𝗘𝗡𝗜𝗘𝗗 〕━┈⊷
┃ Only bot owner can use this command!
╰━━━━━━━━━━━━━━━━━━┈⊷`
            }, { quoted: message });
            return;
        }

        const isGroup = chatId.endsWith('@g.us');
        // Per-session settings directory (prevents settings leaking across sessions)
        try { sessionState.ensureSessionSkeleton(); } catch (_) {}
        const dataDir = sessionState.sessionDataDir();

        // IMPORTANT: keep these ABOVE the decorated text (fixes "mode is not defined")
        const mode = readJsonSafe(path.join(dataDir, 'messageCount.json'), { isPublic: true });
        const autoStatus = readJsonSafe(path.join(dataDir, 'autoStatus.json'), { enabled: false });
        const autoread = readJsonSafe(path.join(dataDir, 'autoread.json'), { enabled: false });
        const autotyping = readJsonSafe(path.join(dataDir, 'autotyping.json'), { enabled: false });
        const pmblocker = readJsonSafe(path.join(dataDir, 'pmblocker.json'), { enabled: false });
        const anticall = readJsonSafe(path.join(dataDir, 'anticall.json'), { enabled: false });
        const userGroupData = readJsonSafe(path.join(dataDir, 'userGroupData.json'), {
            antilink: {}, antibadword: {}, welcome: {}, goodbye: {}, chatbot: {}, antitag: {}
        });
        const autoReaction = Boolean(userGroupData.autoReaction);

        // Per-group features
        const groupId = isGroup ? chatId : null;
        const antilinkOn = groupId ? Boolean(userGroupData.antilink && userGroupData.antilink[groupId]) : false;
        const antibadwordOn = groupId ? Boolean(userGroupData.antibadword && userGroupData.antibadword[groupId]) : false;
        const welcomeOn = groupId ? Boolean(userGroupData.welcome && userGroupData.welcome[groupId]) : false;
        const goodbyeOn = groupId ? Boolean(userGroupData.goodbye && userGroupData.goodbye[groupId]) : false;
        const chatbotOn = groupId ? Boolean(userGroupData.chatbot && userGroupData.chatbot[groupId]) : false;
        const antitagCfg = groupId ? (userGroupData.antitag && userGroupData.antitag[groupId]) : null;

        const lines = [];

        // Header
        lines.push('╭━━━━━━━━━━━━━━━━━━━━━━╮');
        lines.push('┃     ⚙️ 𝗡𝗔𝗦𝗜𝗥-𝗠𝗗 𝗦𝗘𝗧𝗧𝗜𝗡𝗚𝗦     ┃');
        lines.push('╰━━━━━━━━━━━━━━━━━━━━━━╯');
        lines.push('');

        // Global settings
        lines.push('╭─〔 🌐 𝗚𝗟𝗢𝗕𝗔𝗟 𝗦𝗘𝗧𝗧𝗜𝗡𝗚𝗦 〕─╮');
        lines.push(`┃ 🔧 Mode          : ${mode.isPublic ? 'Public 🌍' : 'Private 🔒'}`);
        lines.push(`┃ 📡 Auto Status   : ${autoStatus.enabled ? 'Enabled ✅' : 'Disabled ❌'}`);
        lines.push(`┃ 👁️ Autoread      : ${autoread.enabled ? 'Enabled ✅' : 'Disabled ❌'}`);
        lines.push(`┃ ⌨️ Autotyping    : ${autotyping.enabled ? 'Enabled ✅' : 'Disabled ❌'}`);
        lines.push(`┃ 🚫 PM Blocker    : ${pmblocker.enabled ? 'Enabled ✅' : 'Disabled ❌'}`);
        lines.push(`┃ 📵 Anticall      : ${anticall.enabled ? 'Enabled ✅' : 'Disabled ❌'}`);
        lines.push(`┃ ✨ Auto Reaction : ${autoReaction ? 'Enabled ✅' : 'Disabled ❌'}`);
        lines.push('╰──────────────────────╯');

        if (groupId) {
            lines.push('');
            lines.push('╭─〔 👥 𝗚𝗥𝗢𝗨𝗣 𝗦𝗘𝗧𝗧𝗜𝗡𝗚𝗦 〕─╮');
            lines.push('┃ 🆔 Group ID:');
            lines.push(`┃ ${groupId}`);
            lines.push('┃');

            if (antilinkOn) {
                const al = userGroupData.antilink[groupId] || {};
                lines.push(`┃ 🔗 Antilink     : Enabled ✅`);
                lines.push(`┃    ↳ Action     : ${al.action || 'delete'}`);
            } else {
                lines.push(`┃ 🔗 Antilink     : Disabled ❌`);
            }

            if (antibadwordOn) {
                const ab = userGroupData.antibadword[groupId] || {};
                lines.push(`┃ 🧼 Antibadword  : Enabled ✅`);
                lines.push(`┃    ↳ Action     : ${ab.action || 'delete'}`);
            } else {
                lines.push(`┃ 🧼 Antibadword  : Disabled ❌`);
            }

            lines.push(`┃ 👋 Welcome      : ${welcomeOn ? 'Enabled ✅' : 'Disabled ❌'}`);
            lines.push(`┃ 🫂 Goodbye      : ${goodbyeOn ? 'Enabled ✅' : 'Disabled ❌'}`);
            lines.push(`┃ 🤖 Chatbot      : ${chatbotOn ? 'Enabled ✅' : 'Disabled ❌'}`);

            if (antitagCfg && antitagCfg.enabled) {
                lines.push(`┃ 🏷️ Antitag      : Enabled ✅`);
                lines.push(`┃    ↳ Action     : ${antitagCfg.action || 'delete'}`);
            } else {
                lines.push(`┃ 🏷️ Antitag      : Disabled ❌`);
            }

            lines.push('╰──────────────────────╯');
        } else {
            lines.push('');
            lines.push('╭─〔 ℹ️ 𝗡𝗢𝗧𝗘 〕─╮');
            lines.push('┃ Use this command inside a group');
            lines.push('┃ to view group-specific settings.');
            lines.push('╰──────────────────────╯');
        }

        await sock.sendMessage(chatId, { text: lines.join('\n') }, { quoted: message });
    } catch (error) {
        console.error('Error in settings command:', error);
        await sock.sendMessage(chatId, { 
            text:
`╭━━〔 ❌ 𝗘𝗥𝗥𝗢𝗥 〕━━┈⊷
┃ Failed to read settings.
╰━━━━━━━━━━━━━━━━━━┈⊷`
        }, { quoted: message });
    }
}

module.exports = settingsCommand;
