const config = require('../data/config');  // Make sure the path is correct
const { handleGoodbye } = require('../lib/welcome');
const { isGoodByeOn, getGoodbye } = require('../lib/index');
const fetch = require('node-fetch');
const fs = require('fs');

// Helper function to get join time from jointime.json
function getJoinTime(groupId, participantId) {
    const filePath = './data/jointime.json';

    if (!fs.existsSync(filePath)) return 'Unknown';

    try {
        const data = JSON.parse(fs.readFileSync(filePath));
        return data[groupId]?.[participantId] || 'Unknown';
    } catch (error) {
        console.error('Error reading jointime.json:', error);
        return 'Unknown';
    }
}

// Function to extract the phone number from JID (removes '@c.us')
function extractPhoneNumber(jid) {
    return jid.split('@')[0];  // Remove '@c.us' and return the phone number part
}

async function goodbyeCommand(sock, chatId, message, match) {
    if (!chatId.endsWith('@g.us')) {
        await sock.sendMessage(chatId, { text: 'This command can only be used in groups.' });
        return;
    }

    const text = message.message?.conversation || message.message?.extendedTextMessage?.text || '';
    const matchText = text.split(' ').slice(1).join(' ');

    await handleGoodbye(sock, chatId, message, matchText);
}

async function handleLeaveEvent(sock, id, participants) {
    const isGoodbyeEnabled = await isGoodByeOn(id);
    if (!isGoodbyeEnabled) return;

    const groupMetadata = await sock.groupMetadata(id);
    const groupName = groupMetadata.subject;
    const groupDesc = groupMetadata.desc || 'No description available';
    const memberCount = groupMetadata.participants.length;
    const adminCount = groupMetadata.participants.filter(p => p.admin).length;

    // Get owner phone number from config.js
    const owner = config.owner || 'Unknown';
    const bot = config.botname || 'Unknown Bot';

    // Get current time in Pakistan time (departure time)
    const departureTime = new Date().toLocaleString("en-PK", {
        timeZone: "Asia/Karachi",
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: true
    });

    console.log("Departure Time in PKT:", departureTime);

    for (const participant of participants) {
        try {
            const participantString = typeof participant === 'string' ? participant : (participant.id || participant.toString());
            const user = participantString.split('@')[0];

            let displayName = user;
            try {
                // Try to get name from business profile
                const contact = await sock.getBusinessProfile(participantString);
                if (contact && contact.name) {
                    displayName = contact.name;
                } else {
                    // Fallback to name from group participants
                    const userParticipant = groupMetadata.participants.find(p => p.id === participantString);
                    if (userParticipant && userParticipant.name) {
                        displayName = userParticipant.name;
                    }
                }
            } catch (error) {
                console.error('Error getting user name:', error);
            }

            // Get user bio/status
            let bio = "";
            try {
                const status = await sock.fetchStatus(participantString);
                bio = status?.status || "";
            } catch (error) {
                console.error('Error fetching user status:', error);
            }

            // Get join time from jointime.json
            const joinTime = getJoinTime(id, participantString);

            // Create the goodbye message
            const finalMessage = `*🌙🌸 G O O D B Y E* @${displayName} 🌸🌙

You're departing from *${groupName}* ✨

*👥 Members Left:* ${memberCount}
*🛡 Admin Count:* ${adminCount}
*👑 Owner:* ${extractPhoneNumber(owner)}

*📝 Description:*
${groupDesc}

*💬 Your Bio:* ${bio || 'No bio available'}

*📅 User Joined On:* ${joinTime}
*⏰ Departure Time:* ${departureTime}

*🤖 Powered By:* ${bot}

*✨ Wishing you peace, luck, and a beautiful journey ahead. ✨*`;

            // Try to send with image
            try {
                let profilePicUrl = `https://img.pyrocdn.com/dbKUgahg.png`; // Default avatar
                try {
                    const profilePic = await sock.profilePictureUrl(participantString, 'image');
                    if (profilePic) {
                        profilePicUrl = profilePic;
                    }
                } catch (error) {
                    console.error('Error fetching profile picture:', error);
                }

                const apiUrl = `https://api.some-random-api.com/welcome/img/2/gaming1?type=leave&textcolor=red&username=${encodeURIComponent(displayName)}&guildName=${encodeURIComponent(groupName)}&memberCount=${memberCount}&avatar=${encodeURIComponent(profilePicUrl)}`;
                const response = await fetch(apiUrl);
                if (response.ok) {
                    const imageBuffer = await response.buffer();
                    await sock.sendMessage(id, {
                        image: imageBuffer,
                        caption: finalMessage,
                        mentions: [participantString]
                    });
                    continue;
                }
            } catch (error) {
                console.error('Error with image API:', error);
            }

            // Fallback to text message if image fails
            await sock.sendMessage(id, {
                text: finalMessage,
                mentions: [participantString]
            });
        } catch (error) {
            console.error('Error processing goodbye for participant:', error);
            const participantString = typeof participant === 'string' ? participant : (participant.id || participant.toString());
            const user = participantString.split('@')[0];

            const fallbackMessage = `Goodbye @${user}! We'll miss you!`;
            await sock.sendMessage(id, {
                text: fallbackMessage,
                mentions: [participantString]
            });
        }
    }
}

module.exports = { goodbyeCommand, handleLeaveEvent };