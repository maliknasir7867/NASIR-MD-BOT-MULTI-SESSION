// decrypt.js
// Auto-detect and decrypt: base64, hex, binary, url, rot13, reverse
// Channel forwarded UI enabled

module.exports = async function decryptCommand(sock, chatId, message, rawText) {
    try {
        const text = rawText.split(" ").slice(1).join(" ").trim();

        // Show usage if no input
        if (!text) {
            return await sock.sendMessage(chatId, {
                text: `🔓 *Auto-Decryption Guide*

Just send:
.decrypt <encoded_text>

✨ Bot will automatically detect:
• Base64
• Hex
• Binary
• URL encoded
• ROT13
• Reverse text`,
                contextInfo: {
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: "120363404049028072@newsletter",
                        newsletterName: "NASIR-MD BOT",
                        serverMessageId: -1
                    }
                }
            }, { quoted: message });
        }

        let decoded = null;
        let detected = null;

        // Base64 detection
        if (!decoded) {
            try {
                const buff = Buffer.from(text, 'base64').toString('utf8');
                if (/^[\x00-\x7F]*$/.test(buff) && buff.length > 0) {
                    decoded = buff;
                    detected = 'Base64';
                }
            } catch {}
        }

        // HEX detection
        if (!decoded && /^[0-9a-fA-F]+$/.test(text.replace(/\s+/g, ''))) {
            try {
                const buff = Buffer.from(text.replace(/\s+/g, ''), 'hex').toString('utf8');
                decoded = buff;
                detected = 'HEX';
            } catch {}
        }

        // Binary detection
        if (!decoded && /^[01\s]+$/.test(text)) {
            try {
                const bin = text.split(' ')
                    .map(b => String.fromCharCode(parseInt(b, 2)))
                    .join('');
                decoded = bin;
                detected = 'Binary';
            } catch {}
        }

        // URL decode
        if (!decoded && /%[0-9A-Fa-f]{2}/.test(text)) {
            try {
                decoded = decodeURIComponent(text);
                detected = 'URL Encoded';
            } catch {}
        }

        // ROT13 detection
        if (!decoded) {
            const rot = text.replace(/[a-zA-Z]/g, c =>
                String.fromCharCode(
                    (c <= 'Z' ? 90 : 122) >= (c = c.charCodeAt(0) + 13)
                        ? c
                        : c - 26
                )
            );

            if (rot !== text) {
                decoded = rot;
                detected = 'ROT13';
            }
        }

        // Reverse text
        if (!decoded && text.length > 1) {
            const rev = text.split('').reverse().join('');
            if (rev !== text) {
                decoded = rev;
                detected = 'Reversed Text';
            }
        }

        // If no match found
        if (!decoded) {
            return await sock.sendMessage(chatId, {
                text: `❌ *Unable to detect encryption type*

Try:
.encrypt base64 <msg>
.encrypt hex <msg>
.encrypt binary <msg>
.encrypt rot13 <msg>
.encrypt url <msg>
.encrypt reverse <msg>`,
                contextInfo: {
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: "120363404049028072@newsletter",
                        newsletterName: "NASIR-MD BOT",
                        serverMessageId: -1
                    }
                }
            }, { quoted: message });
        }

        // SUCCESS — Channel Forwarded Look
        return await sock.sendMessage(chatId, {
            text: `🔓 *Decryption Successful!*

🧩 *Detected:* ${detected}
🔐 *Encoded:* ${text}
✨ *Decoded:* ${decoded}`,
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: "120363404049028072@newsletter",
                    newsletterName: "NASIR-MD BOT",
                    serverMessageId: -1
                }
            }
        }, { quoted: message });

    } catch (err) {
        console.error("DECRYPT ERROR:", err);
        return await sock.sendMessage(chatId, {
            text: "⚠️ Failed to decrypt the message.",
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: "120363404049028072@newsletter",
                    newsletterName: "NASIR-MD BOT",
                    serverMessageId: -1
                }
            }
        }, { quoted: message });
    }
};
