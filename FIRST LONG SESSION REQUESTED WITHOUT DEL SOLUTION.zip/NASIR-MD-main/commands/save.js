const { downloadMediaMessage } = require('@whiskeysockets/baileys');

module.exports = {
    name: 'save',
    description: 'Save and forward status updates with caption',
    async execute(sock, chatId, message, isGroup) {
        try {
            // Check if message is a reply
            if (!message.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
                return await sock.sendMessage(chatId, {
                    text: '❌ *Usage:* Reply to a status with `.save` to save it.'
                });
            }

            const quotedCtx = message.message.extendedTextMessage.contextInfo;
            const quotedMsg = quotedCtx.quotedMessage;
            
            // Debug: Log the quoted message structure
            console.log('Quoted message keys:', Object.keys(quotedMsg));
            console.log('Remote JID:', quotedCtx.remoteJid);

            // Check if it's from status
            if (quotedCtx.remoteJid !== 'status@broadcast') {
                return await sock.sendMessage(chatId, {
                    text: '❌ This command only works for status updates. Please reply to a status.'
                });
            }

            await sock.sendMessage(chatId, { text: '📥 *Downloading status...*' });

            let mediaBuffer;
            let caption = '';
            let mimeType = '';
            let messageType = '';

            // Check for different message types in status
            if (quotedMsg.imageMessage || quotedMsg.jpegThumbnail) {
                messageType = 'image';
                const imgMsg = quotedMsg.imageMessage || {};
                caption = imgMsg.caption || '';
                mimeType = imgMsg.mimetype || 'image/jpeg';
            } 
            else if (quotedMsg.videoMessage) {
                messageType = 'video';
                const vidMsg = quotedMsg.videoMessage;
                caption = vidMsg.caption || '';
                mimeType = vidMsg.mimetype || 'video/mp4';
            }
            else if (quotedMsg.conversation || quotedMsg.extendedTextMessage) {
                messageType = 'text';
                caption = quotedMsg.conversation || quotedMsg.extendedTextMessage?.text || '';
            }
            else if (quotedMsg.documentMessage) {
                messageType = 'document';
                const docMsg = quotedMsg.documentMessage;
                caption = docMsg.caption || '';
                mimeType = docMsg.mimetype || 'application/octet-stream';
            }

            // Append custom footer
            const customFooter = '\n\n*🚀 Powered by Nasir-MD Bot*';
            const finalCaption = caption ? caption + customFooter : customFooter.trim();

            // Download media if it exists
            if (messageType === 'image' || messageType === 'video' || messageType === 'document') {
                try {
                    // Construct proper message object for download
                    const statusMessage = {
                        key: {
                            remoteJid: 'status@broadcast',
                            id: quotedCtx.stanzaId,
                            fromMe: false,
                            participant: quotedCtx.participant
                        },
                        message: quotedMsg,
                        // Important: Status messages need this flag
                        messageTimestamp: Date.now()
                    };

                    console.log('Attempting to download...');
                    
                    // Try with stream first (more reliable)
                    mediaBuffer = await downloadMediaMessage(
                        statusMessage,
                        'buffer',
                        {},
                        {
                            reuploadRequest: sock.updateMediaMessage,
                            logger: console
                        }
                    );

                    console.log('Download successful, buffer size:', mediaBuffer?.length);

                } catch (mediaError) {
                    console.error('Download error details:', mediaError);
                    console.error('Message structure:', JSON.stringify(quotedMsg, null, 2));
                    
                    // Try alternative download method
                    try {
                        // Alternative: Try using the URL if available
                        const mediaKey = quotedMsg.imageMessage?.mediaKey || 
                                        quotedMsg.videoMessage?.mediaKey ||
                                        quotedMsg.documentMessage?.mediaKey;
                        
                        if (mediaKey) {
                            console.log('Media key found, trying alternative download...');
                            // You might need to implement direct URL fetching here
                        }
                        
                        return await sock.sendMessage(chatId, {
                            text: '❌ Failed to download media. The status might have expired or is not downloadable.'
                        });
                    } catch (altError) {
                        return await sock.sendMessage(chatId, {
                            text: '❌ Download failed. Status may be too old or not accessible.'
                        });
                    }
                }
            }

            // Send the saved content back
            if (mediaBuffer && mediaBuffer.length > 0) {
                if (messageType === 'image') {
                    await sock.sendMessage(chatId, {
                        image: mediaBuffer,
                        caption: finalCaption,
                        mimetype: mimeType
                    });
                } else if (messageType === 'video') {
                    await sock.sendMessage(chatId, {
                        video: mediaBuffer,
                        caption: finalCaption,
                        mimetype: mimeType
                    });
                } else if (messageType === 'document') {
                    const fileName = `status_${Date.now()}.${mimeType.split('/')[1] || 'bin'}`;
                    await sock.sendMessage(chatId, {
                        document: mediaBuffer,
                        caption: finalCaption,
                        mimetype: mimeType,
                        fileName: fileName
                    });
                }
            } else if (caption || messageType === 'text') {
                // Send text-only status
                await sock.sendMessage(chatId, {
                    text: finalCaption
                });
            } else {
                return await sock.sendMessage(chatId, {
                    text: '❌ No downloadable content found in this status.'
                });
            }

            // Success message
            await sock.sendMessage(chatId, {
                text: '✅ *Status saved successfully!*'
            });

        } catch (error) {
            console.error('Full error in save command:', error);
            console.error('Error stack:', error.stack);
            await sock.sendMessage(chatId, {
                text: '❌ An error occurred: ' + error.message
            });
        }
    }
};