const axios = require('axios');
const yts = require('yt-search');

// API configuration
const apis = {
    davidcyril: "https://apis.davidcyril.name.ng/song?query="
};

const AXIOS_DEFAULTS = {
    timeout: 60000,
    headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'application/json, text/plain, */*',
        'Referer': 'https://apis.davidcyril.name.ng/'
    }
};

// Channel tag (DO NOT send to channel)
const CHANNEL_JID = "120363404049028072@newsletter";

function forwardedTag() {
    return {
        contextInfo: {
            isForwarded: true,
            forwardingScore: 777,
            forwardedNewsletterMessageInfo: {
                newsletterJid: CHANNEL_JID,
                serverMessageId: null
            }
        }
    };
}

async function tryRequest(getter, attempts = 3) {
    let lastError;
    for (let attempt = 1; attempt <= attempts; attempt++) {
        try { return await getter(); }
        catch (err) {
            lastError = err;
            if (attempt < attempts) await new Promise(r => setTimeout(r, 1000 * attempt));
        }
    }
    throw lastError;
}

// Function to extract direct video URL from redirect
async function getDirectVideoUrl(redirectUrl) {
    try {
        const response = await axios.get(redirectUrl, {
            ...AXIOS_DEFAULTS,
            maxRedirects: 0,
            validateStatus: function (status) {
                return status >= 200 && status < 400; // Allow redirect status codes
            }
        });
        
        // Check for location header
        if (response.headers.location) {
            return response.headers.location;
        }
        
        // Try to parse the HTML for download link
        const html = response.data;
        const directUrlMatch = html.match(/href="([^"]*\.mp4[^"]*)"/i) || 
                              html.match(/src="([^"]*\.mp4[^"]*)"/i) ||
                              html.match(/url:\s*['"]([^'"]*\.mp4[^'"]*)['"]/i);
        
        if (directUrlMatch && directUrlMatch[1]) {
            return directUrlMatch[1];
        }
        
        throw new Error("No direct video URL found in redirect");
        
    } catch (error) {
        console.error("Error extracting direct URL:", error.message);
        throw error;
    }
}

// New function to get video from David Cyril API
async function getDavidCyrilVideoByQuery(query) {
    const apiUrl = `${apis.davidcyril}${encodeURIComponent(query)}`;
    const res = await tryRequest(() => axios.get(apiUrl, AXIOS_DEFAULTS));
    
    if (res?.data?.status && res?.data?.result?.video?.download_url) {
        const result = res.data.result;
        
        // Try to get direct video URL from the redirect link
        let directDownloadUrl = result.video.download_url;
        
        try {
            if (result.video.download_url.includes('savenow.to') || 
                result.video.download_url.includes('redirect')) {
                directDownloadUrl = await getDirectVideoUrl(result.video.download_url);
            }
        } catch (redirectError) {
            console.log("Could not resolve redirect, using original URL:", redirectError.message);
        }
        
        return {
            download: directDownloadUrl,
            title: result.title,
            thumbnail: result.thumbnail,
            duration: result.duration,
            views: result.views,
            published: result.published,
            video_url: result.video_url,
            quality: result.video.quality,
            original_url: result.video.download_url
        };
    }
    throw new Error("David Cyril API returned no video");
}

// ===========================================================
// ⭐ ULTRA PRO LEGENDARY VIDEO COMMAND (with funny search UI)
// ===========================================================

async function videoCommand(sock, chatId, message) {
    try {
        const text = message.message?.conversation || message.message?.extendedTextMessage?.text;
        const query = text.split(" ").slice(1).join(" ").trim();

        if (!query) {
            await sock.sendMessage(chatId, {
                text: `
🎧 *NASIR-MD VIDEO DOWNLOADER* 
━━━━━━━━━━━━━━━━━━━━━━  
What video would you like to download?  
✨ Send a *YouTube link* or type a *song name*!
                `,
                ...forwardedTag()
            }, { quoted: message });
            return;
        }

        let info, videoUrl;
        const isLink = query.startsWith("http://") || query.startsWith("https://");

        // ==========================
        // ⭐ Friendly Search Animation
        // ==========================

        if (!isLink) {
            await sock.sendMessage(chatId, {
                text: `
👀 *Hold up! Let me look...*  
🔍 Searching YouTube for your song...  
🎧 Getting the juicy details...
                `,
                ...forwardedTag()
            }, { quoted: message });
        }

        // ==========================
        // ⭐ Try David Cyril API first for search queries
        // ==========================

        if (!isLink) {
            try {
                const davidCyrilData = await getDavidCyrilVideoByQuery(query);
                
                // ==========================
                // ⭐ VIDEO DETAIL PANEL (from David Cyril API)
                // ==========================

                const panel = `
🎬 *${davidCyrilData.title}*
━━━━━━━━━━━━━━━━━━━
⏳ *Duration:* ${davidCyrilData.duration}
👁 *Views:* ${davidCyrilData.views?.toLocaleString()}
📅 *Uploaded:* ${davidCyrilData.published}
🎯 *Quality:* ${davidCyrilData.quality}
🔗 *URL:* ${davidCyrilData.video_url}
━━━━━━━━━━━━━━━━━━━
⏳ *Preparing your download...*
                `;

                await sock.sendMessage(chatId, {
                    image: { url: davidCyrilData.thumbnail },
                    caption: panel,
                    ...forwardedTag()
                }, { quoted: message });

                // ==========================
                // ⭐ FINAL DELIVERY with retry mechanism
                // ==========================

                const finalCaption = `
🌟 *YOUR VIDEO IS READY!* 🌟  
━━━━━━━━━━━━━━━━━━━  
📥 Delivered by *NASIR-MD BOT*  
🔥 Enjoy your masterpiece!
                `;

                // Try to send video with the URL
                try {
                    await sock.sendMessage(chatId, {
                        video: { url: davidCyrilData.download },
                        mimetype: "video/mp4",
                        fileName: `${davidCyrilData.title.replace(/[<>:"/\\|?*]/g, '_').substring(0, 100)}.mp4`,
                        caption: finalCaption,
                        ...forwardedTag()
                    }, { quoted: message });
                } catch (sendError) {
                    console.error("Error sending video:", sendError.message);
                    
                    // If sending fails, provide the download link as text
                    await sock.sendMessage(chatId, {
                        text: `
❌ *Video sending failed!*  
But here's your download link:
${davidCyrilData.download}

📥 *Alternative:* Try downloading manually from the link above.
                        `,
                        ...forwardedTag()
                    }, { quoted: message });
                }

                return; // Exit function after successful download
                
            } catch (err) {
                console.log("David Cyril API failed:", err.message);
                // Fall back to yts if David Cyril API fails
            }
        }

        // ==========================
        // ⭐ Fallback to yts search (for links or if David Cyril fails)
        // ==========================

        if (isLink) {
            videoUrl = query;
            info = (await yts({ videoId: videoUrl.split("v=")[1] })) || {};
        } else {
            const { videos } = await yts(query);
            if (!videos || videos.length === 0) {
                await sock.sendMessage(chatId, {
                    text: "❌ *Couldn't find anything matching your search!*",
                    ...forwardedTag()
                }, { quoted: message });
                return;
            }
            info = videos[0];
            videoUrl = info.url;
        }

        // ==========================
        // ⭐ VIDEO DETAIL PANEL (yts fallback)
        // ==========================

        const panel = `
🎬 *${info.title}*
━━━━━━━━━━━━━━━━━━━
⏳ *Duration:* ${info.timestamp}
👁 *Views:* ${info.views?.toLocaleString()}
👤 *Channel:* ${info.author?.name}
📅 *Uploaded:* ${info.ago}
🔗 *URL:* ${videoUrl}
━━━━━━━━━━━━━━━━━━━
❌ *Unable to download video - No download API available*
        `;

        await sock.sendMessage(chatId, {
            image: { url: info.thumbnail },
            caption: panel,
            ...forwardedTag()
        }, { quoted: message });

        await sock.sendMessage(chatId, {
            text: `
⚠️ **Limited Functionality**  
The video download feature is currently unavailable.  
You can still search and view video details.
            `,
            ...forwardedTag()
        }, { quoted: message });

    } catch (err) {
        console.error("Command error:", err);
        await sock.sendMessage(chatId, {
            text: `
❌ **Download Error!**  
⚙ Reason: ${err.message}
💡 Try again with a different link or name.
            `,
            ...forwardedTag()
        }, { quoted: message });
    }
}

module.exports = videoCommand;