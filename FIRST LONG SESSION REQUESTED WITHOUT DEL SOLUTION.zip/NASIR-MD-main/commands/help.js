const settings = require('../settings');
const fs = require('fs');
const path = require('path');

let botMode = 'private';
try {
  const modeData = JSON.parse(
    fs.readFileSync('./data/messageCount.json', 'utf-8')
  );
  botMode = modeData?.isPublic ? 'public' : 'private';
} catch (e) {
  botMode = 'private';
}

async function helpCommand(sock, chatId, message) {

// Refresh mode on every .menu call so it always reflects the latest setting
try {
  const modeFilePath = path.join(__dirname, '..', 'data', 'messageCount.json');
  const latestModeData = JSON.parse(fs.readFileSync(modeFilePath, 'utf-8'));
  if (typeof latestModeData?.isPublic === 'boolean') {
    botMode = latestModeData.isPublic ? 'public' : 'private';
  } else if (typeof settings?.commandMode === 'string') {
    botMode = String(settings.commandMode).toLowerCase() === 'private' ? 'private' : 'public';
  }
} catch (e) {
  if (typeof settings?.commandMode === 'string') {
    botMode = String(settings.commandMode).toLowerCase() === 'private' ? 'private' : 'public';
  }
}

const helpMessage = `
╭━━〔 *${settings.botName || 'NASIR-MD'}* 〕━┈⊷
╔═══════◇◆◇═══════╗
『𝗨𝗟𝗧𝗜𝗠𝗔𝗧𝗘 𝗕𝗢𝗧 𝗠𝗘𝗡𝗨』
╚═══════◇◆◇═══════╝
⟬★⟭────────────────
⟬★⟭ 𝗕𝗢𝗧 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡
⟬★⟭────────────────
│ 👑  Owner » *${settings.botOwner || 'NASIR'}*
│ 🤖  Version » *v${settings.version || '3.0.4'}*
│ 💻  Type » *NodeJs*
│ 🚀  Platform » *Multi Device*
│ ⚙️  Mode » *[${botMode}]*

│ 🔣  Prefix » *[.]*
│ 📚  Commands » *200+*
⟬★⟭─────────────────
╔═══◇◆◇════════════╗
『 📜 𝗠𝗘𝗡𝗨 𝗦𝗘𝗖𝗧𝗜𝗢𝗡𝗦 』
╚═══◇◆◇════════════╝
│ 1️⃣  ⚡ *Core Menu*
│ 2️⃣  🌐 *General Menu*
│ 3️⃣  👮 *Admin Menu*
│ 4️⃣  👑 *Owner Menu*
│ 5️⃣  🖼️ *Media Menu*
│ 6️⃣  🇵🇷 *Pies Menu*
│ 7️⃣  🎮 *Games Menu*
│ 8️⃣  🤖 *AI Menu*
│ 9️⃣  🎯 *Fun Menu*
│ 🔟  🔤 *Text Menu*
│ 1️⃣1️⃣ 📥 *Download Menu*
│ 1️⃣2️⃣ 🧩 *Misc Menu*
│ 1️⃣3️⃣ 🖼️ *Anime Menu*
│ 1️⃣4️⃣ 💻 *Github Menu*
───────────────────

╔════◇◆◇══════════╗
『⚡ *𝗖𝗢𝗥𝗘 𝗠𝗘𝗡𝗨* 』
╚════◇◆◇══════════╝

╭━[🔧*𝗘𝗦𝗦𝗘𝗡𝗧𝗜𝗔𝗟𝗦* ]━━╮
│ • *help*
│ • *ping*
│ • *alive*
│ • *tts* [text]
│ • *owner*
│ • *settings*
╰━━━━━━━━━━━━━━━━━╯
──────────────────

╔════◇◆◇══════════╗
『🌐 *𝗚𝗘𝗡𝗘𝗥𝗔𝗟 𝗠𝗘𝗡𝗨* 』
╚════◇◆◇══════════╝
╭─━📱*𝗨𝗧𝗜𝗟𝗜𝗧𝗜𝗘𝗦* ━╮
│ • *menu*
│ • *quote*
│ • *joke*
│ • *fact*
│ • *weather* [city]
│ • *news*
│ • *attp* [text]
│ • *lyrics* [song]
╰━━━━━━━━━━━━━━━━━╯
╭─━〔 🔍 *𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡* 〕━╮
│ • *8ball* [question]
│ • *groupinfo*
│ • *admins*
│ • *staff*
│ • *vv*
│ • *simDetails* [num]
│ • *trt* [text] [lang]
│ • *ss* [link]
│ • *jid*
│ • *url*
│ • *gdesc*
│ • *topmembers*
╰━━━━━━━━━━━━━━━━━╯
───────────────────

╔════◇◆◇══════════╗
『👮 *𝗔𝗗𝗠𝗜𝗡 𝗠𝗘𝗡𝗨* 』
╚════◇◆◇══════════╝
╭━[🛡️*𝗠𝗔𝗡𝗔𝗚𝗘𝗠𝗘𝗡𝗧* ]━━╮
│ • *ban* @user
│ • *promote* @user
│ • *demote* @user
│ • *mute* [minutes]
│ • *unmute*
│ • *delete* / *del*
│ • *kick* @user
╰━━━━━━━━━━━━━━━━━╯
╭─━⚡*𝗦𝗘𝗖𝗨𝗥𝗜𝗧𝗬* ─━╮
│ • *warnings* @user
│ • *warn* @user
│ • *antilink*
│ • *antibadword*
│ • *clear*
╰─────────────────╯
╭─━〔 🏷️ *𝗧𝗔𝗚𝗚𝗜𝗡𝗚* 〕━╮
│ • *tag* [text]
│ • *tagall*
│ • *tagnotadmin*
│ • *hidetag* [text]
╰━━━━━━━━━━━━━━━━━╯
╭─━〔 ⚙️ *𝗦𝗘𝗧𝗧𝗜𝗡𝗚𝗦* 〕━╮
│ • *chatbot*
│ • *resetlink*
│ • *antitag* [on/off]
│ • *welcome* [on/off]
│ • *goodbye* [on/off]
│ • *setgdesc*
│ • *setgname*
│ • *setgpp*
│ • *add* @user
│ • *left*
╰━━━━━━━━━━━━━━━━━╯
───────────────────

╔════◇◆◇══════════╗
『👑 *𝗢𝗪𝗡𝗘𝗥 𝗠𝗘𝗡𝗨* 』
╚════◇◆◇══════════╝
╭─━⚙️*𝗦𝗬𝗦𝗧𝗘𝗠 𝗖𝗢𝗡𝗧𝗥𝗢𝗟* ━╮
│ • *mode* [public/private]
│ • *clearsession*
│ • *antidelete*
│ • *cleartmp*
│ • *update*
│ • *settings*
│ • *setpp*
╰━━━━━━━━━━━━━━━━━╯
╭─━ 🔧 *𝗔𝗨𝗧𝗢𝗠𝗔𝗧𝗜𝗢𝗡* ━╮
│ • *autoreact* [on/off]
│ • *autostatus* [on/off]
│ • *autostatus react* [on/off]
│ • *autotyping* [on/off]
│ • *autoread* [on/off]
│ • *anticall* [on/off]
│ • *pmblocker* [on/off/status]
│ • *pmblocker setmsg* [text]
│ • *setmention*
│ • *mention* [on/off]
│ • *autosave*
╰━━━━━━━━━━━━━━━━━╯
───────────────────

╔════◇◆◇══════════╗
『🖼️ *𝗠𝗘𝗗𝗜𝗔 𝗠𝗘𝗡𝗨* 』
╚════◇◆◇══════════╝
╭─━ 🎭 *𝗜𝗠𝗔𝗚𝗘 𝗧𝗢𝗢𝗟𝗦* ━╮
│ • *blur*
│ • *simage*
│ • *sticker*
│ • *removebg*
│ • *remini*
│ • *crop*
│ • *tgsticker* [link]
│ • *meme*
│ • *take* [packname]
│ • *emojimix* 😎+😂
│ • *igs* [link]
│ • *igsc* [link]
╰━━━━━━━━━━━━━━━━━╯
───────────────────

╔═════◇◆◇═════════╗
『🇵🇷 *𝗣𝗜𝗘𝗦 𝗠𝗘𝗡𝗨* 』
╚═════◇◆◇═════════╝
╭─━ 🎭 *𝗖𝗢𝗨𝗡𝗧𝗥𝗬 𝗣𝗜𝗘𝗦* ━╮
│ • *pies* [country]
│ • *china*
│ • *indonesia*
│ • *japan*
│ • *korea*
│ • *hijab*
╰━━━━━━━━━━━━━━━━━╯
───────────────────

╔════◇◆◇══════════╗
『🎮 *𝗚𝗔𝗠𝗘𝗦 𝗠𝗘𝗡𝗨* 』
╚════◇◆◇══════════╝
╭─━ 🎲 *𝗠𝗨𝗟𝗧𝗜𝗣𝗟𝗔𝗬𝗘𝗥* ━╮
│ • *tictactoe* @user
│ • *hangman*
│ • *guess* [letter]
│ • *trivia*
│ • *answer* [text]
│ • *truth*
│ • *dare*
╰━━━━━━━━━━━━━━━━━╯
───────────────────

╔════◇◆◇══════════╗
『🤖 *𝗔𝗜 𝗠𝗘𝗡𝗨* 』
╚════◇◆◇══════════╝
╭─━ 💬 *𝗔𝗜 𝗖𝗛𝗔𝗧𝗕𝗢𝗧𝗦* ━╮
│ • *gpt* [prompt]
│ • *gemini* [prompt]
│ • *imagine* [prompt]
│ • *flux* [prompt]
│ • *sora* [prompt]
╰━━━━━━━━━━━━━━━━━╯
───────────────────

╔════◇◆◇══════════╗
『🎯 *𝗙𝗨𝗡 𝗠𝗘𝗡𝗨* 』
╚════◇◆◇══════════╝
╭─━ 🎭 *𝗜𝗡𝗧𝗘𝗥𝗔𝗖𝗧𝗜𝗩𝗘* ━╮
│ • *compliment* @user
│ • *insult* @user
│ • *flirt*
│ • *shayari*
│ • *goodnight*
│ • *roseday*
│ • *character* @user
│ • *wasted* @user
│ • *ship* @user
│ • *simp* @user
│ • *stupid* @user [text]
╰━━━━━━━━━━━━━━━━━╯
───────────────────

╔════◇◆◇══════════╗
『🔤 *𝗧𝗘𝗫𝗧 𝗠𝗘𝗡𝗨* 』
╚════◇◆◇══════════╝
╭─━ ✨ *𝗧𝗘𝗫𝗧 𝗦𝗧𝗬𝗟𝗘𝗦* ━╮
│ • *metallic*
│ • *ice*
│ • *snow*
│ • *impressive*
│ • *matrix*
│ • *light*
│ • *neon*
│ • *devil*
│ • *purple*
│ • *thunder*
│ • *leaves*
│ • *1917*
│ • *arena*
│ • *hacker*
│ • *sand*
│ • *blackpink*
│ • *glitch*
│ • *fire*
╰━━━━━━━━━━━━━━━━━╯
───────────────────

╔════◇◆◇══════════╗
『📥 *𝗗𝗢𝗪𝗡𝗟𝗢𝗔𝗗 𝗠𝗘𝗡𝗨* 』
╚════◇◆◇══════════╝
╭━[🎵*𝗠𝗨𝗦𝗜𝗖/𝗩𝗜𝗗𝗘𝗢* ]━━╮
│ • *play*
│ • *song*
│ • *spotify*
│ • *instagram* [link]
│ • *facebook* [link]
│ • *tiktok* [link]
│ • *video* [name]
│ • *ytmp4* [link]
│ • *save* (reply status)
╰━━━━━━━━━━━━━━━━━╯
───────────────────

╔════◇◆◇══════════╗
『🧩 *𝗠𝗜𝗦𝗖 𝗠𝗘𝗡𝗨* 』
╚════◇◆◇══════════╝
╭─━ 🎭 *𝗘𝗙𝗙𝗘𝗖𝗧𝗦 & 𝗧𝗢𝗢𝗟𝗦* ━╮
│ • *heart*
│ • *horny*
│ • *circle*
│ • *lgbt*
│ • *lolice*
│ • *its-so-stupid*
│ • *namecard*
│ • *oogway*
│ • *tweet*
│ • *ytcomment*
│ • *comrade*
│ • *gay*
│ • *glass*
│ • *jail*
│ • *passed*
│ • *triggered*
│ • *encrypt* [text]
│ • *decrypt* [text]
╰━━━━━━━━━━━━━━━━━╯
───────────────────

╔════◇◆◇══════════╗
『🖼️ *𝗔𝗡𝗜𝗠𝗘 𝗠𝗘𝗡𝗨* 』
╚════◇◆◇══════════╝
╭─━ 🎌 *𝗔𝗡𝗜𝗠𝗘 𝗥𝗘𝗔𝗖𝗧𝗦* ━╮
│ • *neko*
│ • *waifu*
│ • *loli*
│ • *nom*
│ • *poke*
│ • *cry*
│ • *kiss*
│ • *pat*
│ • *hug*
│ • *wink*
│ • *facepalm*
╰━━━━━━━━━━━━━━━━━╯
───────────────────

╔════◇◆◇══════════╗
『💻 *𝗚𝗜𝗧𝗛𝗨𝗕 𝗠𝗘𝗡𝗨* 』
╚════◇◆◇══════════╝
╭─━ 🧷 *𝗥𝗘𝗣𝗢 𝗧𝗢𝗢𝗟𝗦* ━╮
│ • *git*
│ • *github*
│ • *sc*
│ • *script*
│ • *repo*
╰━━━━━━━━━━━━━━━━━╯
───────────────────

╔═══════◇◆◇═══════╗
『✨*𝗕𝗢𝗧 𝗖𝗢𝗡𝗧𝗥𝗢𝗟𝗦*✨ 』
╚═══════◇◆◇═══════╝
⟦★⟧────────────────
│ • *menu*
│ • *help*
│ • *alive*
│ • *restart*
⟦★⟧────────────────
> *© 𝙿𝙾𝚆𝙴𝚁𝙴𝙳 𝙱𝚈 ${settings.botName || 'NASIR-MD'}*
> *📢 ${global.channelLink || 'Join our channel!'}*`;



    try {
        const imagePath = path.join(__dirname, '../assets/bot_image.jpg');
        const mp3Path = path.join(__dirname, '../assets/Hacker.mp3');
        let menuMsg;
        
        if (fs.existsSync(imagePath)) {
            const imageBuffer = fs.readFileSync(imagePath);
            
            menuMsg = await sock.sendMessage(chatId, {
                image: imageBuffer,
                caption: helpMessage,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363404049028072@newsletter',
                        newsletterName: 'NASIR-MD BOT',
                        serverMessageId: -1
                    }
                }
            },{ quoted: message });

            // Send Hacker.mp3 as a reply to the menu message
            if (fs.existsSync(mp3Path)) {
                const mp3Buffer = fs.readFileSync(mp3Path);
                await sock.sendMessage(chatId, {
                    audio: mp3Buffer,
                    mimetype: 'audio/mpeg'
                }, { quoted: menuMsg });
            } else {
                console.error('Hacker.mp3 not found at:', mp3Path);
            }
        } else {
            console.error('Bot image not found at:', imagePath);
            menuMsg = await sock.sendMessage(chatId, { 
                text: helpMessage,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363404049028072@newsletter',
                        newsletterName: 'NASIR-MD BOT BY NASIR HACKER',
                        serverMessageId: -1
                    } 
                }
            });

            // Send Hacker.mp3 as a reply to the menu message
            if (fs.existsSync(mp3Path)) {
                const mp3Buffer = fs.readFileSync(mp3Path);
                await sock.sendMessage(chatId, {
                    audio: mp3Buffer,
                    mimetype: 'audio/mpeg'
                }, { quoted: menuMsg });
            } else {
                console.error('Hacker.mp3 not found at:', mp3Path);
            }
        }
    } catch (error) {
        console.error('Error in help command:', error);
        const menuMsg = await sock.sendMessage(chatId, { text: helpMessage });

        // Send Hacker.mp3 as a reply to the menu message
        const mp3Path = path.join(__dirname, '../assets/Hacker.mp3');
        if (fs.existsSync(mp3Path)) {
            const mp3Buffer = fs.readFileSync(mp3Path);
            await sock.sendMessage(chatId, {
                audio: mp3Buffer,
                mimetype: 'audio/mpeg'
            }, { quoted: menuMsg });
        } else {
            console.error('Hacker.mp3 not found at:', mp3Path);
        }
    }
}

module.exports = helpCommand;