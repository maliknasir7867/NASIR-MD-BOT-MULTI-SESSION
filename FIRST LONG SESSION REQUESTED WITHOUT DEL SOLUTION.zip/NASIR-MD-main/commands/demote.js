const isAdmin = require('../lib/isAdmin');

// Set Pakistani time (UTC+5)
const PAKISTAN_TIME_OPTIONS = {
    timeZone: 'Asia/Karachi',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: true
};

// Get current Pakistani time
function getPakistanTime() {
    return new Date().toLocaleString('en-PK', PAKISTAN_TIME_OPTIONS);
}

// DEMOTION TEMPLATES - Choose your favorite
const DEMOTION_TEMPLATES = {
    // Template 1: Box Design
    BOX_DESIGN: (usernames, demoter, count, participants) => 
        `╔═══════════════════╗\n` +
        `║   ⬇️ DEMOTION     ║\n` +
        `╚═══════════════════╝\n\n` +
        `📌 *Demoted Admin${count > 1 ? 's' : ''}:*\n` +
        `${usernames.map(name => `  └─ ${name}`).join('\n')}\n\n` +
        `👤 *Demoted By:* ${demoter}\n` +
        `🕐 *Pakistan Time:* ${getPakistanTime()}`,

    // Template 2: Warning Style
    WARNING: (usernames, demoter, count, participants) => 
        `⚠️ *ADMIN DEMOTION*\n\n` +
        `🚫 *Removed Admin${count > 1 ? 's' : ''}:*\n` +
        `${usernames.map(name => `▸ ${name}`).join('\n')}\n\n` +
        `👮 *Demoted By:* ${demoter}\n` +
        `🕒 *Time (PKT):* ${getPakistanTime()}\n` +
        `📊 *Type:* Manual Demotion`,

    // Template 3: Professional
    PROFESSIONAL: (usernames, demoter, count, participants) => 
        `📢 *Administrative Demotion*\n\n` +
        `**Demoted Administrator${count > 1 ? 's' : ''}:**\n` +
        `${usernames.map(name => `✗ ${name}`).join('\n')}\n\n` +
        `**Demoted By:** ${demoter}\n` +
        `**Demotion Date:** ${getPakistanTime()}\n\n` +
        `_Administrative privileges have been removed._`,

    // Template 4: Minimal
    MINIMAL: (usernames, demoter, count, participants) => 
        `📉 *Demotion Update*\n\n` +
        `👥 *Removed Admin${count > 1 ? 's' : ''}:*\n` +
        `${usernames.map(name => `• ${name}`).join('\n')}\n\n` +
        `👑 *Demoted By:* ${demoter}\n` +
        `📅 *Pakistan Time:* ${getPakistanTime()}`,

    // Template 5: Decorative
    DECORATIVE: (usernames, demoter, count, participants) => 
        `✧･ﾟ: *✧･ﾟ:* DEMOTION *:･ﾟ✧:･ﾟ✧*\n\n` +
        `📉 *Demoted Admin${count > 1 ? 's' : ''}:*\n` +
        `${usernames.map(name => `» ${name}`).join('\n')}\n\n` +
        `👑 *Demoted By:* ${demoter}\n` +
        `⏰ *PKT:* ${getPakistanTime()}\n\n` +
        `🔓 _Admin powers removed!_`
};

// CHOOSE YOUR TEMPLATE HERE (change 'BOX_DESIGN' to any template name above)
const CURRENT_DEMOTION_TEMPLATE = 'BOX_DESIGN';

// Helper function to get user's display name
async function getUserDisplayName(sock, jid, groupId) {
    try {
        // Try to get from group participants first
        const metadata = await sock.groupMetadata(groupId);
        const participant = metadata.participants.find(p => p.id === jid);
        
        if (participant && participant.notify) {
            return participant.notify;
        }
        
        // Fallback to checking contact
        const [contact] = await sock.onWhatsApp(jid);
        if (contact && contact.exists && contact.pushname) {
            return contact.pushname;
        }
        
        // Last resort: return number
        return `@${jid.split('@')[0]}`;
    } catch (error) {
        return `@${jid.split('@')[0]}`;
    }
}

async function demoteCommand(sock, chatId, mentionedJids, message) {
    try {
        // First check if it's a group
        if (!chatId.endsWith('@g.us')) {
            await sock.sendMessage(chatId, { 
                text: '❌ This command can only be used in groups!'
            });
            return;
        }

        // Check admin status first, before any other operations
        try {
            const adminStatus = await isAdmin(sock, chatId, message.key.participant || message.key.remoteJid);
            
            if (!adminStatus.isBotAdmin) {
                await sock.sendMessage(chatId, { 
                    text: '❌ Error: Please make the bot an admin first to use this command.'
                });
                return;
            }

            if (!adminStatus.isSenderAdmin) {
                await sock.sendMessage(chatId, { 
                    text: '❌ Error: Only group admins can use the demote command.'
                });
                return;
            }
        } catch (adminError) {
            console.error('Error checking admin status:', adminError);
            await sock.sendMessage(chatId, { 
                text: '❌ Error: Please make sure the bot is an admin of this group.'
            });
            return;
        }

        let userToDemote = [];
        
        // Check for mentioned users
        if (mentionedJids && mentionedJids.length > 0) {
            userToDemote = mentionedJids;
        }
        // Check for replied message
        else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
            userToDemote = [message.message.extendedTextMessage.contextInfo.participant];
        }
        
        // If no user found through either method
        if (userToDemote.length === 0) {
            await sock.sendMessage(chatId, { 
                text: '❌ Error: Please mention the user or reply to their message to demote!'
            });
            return;
        }

        // Add delay to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 1000));

        await sock.groupParticipantsUpdate(chatId, userToDemote, "demote");
        
        // Get usernames for each demoted user
        const usernames = await Promise.all(userToDemote.map(async jid => {
            try {
                const name = await getUserDisplayName(sock, jid, chatId);
                return name;
            } catch (error) {
                return `@${jid.split('@')[0]}`;
            }
        }));

        // Add delay to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 500));

        // Get demoter's name
        const demoterJid = message.key.participant || message.key.remoteJid;
        let demoterName;
        try {
            demoterName = await getUserDisplayName(sock, demoterJid, chatId);
        } catch (error) {
            demoterName = `@${demoterJid.split('@')[0]}`;
        }

        // Get demotion message from template
        const demotionMessage = DEMOTION_TEMPLATES[CURRENT_DEMOTION_TEMPLATE](
            usernames,
            demoterName,
            userToDemote.length,
            userToDemote
        );
        
        await sock.sendMessage(chatId, { 
            text: demotionMessage,
            mentions: [...userToDemote, demoterJid]
        });
    } catch (error) {
        console.error('Error in demote command:', error);
        if (error.data === 429) {
            await new Promise(resolve => setTimeout(resolve, 2000));
            try {
                await sock.sendMessage(chatId, { 
                    text: '❌ Rate limit reached. Please try again in a few seconds.'
                });
            } catch (retryError) {
                console.error('Error sending retry message:', retryError);
            }
        } else {
            try {
                await sock.sendMessage(chatId, { 
                    text: '❌ Failed to demote user(s). Make sure the bot is admin and has sufficient permissions.'
                });
            } catch (sendError) {
                console.error('Error sending error message:', sendError);
            }
        }
    }
}

// Function to handle automatic demotion detection
async function handleDemotionEvent(sock, groupId, participants, author) {
    try {
        // Safety check for participants
        if (!Array.isArray(participants) || participants.length === 0) {
            return;
        }

        // Add delay to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 1000));

        // Get usernames for demoted participants
        const demotedUsernames = await Promise.all(participants.map(async jid => {
            const jidString = typeof jid === 'string' ? jid : (jid.id || jid.toString());
            try {
                const name = await getUserDisplayName(sock, jidString, groupId);
                return name;
            } catch (error) {
                return `@${jidString.split('@')[0]}`;
            }
        }));

        let demotedBy;
        let mentionList = participants.map(jid => {
            return typeof jid === 'string' ? jid : (jid.id || jid.toString());
        });

        // Get admin who performed the demotion
        if (author) {
            const authorJid = typeof author === 'string' ? author : (author.id || author.toString());
            
            try {
                const displayName = await getUserDisplayName(sock, authorJid, groupId);
                demotedBy = displayName;
                
                // Add author to mention list
                if (!mentionList.includes(authorJid)) {
                    mentionList.push(authorJid);
                }
            } catch (error) {
                demotedBy = `@${authorJid.split('@')[0]}`;
            }
        } else {
            demotedBy = 'System';
        }

        // Add delay to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 500));

        // Get demotion message from template
        const demotionMessage = DEMOTION_TEMPLATES[CURRENT_DEMOTION_TEMPLATE](
            demotedUsernames,
            demotedBy,
            participants.length,
            participants
        );
        
        await sock.sendMessage(groupId, {
            text: demotionMessage,
            mentions: mentionList
        });
    } catch (error) {
        console.error('Error handling demotion event:', error);
        if (error.data === 429) {
            await new Promise(resolve => setTimeout(resolve, 2000));
        }
    }
}

module.exports = { demoteCommand, handleDemotionEvent };