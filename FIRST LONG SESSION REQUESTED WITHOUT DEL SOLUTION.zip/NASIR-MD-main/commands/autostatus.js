const fs = require('fs');
const path = require('path');
const isOwnerOrSudo = require('../lib/isOwner');
const { getSessionId } = require('../lib/sessionContext');
const sessionState = require('../lib/sessionState');
const { emojiDbPath } = require('./auto_status_react');

const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363404049028072@newsletter',
            newsletterName: 'NASIR-MD BOT',
            serverMessageId: -1
        }
    }
};

function getConfigPath() {
    // Per-session config so one user's AutoStatus toggle doesn't affect other sessions.
    try { sessionState.ensureSessionSkeleton(); } catch (_) {}
    return path.join(sessionState.sessionDataDir(), 'autoStatus.json');
}

function readConfig() {
    const configPath = getConfigPath();
    try {
        if (!fs.existsSync(configPath)) {
            try { fs.mkdirSync(path.dirname(configPath), { recursive: true }); } catch (_) {}
            fs.writeFileSync(configPath, JSON.stringify({ enabled: false, reactOn: false }, null, 2));
        }
        const raw = fs.readFileSync(configPath, 'utf8');
        const parsed = JSON.parse(raw || '{}');
        return {
            enabled: Boolean(parsed.enabled),
            reactOn: Boolean(parsed.reactOn)
        };
    } catch {
        return { enabled: false, reactOn: false };
    }
}

function writeConfig(next) {
    const configPath = getConfigPath();
    try { fs.mkdirSync(path.dirname(configPath), { recursive: true }); } catch (_) {}
    fs.writeFileSync(configPath, JSON.stringify(next, null, 2));
}

// Per-user emoji list helpers (stored per sessionId)
function readEmojiDb() {
    try {
        if (!fs.existsSync(emojiDbPath)) return {};
        const raw = fs.readFileSync(emojiDbPath, 'utf-8');
        const parsed = JSON.parse(raw || '{}');
        return (parsed && typeof parsed === 'object') ? parsed : {};
    } catch {
        return {};
    }
}

function getEmojiForCurrentUser() {
    const sessionId = getSessionId();
    const db = readEmojiDb();
    const list = Array.isArray(db[sessionId]) ? db[sessionId].filter(Boolean) : [];
    const safeList = list.length ? list : ['💚']; // fallback if user never set any
    const idx = Math.floor(Math.random() * safeList.length);
    return safeList[idx] || '💚';
}

async function autoStatusCommand(sock, chatId, msg, args) {
    try {
        const senderId = msg.key.participant || msg.key.remoteJid;
        const isOwner = await isOwnerOrSudo(senderId, sock, chatId);
        
        if (!msg.key.fromMe && !isOwner) {
            await sock.sendMessage(chatId, { 
                text:
`╭━〔 ❌ 𝗔𝗖𝗖𝗘𝗦𝗦 𝗗𝗘𝗡𝗜𝗘𝗗 〕━┈⊷
┃ This command can only be used by the owner!
╰━━━━━━━━━━━━━━━━┈⊷`,
                ...channelInfo
            });
            return;
        }

        // Read current config
        let config = readConfig();

        // If no arguments, show current status
        if (!args || args.length === 0) {
            const status = config.enabled ? '✅ Enabled' : '❌ Disabled';
            const reactStatus = config.reactOn ? '✅ Enabled' : '❌ Disabled';

            await sock.sendMessage(chatId, { 
                text:
`╭━〔 🔄 𝗔𝗨𝗧𝗢 𝗦𝗧𝗔𝗧𝗨𝗦 𝗦𝗘𝗧𝗧𝗜𝗡𝗚𝗦 〕┈⊷
┃ 📱 Auto Status View : ${status}
┃ 💫 Status Reactions : ${reactStatus}
┃
┃ 🛠️ 𝗖𝗢𝗠𝗠𝗔𝗡𝗗𝗦
┃ • .autostatus on
┃ • .autostatus off
┃ • .autostatus react on
┃ • .autostatus react off
╰━━━━━━━━━━━━━━━━┈⊷`,
                ...channelInfo
            });
            return;
        }

        // Handle on/off commands
        const command = args[0].toLowerCase();
        
        if (command === 'on') {
            config.enabled = true;
            writeConfig(config);
            await sock.sendMessage(chatId, { 
                text:
`╭━〔 ✅ 𝗔𝗨𝗧𝗢 𝗦𝗧𝗔𝗧𝗨𝗦 𝗢𝗡 ━┈⊷
┃ Auto status view has been enabled!
┃ Bot will now view all contact statuses.
╰━━━━━━━━━━━━━━┈⊷`,
                ...channelInfo
            });

        } else if (command === 'off') {
            config.enabled = false;
            writeConfig(config);
            await sock.sendMessage(chatId, { 
                text:
`╭━〔 ❌ 𝗔𝗨𝗧𝗢 𝗦𝗧𝗔𝗧𝗨𝗦 𝗢𝗙𝗙 〕┈⊷
┃ Auto status view has been disabled!
┃ Bot will no longer view statuses.
╰━━━━━━━━━━━━━━━┈⊷`,
                ...channelInfo
            });

        } else if (command === 'react') {
            // Handle react subcommand
            if (!args[1]) {
                await sock.sendMessage(chatId, { 
                    text:
`╭━〔 ❌ 𝗠𝗜𝗦𝗦𝗜𝗡𝗚 𝗔𝗥𝗚𝗨𝗠𝗘𝗡𝗧〕┈⊷
┃ Please specify on/off for reactions!
┃ Use: .autostatus react on/off
╰━━━━━━━━━━━━━━━━┈⊷`,
                    ...channelInfo
                });
                return;
            }
            
            const reactCommand = args[1].toLowerCase();
            if (reactCommand === 'on') {
                config.reactOn = true;
                writeConfig(config);
                await sock.sendMessage(chatId, { 
                    text:
`╭━〔 💫 𝗥𝗘𝗔𝗖𝗧𝗜𝗢𝗡𝗦 𝗢𝗡 〕━┈⊷
┃ Status reactions have been enabled!
┃ Bot will now react to status updates.
╰━━━━━━━━━━━━━━━━┈⊷`,
                    ...channelInfo
                });

            } else if (reactCommand === 'off') {
                config.reactOn = false;
                writeConfig(config);
                await sock.sendMessage(chatId, { 
                    text:
`╭━〔 ❌ 𝗥𝗘𝗔𝗖𝗧𝗜𝗢𝗡𝗦 𝗢𝗙𝗙 〕┈⊷
┃ Status reactions have been disabled!
┃ Bot will no longer react to status updates.
╰━━━━━━━━━━━━━━━━┈⊷`,
                    ...channelInfo
                });

            } else {
                await sock.sendMessage(chatId, { 
                    text:
`╭━〔 ❌ 𝗜𝗡𝗩𝗔𝗟𝗜𝗗 𝗖𝗢𝗠𝗠𝗔𝗡𝗗 〕━┈⊷
┃ Use: .autostatus react on/off
╰━━━━━━━━━━━━━━━━━┈⊷`,
                    ...channelInfo
                });
            }

        } else {
            await sock.sendMessage(chatId, { 
                text:
`╭━〔 ❌ 𝗜𝗡𝗩𝗔𝗟𝗜𝗗 𝗖𝗢𝗠𝗠𝗔𝗡𝗗 〕┈⊷
┃ Use:
┃ • .autostatus on/off
┃ • .autostatus react on/off
╰━━━━━━━━━━━━━━━━━┈⊷`,
                ...channelInfo
            });
        }

    } catch (error) {
        console.error('Error in autostatus command:', error);
        await sock.sendMessage(chatId, { 
            text:
`╭━〔 ❌ 𝗘𝗥𝗥𝗢𝗥 〕━┈⊷
┃ Error occurred while managing auto status!
┃ ${error.message}
╰━━━━━━━━━━━━━━━━━┈⊷`,
            ...channelInfo
        });
    }
}

// Function to check if auto status is enabled
function isAutoStatusEnabled() {
    try {
        const config = readConfig();
        return config.enabled;
    } catch (error) {
        console.error('Error checking auto status config:', error);
        return false;
    }
}

// Function to check if status reactions are enabled
function isStatusReactionEnabled() {
    try {
        const config = readConfig();
        return config.reactOn;
    } catch (error) {
        console.error('Error checking status reaction config:', error);
        return false;
    }
}

// Function to react to status using proper method
async function reactToStatus(sock, statusKey) {
    try {
        if (!isStatusReactionEnabled()) return;

        // Status reactions require the author JID in statusJidList.
        // Passing status@broadcast here breaks reactions.
        const authorJid = statusKey.participant || statusKey.remoteJid;
        if (!authorJid || authorJid === 'status@broadcast') return;

        const emoji = getEmojiForCurrentUser();

        await sock.relayMessage(
            'status@broadcast',
            {
                reactionMessage: {
                    key: {
                        remoteJid: 'status@broadcast',
                        id: statusKey.id,
                        participant: authorJid,
                        fromMe: false
                    },
                    text: emoji
                }
            },
            {
                messageId: statusKey.id,
                statusJidList: [authorJid]
            }
        );
    } catch (error) {
        console.error('❌ Error reacting to status:', error.message);
    }
}

// Function to handle status updates
async function handleStatusUpdate(sock, status) {
    try {
        if (!isAutoStatusEnabled()) {
            return;
        }

        // Add delay to prevent rate limiting
        await new Promise(resolve => setTimeout(resolve, 1000));

        // Handle status from messages.upsert
        if (status.messages && status.messages.length > 0) {
            const msg = status.messages[0];
            if (msg.key && msg.key.remoteJid === 'status@broadcast') {
                try {
                    await sock.readMessages([msg.key]);
                    const sender = msg.key.participant || msg.key.remoteJid;
                    // Some Baileys builds require an explicit read receipt for statuses
                    // to count as "viewed".
                    try {
                        if (sock.sendReadReceipt && sender && sender !== 'status@broadcast') {
                            await sock.sendReadReceipt('status@broadcast', sender, [msg.key.id]);
                        }
                    } catch (_) {}
                    
                    // React to status if enabled
                    await reactToStatus(sock, msg.key);
                } catch (err) {
                    if (err.message?.includes('rate-overlimit')) {
                        console.log('⚠️ Rate limit hit, waiting before retrying...');
                        await new Promise(resolve => setTimeout(resolve, 2000));
                        await sock.readMessages([msg.key]);
                    } else {
                        throw err;
                    }
                }
                return;
            }
        }

        // Handle direct status updates
        if (status.key && status.key.remoteJid === 'status@broadcast') {
            try {
                await sock.readMessages([status.key]);
                const sender = status.key.participant || status.key.remoteJid;
                try {
                    if (sock.sendReadReceipt && sender && sender !== 'status@broadcast') {
                        await sock.sendReadReceipt('status@broadcast', sender, [status.key.id]);
                    }
                } catch (_) {}
                
                // React to status if enabled
                await reactToStatus(sock, status.key);
            } catch (err) {
                if (err.message?.includes('rate-overlimit')) {
                    console.log('⚠️ Rate limit hit, waiting before retrying...');
                    await new Promise(resolve => setTimeout(resolve, 2000));
                    await sock.readMessages([status.key]);
                } else {
                    throw err;
                }
            }
            return;
        }

        // Handle status in reactions
        if (status.reaction && status.reaction.key.remoteJid === 'status@broadcast') {
            try {
                await sock.readMessages([status.reaction.key]);
                const sender = status.reaction.key.participant || status.reaction.key.remoteJid;
                try {
                    if (sock.sendReadReceipt && sender && sender !== 'status@broadcast') {
                        await sock.sendReadReceipt('status@broadcast', sender, [status.reaction.key.id]);
                    }
                } catch (_) {}
                
                // React to status if enabled
                await reactToStatus(sock, status.reaction.key);
            } catch (err) {
                if (err.message?.includes('rate-overlimit')) {
                    console.log('⚠️ Rate limit hit, waiting before retrying...');
                    await new Promise(resolve => setTimeout(resolve, 2000));
                    await sock.readMessages([status.reaction.key]);
                } else {
                    throw err;
                }
            }
            return;
        }

    } catch (error) {
        console.error('❌ Error in auto status view:', error.message);
    }
}

module.exports = {
    autoStatusCommand,
    handleStatusUpdate
};
