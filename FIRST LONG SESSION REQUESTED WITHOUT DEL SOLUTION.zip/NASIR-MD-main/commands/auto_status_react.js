const fs = require('fs');
const path = require('path');
const { getSessionId } = require('../lib/sessionContext');

// Per-user (per session) emoji list storage
const emojiDbPath = path.join(__dirname, '../data/autoStatusReactEmojis.json');

// Ensure DB exists
function ensureDb() {
  try {
    if (!fs.existsSync(emojiDbPath)) {
      fs.writeFileSync(emojiDbPath, JSON.stringify({}), 'utf-8');
    }
  } catch (e) {
    // If filesystem is read-only or any issue, throw to be handled by caller
    throw e;
  }
}

function readDb() {
  ensureDb();
  try {
    const raw = fs.readFileSync(emojiDbPath, 'utf-8');
    const parsed = JSON.parse(raw || '{}');
    return (parsed && typeof parsed === 'object') ? parsed : {};
  } catch {
    // Reset to empty object on corruption
    fs.writeFileSync(emojiDbPath, JSON.stringify({}), 'utf-8');
    return {};
  }
}

function writeDb(db) {
  ensureDb();
  fs.writeFileSync(emojiDbPath, JSON.stringify(db, null, 2), 'utf-8');
}

/**
 * Basic emoji validation.
 * Accepts most emoji sequences (including ZWJ sequences and variation selectors),
 * while rejecting plain text.
 */
function isValidEmoji(str) {
  if (!str || typeof str !== 'string') return false;
  const s = str.trim();
  if (!s) return false;

  // Must contain at least one Extended Pictographic code point
  const hasPictographic = /\p{Extended_Pictographic}/u.test(s);
  if (!hasPictographic) return false;

  // Only allow emoji components, ZWJ, variation selectors, and pictographic chars
  const ok = /^(?:\p{Extended_Pictographic}|\p{Emoji_Component}|\u200D|\uFE0F|\uFE0E)+$/u.test(s);
  return ok;
}

function parseEmojiList(input) {
  const raw = String(input || '').trim();
  if (!raw) return { ok: false, error: 'Empty emoji list. Example: .auto_status_react=💋,🤝,🙂' };

  const parts = raw.split(',').map(s => s.trim()).filter(Boolean);
  if (parts.length === 0) return { ok: false, error: 'Empty emoji list. Example: .auto_status_react=💋,🤝,🙂' };

  const invalid = parts.filter(e => !isValidEmoji(e));
  if (invalid.length) {
    return { ok: false, error: `Invalid emoji detected: ${invalid.join(' ')}\nUse only emojis separated by commas.` };
  }

  // De-duplicate while preserving order
  const seen = new Set();
  const unique = [];
  for (const e of parts) {
    if (!seen.has(e)) {
      seen.add(e);
      unique.push(e);
    }
  }

  if (unique.length === 0) return { ok: false, error: 'Emoji list cannot be empty.' };

  const hadDuplicates = unique.length !== parts.length;
  return { ok: true, list: unique, hadDuplicates };
}

async function autoStatusReactCommand(sock, chatId, msg, userMessage) {
  try {
    const sessionId = getSessionId();

    // Show current list
    if (userMessage === '.auto_status_react' || userMessage === '.auto_status_react ') {
      const db = readDb();
      const list = Array.isArray(db[sessionId]) ? db[sessionId] : null;
      const shown = (list && list.length) ? list.join(', ') : '💚 (default)';

      await sock.sendMessage(chatId, {
        text:
`╭━━━〔 🧩 𝗔𝗨𝗧𝗢 𝗦𝗧𝗔𝗧𝗨𝗦 𝗥𝗘𝗔𝗖𝗧 〕━━━┈⊷
┃ 📌 𝗬𝗼𝘂𝗿 𝗘𝗺𝗼𝗷𝗶𝘀:
┃ ${shown}
┃
┃ ✅ 𝗦𝗲𝘁 𝗡𝗲𝘄:
┃ .auto_status_react=💋,🤝,🙂
╰━━━━━━━━━━━━━━━━━━━━━━━┈⊷`
      });

      return;
    }

    // Set list via .auto_status_react=...
    const prefix = '.auto_status_react=';
    if (!userMessage.startsWith(prefix)) {
      await sock.sendMessage(chatId, {
        text:
`╭━━━〔 ❌ 𝗜𝗡𝗩𝗔𝗟𝗜𝗗 𝗙𝗢𝗥𝗠𝗔𝗧 〕━━━┈⊷
┃ Use this:
┃ .auto_status_react=💋,🤝,🙂
╰━━━━━━━━━━━━━━━━━━━━━━━┈⊷`
      });
      return;
    }

    const value = userMessage.slice(prefix.length);
    const parsed = parseEmojiList(value);
    if (!parsed.ok) {
      await sock.sendMessage(chatId, {
        text:
`╭━━━〔 ❌ 𝗘𝗥𝗥𝗢𝗥 〕━━━┈⊷
┃ ${parsed.error}
╰━━━━━━━━━━━━━━━━━━━━━━━┈⊷`
      });
      return;
    }

    const db = readDb();
    db[sessionId] = parsed.list;
    writeDb(db);

    const dupNote = parsed.hadDuplicates
      ? `\n┃ ⚠️ Duplicates removed automatically.`
      : '';

    await sock.sendMessage(chatId, {
      text:
`╭━━━〔 ✅ 𝗦𝗔𝗩𝗘𝗗 〕━━━┈⊷
┃ 𝗦𝘁𝗮𝘁𝘂𝘀-𝗥𝗲𝗮𝗰𝘁 𝗘𝗺𝗼𝗷𝗶𝘀:
┃ ${parsed.list.join('  ')}${dupNote}
╰━━━━━━━━━━━━━━━━━━━━━━━┈⊷`
    });
  } catch (err) {
    console.error('Error in autoStatusReactCommand:', err);
    await sock.sendMessage(chatId, {
      text:
`╭━━━〔 ❌ 𝗙𝗔𝗜𝗟𝗘𝗗 〕━━━┈⊷
┃ Failed to save emojis.
┃ Please try again.
╰━━━━━━━━━━━━━━━━━━━━━━━┈⊷`
    });
  }
}

module.exports = {
  autoStatusReactCommand,
  parseEmojiList, // exported for reuse/testing
  isValidEmoji,
  emojiDbPath
};
