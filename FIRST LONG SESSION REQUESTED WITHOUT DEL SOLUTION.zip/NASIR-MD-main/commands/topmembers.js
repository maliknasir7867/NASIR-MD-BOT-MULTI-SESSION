// lib/topmember.js
const fs = require("fs");
const path = require("path");

const dataFilePath = path.join(__dirname, "..", "data", "messageCount.json");

function ensureDataFile() {
  try {
    const dir = path.dirname(dataFilePath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    if (!fs.existsSync(dataFilePath)) fs.writeFileSync(dataFilePath, JSON.stringify({}, null, 2));
  } catch (_) {}
}

function loadMessageCounts() {
  try {
    ensureDataFile();
    const raw = fs.readFileSync(dataFilePath, "utf8");
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function saveMessageCounts(messageCounts) {
  try {
    ensureDataFile();
    fs.writeFileSync(dataFilePath, JSON.stringify(messageCounts, null, 2));
  } catch (_) {}
}

function incrementMessageCount(groupId, userId) {
  try {
    if (!groupId || !userId) return;

    const messageCounts = loadMessageCounts();

    if (!messageCounts[groupId]) messageCounts[groupId] = {};
    if (!messageCounts[groupId][userId]) messageCounts[groupId][userId] = 0;

    messageCounts[groupId][userId] += 1;
    saveMessageCounts(messageCounts);
  } catch (_) {}
}

function toMention(userId) {
  return `@${String(userId).split("@")[0]}`;
}

async function topMembers(sock, chatId, isGroup, message, limit = 5) {
  try {
    if (!isGroup) {
      return sock.sendMessage(chatId, { text: "This command is only available in group chats." }, { quoted: message });
    }

    const messageCounts = loadMessageCounts();
    const groupCounts = messageCounts[chatId] || {};

    const sorted = Object.entries(groupCounts)
      .sort(([, a], [, b]) => b - a)
      .slice(0, Number(limit) || 5);

    if (!sorted.length) {
      return sock.sendMessage(chatId, { text: "No message activity recorded yet." }, { quoted: message });
    }

    // extra details (safe)
    let groupName = "Unknown";
    let membersCount = 0;
    let adminCount = 0;

    try {
      const meta = await sock.groupMetadata(chatId);
      groupName = meta?.subject || groupName;
      membersCount = Array.isArray(meta?.participants) ? meta.participants.length : 0;
      adminCount = Array.isArray(meta?.participants)
        ? meta.participants.filter(p => p?.admin === "admin" || p?.admin === "superadmin").length
        : 0;
    } catch (_) {}

    const mentions = sorted.map(([uid]) => uid);

    // Build stylish box (WhatsApp-friendly length)
    let text =
`╭━━〔 🏆 𝗧𝗢𝗣 𝗠𝗘𝗠𝗕𝗘𝗥𝗦 〕━━╮
┃ 📊 Based on messages
╰━━━━━━━━━━━━━━━━━━━━━━╯

▢ Group : *${groupName}*
▢ Members : *${membersCount || "?"}*
▢ Admins : *${adminCount || "?"}*

┌───⊷ 𝗥𝗔𝗡𝗞𝗜𝗡𝗚`;

    sorted.forEach(([uid, count], idx) => {
      const crown = idx === 0 ? "👑 " : "";
      text += `\n┃ ${idx + 1}. ${crown}👤 ${toMention(uid)}\n┃ 💬 Messages: ${count}\n┃`;
    });

    text += `\n└──✪ 𝗡𝗔𝗦𝗜𝗥-𝗠𝗗 ✪──┘`;

    return sock.sendMessage(
      chatId,
      { text, mentions },
      { quoted: message }
    );
  } catch (err) {
    console.error("topMembers error:", err);
    return sock.sendMessage(chatId, { text: "❌ Failed to process command!" }, { quoted: message });
  }
}

/**
 * IMPORTANT:
 * Export in a way that NEVER breaks regardless of how you require it.
 * This prevents: incrementMessageCount is not a function
 */
module.exports = topMembers; // if someone did: const topMembers = require(...)
module.exports.topMembers = topMembers;
module.exports.incrementMessageCount = incrementMessageCount;
module.exports.loadMessageCounts = loadMessageCounts;
module.exports.saveMessageCounts = saveMessageCounts;
