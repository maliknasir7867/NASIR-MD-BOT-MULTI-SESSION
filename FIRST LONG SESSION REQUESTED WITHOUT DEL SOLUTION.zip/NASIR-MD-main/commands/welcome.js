const { handleWelcome } = require('../lib/welcome');
const { isWelcomeOn, getWelcome } = require('../lib/index');
const { channelInfo } = require('../lib/messageConfig');
const fetch = require('node-fetch');
const config = require('../data/config'); // <-- added for owner & bot
const fs = require('fs');  // Add fs module to write to the data file

// Helper function to save join time in jointime.json
function saveJoinTime(groupId, participantId, joinTime) {
    const filePath = './data/jointime.json';

    // Read existing data
    let data = {};
    if (fs.existsSync(filePath)) {
        data = JSON.parse(fs.readFileSync(filePath));
    }

    // Save or update join time for the participant
    if (!data[groupId]) {
        data[groupId] = {};
    }
    data[groupId][participantId] = joinTime;

    // Save the updated data back to the file
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

async function welcomeCommand(sock, chatId, message, match) {
    if (!chatId.endsWith('@g.us')) {
        await sock.sendMessage(chatId, { text: 'This command can only be used in groups.' });
        return;
    }

    const text = message.message?.conversation ||
                 message.message?.extendedTextMessage?.text || '';
    const matchText = text.split(' ').slice(1).join(' ');

    await handleWelcome(sock, chatId, message, matchText);
}

async function handleJoinEvent(sock, id, participants) {

    const isWelcomeEnabled = await isWelcomeOn(id);
    if (!isWelcomeEnabled) return;

    const customMessage = await getWelcome(id);

    const groupMetadata = await sock.groupMetadata(id);
    const groupName = groupMetadata.subject;
    const groupDesc = groupMetadata.desc || 'No description available';
    const memberCount = groupMetadata.participants.length;

    // new: creation date
    const creationDate = new Date(groupMetadata.creation * 1000).toLocaleString("en-PK", {
        timeZone: "Asia/Karachi",
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        hour12: true
    });

    // new: admin count
    const adminCount = groupMetadata.participants.filter(p => p.admin).length;

    for (const participant of participants) {
        try {
            const participantString = typeof participant === 'string'
                ? participant
                : (participant.id || participant.toString());

            const user = participantString.split('@')[0];

            let displayName = user;
            try {
                const contact = await sock.getBusinessProfile(participantString);
                if (contact && contact.name) {
                    displayName = contact.name;
                } else {
                    const groupParticipants = groupMetadata.participants;
                    const userParticipant = groupParticipants.find(p => p.id === participantString);
                    if (userParticipant && userParticipant.name) {
                        displayName = userParticipant.name;
                    }
                }
            } catch (e) {}

            // new: user bio
            let bio = "";
            try {
                const status = await sock.fetchStatus(participantString);
                bio = status?.status || "";
            } catch {}

            // new: Pakistan time
            const now = new Date();
            const pakistanTime = now.toLocaleString("en-PK", {
                timeZone: "Asia/Karachi",
                month: "2-digit",
                day: "2-digit",
                year: "numeric",
                hour: "2-digit",
                minute: "2-digit",
                second: "2-digit",
                hour12: true
            });

            // Store join time for the user
            const joinTime = pakistanTime;
            saveJoinTime(id, participantString, joinTime);  // Save the join time in the data file

            // new replacements for custom message
            let finalMessage;

            if (customMessage) {
                finalMessage = customMessage
                    .replace(/{user}/g, `@${displayName}`)
                    .replace(/{group}/g, groupName)
                    .replace(/{description}/g, groupDesc)
                    .replace(/{member}/g, memberCount)
                    .replace(/{admincount}/g, adminCount)
                    .replace(/{creation}/g, creationDate)
                    .replace(/{owner}/g, config.owner)
                    .replace(/{bot}/g, config.botname)
                    .replace(/{bio}/g, bio)
                    .replace(/{time}/g, pakistanTime);
            } else {
                finalMessage = `╭╼━≪•𝙽𝙴𝚆 𝙼𝙴𝙼𝙱𝙴𝚁•≫━╾╮
┃𝚆𝙴𝙻𝙲𝙾𝙼𝙴: @${displayName} 👋
┃Members: #${memberCount}
┃Admins: ${adminCount}
┃Owner: ${config.owner}
┃Bot: ${config.botname}
┃User Bio: ${bio}
┃Group Created: ${creationDate}
┃Pakistan Time: ${pakistanTime}⏰
╰━━━━━━━━━━━━━━━╯

*@${displayName}* Welcome to *${groupName}*! 🎉
*Group Description:*
${groupDesc}

> *© Powered by ${config.botname}*`;
            }

            const channelForwardInfo = {
                contextInfo: {
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: "120363404049028072@newsletter",
                        newsletterName: "NASIR-MD BOT"
                    },
                    forwardingScore: 1,
                    isForwarded: true
                }
            };

            try {
                let profilePicUrl = `https://img.pyrocdn.com/dbKUgahg.png`;
                try {
                    const profilePic = await sock.profilePictureUrl(participantString, 'image');
                    if (profilePic) {
                        profilePicUrl = profilePic;
                    }
                } catch {}

                const apiUrl = `https://api.some-random-api.com/welcome/img/2/gaming3?type=join&textcolor=green&username=${encodeURIComponent(displayName)}&guildName=${encodeURIComponent(groupName)}&memberCount=${memberCount}&avatar=${encodeURIComponent(profilePicUrl)}`;

                const response = await fetch(apiUrl);
                if (response.ok) {
                    const imageBuffer = await response.buffer();
                    await sock.sendMessage(id, {
                        image: imageBuffer,
                        caption: finalMessage,
                        mentions: [participantString],
                        ...channelForwardInfo
                    });
                    continue;
                }
            } catch {}

            await sock.sendMessage(id, {
                text: finalMessage,
                mentions: [participantString],
                ...channelForwardInfo
            });

        } catch (error) {
            console.error('Error sending welcome message:', error);

            const participantString = typeof participant === 'string'
                ? participant
                : (participant.id || participant.toString());
            const user = participantString.split('@')[0];

            const now = new Date();
            const fallbackTime = now.toLocaleString("en-PK", {
                timeZone: "Asia/Karachi",
                hour: "2-digit",
                minute: "2-digit",
                hour12: true
            });

            let fallbackMessage;
            if (customMessage) {
                fallbackMessage = customMessage
                    .replace(/{user}/g, `@${user}`)
                    .replace(/{group}/g, groupName)
                    .replace(/{description}/g, groupDesc);
            } else {
                fallbackMessage = `Welcome @${user} to ${groupName}! 🎉\n🕒 Pakistan Time: ${fallbackTime}`;
            }

            const channelForwardInfo = {
                contextInfo: {
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: "120363404049028072@newsletter",
                        newsletterName: "NASIR-MD BOT"
                    },
                    forwardingScore: 1,
                    isForwarded: true
                }
            };

            await sock.sendMessage(id, {
                text: fallbackMessage,
                mentions: [participantString],
                ...channelForwardInfo
            });
        }
    }
}

module.exports = { welcomeCommand, handleJoinEvent, saveJoinTime };
