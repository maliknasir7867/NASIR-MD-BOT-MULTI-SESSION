// add.js (Fixed version)
// Command: .add <number>
// Works with your existing main.js command structure

module.exports = async function addCommand(sock, chatId, message, rawText) {
    try {
        const sender = message.key.participant || message.key.remoteJid;
        const isGroup = chatId.endsWith('@g.us');

        if (!isGroup) {
            return await sock.sendMessage(chatId, { text: '❌ This command can only be used in groups.' }, { quoted: message });
        }

        // Extract number
        const text = rawText.split(' ').slice(1).join(' ');
        if (!text) {
            return await sock.sendMessage(chatId, { text: '⚠️ Please provide a number. Example: .add 923001234567' }, { quoted: message });
        }

        let number = text.replace(/[^0-9]/g, '');
        if (number.length < 8) {
            return await sock.sendMessage(chatId, { text: '❌ Invalid number.' }, { quoted: message });
        }

        const jid = number + '@s.whatsapp.net';

        // Fetch group metadata
        const groupMetadata = await sock.groupMetadata(chatId);
        
        // Get bot's JID correctly
        const botJid = sock.user.id.split(':')[0] + '@s.whatsapp.net';
        
        // Find bot's participant info
        const botParticipant = groupMetadata.participants.find(p => p.id === botJid);
        const isBotAdmin = botParticipant && (
            botParticipant.admin === 'admin' || 
            botParticipant.admin === 'superadmin' ||
            botParticipant.isAdmin === true
        );

        // Check group settings
        const isAnnouncement = groupMetadata.announce === true;
        const isRestricted = groupMetadata.restrict === true;

        console.log('Bot Admin Status:', isBotAdmin);
        console.log('Group Announce:', isAnnouncement);
        console.log('Group Restrict:', isRestricted);

        // If bot is admin, it can always add members
        if (isBotAdmin) {
            await sock.groupParticipantsUpdate(chatId, [jid], 'add');
            return await sock.sendMessage(chatId, { 
                text: `✅ Added *${number}* to the group!` 
            }, { quoted: message });
        }

        // If bot is NOT admin but group allows anyone to add members
        if (!isAnnouncement && !isRestricted) {
            // In non-announcement groups, anyone can add members
            await sock.groupParticipantsUpdate(chatId, [jid], 'add');
            return await sock.sendMessage(chatId, { 
                text: `✅ Added *${number}* to the group!` 
            }, { quoted: message });
        }

        // If bot is not admin and group is restricted/announcement
        return await sock.sendMessage(chatId, { 
            text: `❌ Cannot add members. Bot needs admin rights or group must allow anyone to add members.\n\n💡 *Solutions:*\n• Make bot admin\n• Change group settings to allow anyone to add members` 
        }, { quoted: message });

    } catch (err) {
        console.error('ADD command error:', err);
        
        let errorMessage = '❌ Failed to add member.';
        if (err.message.includes('not authorized')) {
            errorMessage = '❌ Bot needs admin rights to add members in this group.';
        } else if (err.message.includes('invite')) {
            errorMessage = '❌ Cannot add this number. They may have privacy restrictions.';
        } else if (err.message.includes('401')) {
            errorMessage = '❌ Invalid number or number does not exist on WhatsApp.';
        }
        
        await sock.sendMessage(chatId, { text: errorMessage }, { quoted: message });
    }
};