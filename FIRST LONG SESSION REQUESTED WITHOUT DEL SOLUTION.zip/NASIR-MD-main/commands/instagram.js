const { igdl } = require("ruhend-scraper");

// Channel Forward Info
const channelInfo = {
    forwardingScore: 777,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363404049028072@newsletter',
        newsletterName: 'NASIR-MD BOT',
        serverMessageId: -1
    }
};

// Store processed message IDs to prevent duplicates
const processedMessages = new Set();

function igBox(query, typeLabel, itemLabel) {
    return `
╭━━〔 📥 𝗜𝗚 𝗗𝗢𝗪𝗡𝗟𝗢𝗔𝗗 〕━━╮
┃ 🎬 𝗧𝘆𝗽𝗲: ${typeLabel}
┃ 📦 𝗜𝘁𝗲𝗺: ${itemLabel}
┃ 🔗 𝗤𝘂𝗲𝗿𝘆: ${query}
╰━━━━━〔 𝗡𝗔𝗦𝗜𝗥-𝗠𝗗 〕━━━━━╯
`.trim();
}

// Function to extract unique media URLs
function extractUniqueMedia(mediaData) {
    const uniqueMedia = [];
    const seenUrls = new Set();

    for (const media of mediaData) {
        if (!media.url) continue;
        if (!seenUrls.has(media.url)) {
            seenUrls.add(media.url);
            uniqueMedia.push(media);
        }
    }
    return uniqueMedia;
}

function isValidMediaUrl(url) {
    if (!url || typeof url !== 'string') return false;
    return url.includes('cdninstagram.com') || 
           url.includes('instagram') || 
           url.includes('http');
}

async function instagramCommand(sock, chatId, message) {
    try {
        if (processedMessages.has(message.key.id)) return;

        processedMessages.add(message.key.id);
        setTimeout(() => processedMessages.delete(message.key.id), 5 * 60 * 1000);

        const text = message.message?.conversation || message.message?.extendedTextMessage?.text;

        if (!text) {
            return await sock.sendMessage(chatId, { 
                text: "Please provide an Instagram link for the video.",
                contextInfo: channelInfo
            });
        }

        const instagramPatterns = [
            /https?:\/\/(?:www\.)?instagram\.com\//,
            /https?:\/\/(?:www\.)?instagr\.am\//,
            /https?:\/\/(?:www\.)?instagram\.com\/p\//,
            /https?:\/\/(?:www\.)?instagram\.com\/reel\//,
            /https?:\/\/(?:www\.)?instagram\.com\/tv\//
        ];

        const isValidUrl = instagramPatterns.some(pattern => pattern.test(text));
        if (!isValidUrl) {
            return await sock.sendMessage(chatId, { 
                text: "That is not a valid Instagram link.",
                contextInfo: channelInfo
            });
        }

        await sock.sendMessage(chatId, {
            react: { text: '🔄', key: message.key }
        });

        const downloadData = await igdl(text);

        if (!downloadData || !downloadData.data || downloadData.data.length === 0) {
            return await sock.sendMessage(chatId, { 
                text: "❌ No media found. Post may be private.",
                contextInfo: channelInfo
            });
        }

        const mediaData = downloadData.data;
        const uniqueMedia = extractUniqueMedia(mediaData);
        const mediaToDownload = uniqueMedia.slice(0, 20);

        if (mediaToDownload.length === 0) {
            return await sock.sendMessage(chatId, { 
                text: "❌ No valid media found.",
                contextInfo: channelInfo
            });
        }

        const totalItems = mediaToDownload.length;
        const anyReel = text.includes('/reel/') || text.includes('/tv/');
        let boxSent = false;

        for (let i = 0; i < mediaToDownload.length; i++) {
            try {
                const media = mediaToDownload[i];
                const mediaUrl = media.url;

                if (!isValidMediaUrl(mediaUrl)) continue;

                const isVideo =
                    /\.(mp4|mov|avi|mkv|webm)$/i.test(mediaUrl) ||
                    media.type === 'video' ||
                    anyReel;

                if (!boxSent) {
                    const typeLabel = isVideo ? "Video" : "Media";
                    const boxText = igBox(text, typeLabel, `${totalItems}/${totalItems}`);
                    await sock.sendMessage(chatId, { 
                        text: boxText,
                        contextInfo: channelInfo
                    }, { quoted: message });
                    boxSent = true;
                }

                if (isVideo) {
                    await sock.sendMessage(chatId, {
                        video: { url: mediaUrl },
                        mimetype: "video/mp4",
                        caption: "𝗗𝗢𝗪𝗡𝗟𝗢𝗔𝗗 𝗦𝗨𝗖𝗖𝗘𝗦𝗦𝗙𝗨𝗟 🎬🚀",
                        contextInfo: channelInfo
                    }, { quoted: message });
                } else {
                    await sock.sendMessage(chatId, {
                        image: { url: mediaUrl },
                        caption: "𝗗𝗢𝗪𝗡𝗟𝗢𝗔𝗗 𝗦𝗨𝗖𝗖𝗘𝗦𝗦𝗙𝗨𝗟 🎬🚀",
                        contextInfo: channelInfo
                    }, { quoted: message });
                }

                if (i < mediaToDownload.length - 1) {
                    await new Promise(r => setTimeout(r, 1000));
                }

            } catch (mediaError) {
                console.error(`Error downloading media ${i + 1}:`, mediaError);
            }
        }

    } catch (error) {
        console.error('Error in Instagram command:', error);
        await sock.sendMessage(chatId, { 
            text: "❌ Error while processing Instagram download.",
            contextInfo: channelInfo
        });
    }
}

module.exports = instagramCommand;
