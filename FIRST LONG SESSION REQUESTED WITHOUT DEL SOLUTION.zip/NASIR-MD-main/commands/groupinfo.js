// Add a rate limiter at the top of your file or module
const rateLimit = new Map();

// ✅ ADDED: Channel Forward (Newsletter) info (for "Forwarded from Channel" look)
const NASIR_MD_CHANNEL_NAME = "NASIR-MD BOT";
const NASIR_MD_CHANNEL_JID = "120363404049028072@newsletter"; // <-- REPLACE with your real channel jid

function channelForwardContext() {
    return {
        forwardingScore: 999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: NASIR_MD_CHANNEL_JID,
            newsletterName: NASIR_MD_CHANNEL_NAME,
            serverMessageId: null
        }
    };
}

async function groupInfoCommand(sock, chatId, msg) {
    try {
        // Rate limiting check
        const now = Date.now();
        const lastRequest = rateLimit.get(chatId) || 0;
        const timeDiff = now - lastRequest;
        
        // Limit to 1 request every 5 seconds per chat
        if (timeDiff < 5000) {
            const waitTime = Math.ceil((5000 - timeDiff) / 1000);
            await sock.sendMessage(chatId, { 
                text:
`╭━〔 ⏳ 𝗣𝗟𝗘𝗔𝗦𝗘 𝗪𝗔𝗜𝗧 〕━┈⊷
┃ Slow down a bit 🙂
┃ Try again in: ${waitTime}s
╰━━━━━━━━━━━━━━━━┈⊷`,
                contextInfo: channelForwardContext()
            });
            return;
        }
        
        // Update rate limit timestamp
        rateLimit.set(chatId, now);
        
        // Clean old rate limit entries periodically (older than 1 hour)
        if (Math.random() < 0.01) { // 1% chance to clean up
            for (const [key, timestamp] of rateLimit.entries()) {
                if (now - timestamp > 3600000) { // 1 hour
                    rateLimit.delete(key);
                }
            }
        }

        // Get group metadata with retry logic
        let groupMetadata;
        let attempts = 0;
        const maxAttempts = 3;
        
        while (attempts < maxAttempts) {
            try {
                groupMetadata = await sock.groupMetadata(chatId);
                break;
            } catch (err) {
                attempts++;
                if (attempts === maxAttempts) throw err;
                
                // Wait before retry (exponential backoff)
                await new Promise(resolve => setTimeout(resolve, 1000 * attempts));
            }
        }
        
        // Get group profile picture with timeout
        let pp;
        try {
            const timeoutPromise = new Promise((_, reject) => {
                setTimeout(() => reject(new Error('Timeout')), 5000);
            });
            
            pp = await Promise.race([
                sock.profilePictureUrl(chatId, 'image'),
                timeoutPromise
            ]);
        } catch (error) {
            console.log('Using default profile picture due to error:', error.message);
            pp = 'https://i.imgur.com/2wzGhpF.jpeg';
        }

        // Get participants safely
        const participants = groupMetadata.participants || [];
        
        // Extract admins - different libraries may store admin status differently
        const groupAdmins = participants.filter(p => {
            // Check multiple possible admin property names and values
            if (p.admin === 'admin' || p.admin === 'superadmin' || p.admin === true) {
                return true;
            }
            if (p.isAdmin || p.isAdmin === true) {
                return true;
            }
            if (p.admin_type === 'admin' || p.admin_type === 'superadmin') {
                return true;
            }
            return false;
        });
        
        // Format admin list
        const listAdmin = groupAdmins.length > 0 
            ? groupAdmins.map((v, i) => {
                const userId = v.id || v.user || v.userId || '';
                const username = userId.split('@')[0] || 'unknown';
                return `${i + 1}. @${username}`;
            }).join('\n')
            : 'No admins found';
        
        // Get group owner
        let owner = groupMetadata.owner;
        if (!owner) {
            // Try different possible owner properties
            const creator = participants.find(p => 
                p.admin === 'superadmin' || 
                p.admin === 'creator' || 
                p.isSuperAdmin === true ||
                p.isCreator === true
            );
            owner = creator 
                ? (creator.id || creator.user || creator.userId) 
                : participants[0]?.id || chatId.split('-')[0] + '@s.whatsapp.net';
        }

        // Extract owner username safely
        const ownerUsername = (owner || '').split('@')[0] || 'unknown';

        // Create info text - keep it minimal to reduce API calls
        const text = `
╭━〔 📊 𝗚𝗥𝗢𝗨𝗣 𝗜𝗡𝗙𝗢 〕━┈⊷
┃ 🆔 𝗜𝗗: ${groupMetadata.id?.substring(0, 15) + '...' || 'N/A'}
┃ 📛 𝗡𝗮𝗺𝗲: ${groupMetadata.subject || 'No name'}
┃ 👥 𝗠𝗲𝗺𝗯𝗲𝗿𝘀: ${participants.length || 0}
┃ 👑 𝗢𝘄𝗻𝗲𝗿: @${ownerUsername}
┃ 🛡️ 𝗔𝗱𝗺𝗶𝗻𝘀: ${groupAdmins.length}
┃
┃ 👮 𝗔𝗱𝗺𝗶𝗻 𝗟𝗶𝘀𝘁:
${listAdmin}
${groupMetadata.desc ? `┃\n┃ 📝 𝗗𝗲𝘀𝗰𝗿𝗶𝗽𝘁𝗶𝗼𝗻:\n┃ ${groupMetadata.desc.substring(0, 200)}${groupMetadata.desc.length > 200 ? '...' : ''}` : ''}
╰━━━━━━━━━━━━━━━┈⊷
`.trim();

        // Prepare mentions array
        const mentions = [];
        
        // Add admins to mentions
        groupAdmins.forEach(admin => {
            const adminId = admin.id || admin.user || admin.userId;
            if (adminId && !mentions.includes(adminId)) {
                mentions.push(adminId);
            }
        });
        
        // Add owner to mentions if not already included
        if (owner && !mentions.includes(owner)) {
            mentions.push(owner);
        }

        // Send message without image if rate limited recently
        const sendMessageStart = Date.now();
        const lastImageSend = rateLimit.get(`${chatId}_image`) || 0;
        
        if (sendMessageStart - lastImageSend > 30000) { // 30 seconds between image sends
            try {
                await sock.sendMessage(chatId, {
                    image: { url: pp },
                    caption: text,
                    mentions: mentions.length > 0 ? mentions : undefined,
                    contextInfo: channelForwardContext()
                });
                rateLimit.set(`${chatId}_image`, sendMessageStart);
            } catch (imageError) {
                // If image fails, send text only
                console.log('Image send failed, sending text only:', imageError.message);
                await sock.sendMessage(chatId, {
                    text: text,
                    mentions: mentions.length > 0 ? mentions : undefined,
                    contextInfo: channelForwardContext()
                });
            }
        } else {
            // Send text only to avoid rate limiting
            await sock.sendMessage(chatId, {
                text: text,
                mentions: mentions.length > 0 ? mentions : undefined,
                contextInfo: channelForwardContext()
            });
        }

    } catch (error) {
        console.error('Error in groupinfo command:', error);
        
        // Clear rate limit on error to allow retry
        rateLimit.delete(chatId);
        
        // Check for specific error types
        if (error.message.includes('429') || error.message.includes('rate limit') || error.message.includes('too many')) {
            await sock.sendMessage(chatId, { 
                text:
`╭━〔 ⚠️ 𝗥𝗔𝗧𝗘 𝗟𝗜𝗠𝗜𝗧 〕━┈⊷
┃ WhatsApp is rate limiting us.
┃ Please try again in a few minutes.
┃
┃ Tips:
┃ • Avoid spamming commands
┃ • Wait a few seconds between uses
╰━━━━━━━━━━━━━━━━┈⊷`,
                contextInfo: channelForwardContext()
            });
        } else if (error.message.includes('401') || error.message.includes('403')) {
            await sock.sendMessage(chatId, { 
                text:
`╭━〔 🔐 𝗣𝗘𝗥𝗠𝗜𝗦𝗦𝗜𝗢𝗡 〕━┈⊷
┃ I need to be an admin in this group
┃ to fetch full group information.
╰━━━━━━━━━━━━━━━━━━┈⊷`,
                contextInfo: channelForwardContext()
            });
        } else if (error.message.includes('404')) {
            await sock.sendMessage(chatId, { 
                text:
`╭━━━〔 ❌ 𝗚𝗥𝗢𝗨𝗣 𝗡𝗢𝗧 𝗙𝗢𝗨𝗡𝗗 〕━━━┈⊷
┃ Make sure I'm still in this group.
╰━━━━━━━━━━━━━━━━━┈⊷`,
                contextInfo: channelForwardContext()
            });
        } else {
            await sock.sendMessage(chatId, { 
                text:
`╭━━━〔 ❌ 𝗙𝗔𝗜𝗟𝗘𝗗 〕━━━┈⊷
┃ Failed to get group info.
┃ Error: ${error.message.substring(0, 100)}
╰━━━━━━━━━━━━━━━━━┈⊷`,
                contextInfo: channelForwardContext()
            });
        }
    }
}

module.exports = groupInfoCommand;
