const settings = require("../settings");
const fs = require("fs");
const path = require("path");

function getBotModeLabel() {
  try {
    const modeFile = path.join(__dirname, "..", "data", "messageCount.json");
    const data = JSON.parse(fs.readFileSync(modeFile, "utf-8"));
    return data && data.isPublic === false ? "Private" : "Public";
  } catch {
    return "Public"; // safe fallback
  }
}

async function aliveCommand(sock, chatId, message) {
  try {
    const modeLabel = getBotModeLabel();

    const message1 =
`╭━〔 🤖 𝗡𝗔𝗦𝗜𝗥-𝗠𝗗 𝗔𝗟𝗜𝗩𝗘 〕━┈⊷
┃ ⚡ 𝗦𝘁𝗮𝘁𝘂𝘀 : Online
┃ 🧩 𝗩𝗲𝗿𝘀𝗶𝗼𝗻 : ${settings.version}
┃ 🌐 𝗠𝗼𝗱𝗲   : ${modeLabel}
┃
┃ 🌟 𝗙𝗘𝗔𝗧𝗨𝗥𝗘𝗦
┃ • Group Management
┃ • Antilink Protection
┃ • Fun Commands
┃ • Media Downloader
┃ • And More...
┃
┃ 📜 Type *.menu*
┃ for full command list
╰━━━━━━━━━━━━━━━━━━━━━┈⊷`;

    await sock.sendMessage(chatId, {
      text: message1,
      contextInfo: {
        forwardingScore: 999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          newsletterJid: "120363404049028072@newsletter",
          newsletterName: "NASIR-MD BOT",
          serverMessageId: -1
        }
      }
    }, { quoted: message });

  } catch (error) {
    console.error("Error in alive command:", error);
    await sock.sendMessage(chatId, {
      text:
`╭━〔 ⚠️ 𝗔𝗟𝗜𝗩𝗘 〕━┈⊷
┃ Bot is alive and running!
╰━━━━━━━━━━━━━━━━━┈⊷`
    }, { quoted: message });
  }
}

module.exports = aliveCommand;
