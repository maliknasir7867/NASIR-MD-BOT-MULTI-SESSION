const fs = require('fs');
const path = require('path');

const { startSession, getSessions } = require('../start/index');
const { sendMessageAsChannelForward } = require('../lib/reactions');

// Keep the same channel-forward look used across the project
const channelInfo = {
  contextInfo: {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: '120363404049028072@newsletter',
      newsletterName: 'NASIR-MD BOT',
      serverMessageId: -1,
    },
  },
};

function normalizePhone(input) {
  return String(input || '').replace(/[^0-9]/g, '').trim();
}

function normalizeAlias(input) {
  const a = String(input || 'main').trim().toLowerCase();
  const cleaned = a.replace(/[^a-z0-9_-]/g, '');
  return cleaned || 'main';
}

function getBaseDir() {
  // Keep Telegram sessions untouched. WhatsApp pairing uses its own folder.
  return path.join(process.cwd(), 'sessions', 'whatsapp');
}

function getSessionKey(alias) {
  return `whatsapp:${alias}`;
}

async function pairCommand(sock, chatId, message, q, isOwner = false) {
  try {
    // Owner-only (same style as other restricted commands)
    if (!isOwner) {
      await sock.sendMessage(chatId, { text: '❌ *Owner Only Command!* 🔒', ...channelInfo }, { quoted: message });
      return;
    }

    const raw = String(q || '').trim();
    if (!raw) {
      await sock.sendMessage(
        chatId,
        {
          text:
            'Please provide a valid WhatsApp number\n\nExamples:\n.pair 923xxxxxxxxx\n.pair hacker 923187032193',
          ...channelInfo,
        },
        { quoted: message }
      );
      return;
    }

    const parts = raw.split(/\s+/).filter(Boolean);
    let alias = 'main';
    let phone = '';

    if (parts.length === 1) {
      phone = normalizePhone(parts[0]);
    } else {
      alias = normalizeAlias(parts[0]);
      phone = normalizePhone(parts.slice(1).join(' '));
    }

    if (!phone || phone.length < 8) {
      await sock.sendMessage(
        chatId,
        {
          text:
            'Invalid number❌️ Please use the correct format!\n\nExamples:\n.pair 923xxxxxxxxx\n.pair hacker 923187032193',
          ...channelInfo,
        },
        { quoted: message }
      );
      return;
    }

    const targetJid = `${phone}@s.whatsapp.net`;
    const result = await sock.onWhatsApp(targetJid);
    if (!result?.[0]?.exists) {
      await sock.sendMessage(chatId, { text: 'That number is not registered on WhatsApp❗️', ...channelInfo }, { quoted: message });
      return;
    }

    const sessionKey = getSessionKey(alias);
    const sessionDir = path.join(getBaseDir(), alias);
    fs.mkdirSync(sessionDir, { recursive: true });

    const sessions = getSessions();
    const existingSock = sessions.get(sessionKey);
    if (existingSock?.authState?.creds?.registered) {
      await sock.sendMessage(
        chatId,
        {
          text: `Session '${alias}' is already paired / running ✅\n\nIf you want to re-pair, delete the session folder:\n${sessionDir}`,
          ...channelInfo,
        },
        { quoted: message }
      );
      return;
    }

    await sock.sendMessage(
      chatId,
      {
        text: `🔄 Starting pairing...\n\n• Alias: ${alias}\n• Number: +${phone}\n\nGenerating pairing code...`,
        ...channelInfo,
      },
      { quoted: message }
    );

    let codeSentToUser = false;

    const announceConnected = async (jid) => {
      const number = jid ? String(jid).split('@')[0] : phone;
      await sendMessageAsChannelForward(sock, chatId, {
        text:
          `✅ *Session Connected Successfully*\n\n` +
          `• Alias: *${alias}*\n` +
          `• WhatsApp: *+${number}*\n\n` +
          `Multi-session manager: *Registered* 🟢`,
      });
    };

    await startSession(sessionKey, {
      sessionDir,
      phoneNumber: phone,

      onPairCode: async (code) => {
        // Send pairing code to the *given WhatsApp number*
        codeSentToUser = true;
        await sendMessageAsChannelForward(sock, targetJid, {
          text:
            `🔐 *Your Pairing Code*\n\n` +
            `*${code}*\n\n` +
            `To pair:\n` +
            `1) WhatsApp Settings → Linked Devices\n` +
            `2) Link a device\n` +
            `3) Enter this code\n\n` +
            `⚠️ Code expires in ~5 minutes`,
        });

        // Also acknowledge to the command issuer
        await sock.sendMessage(
          chatId,
          {
            text: `✅ Pairing code generated and sent to +${phone} on WhatsApp.\n\nWaiting for login...`,
            ...channelInfo,
          },
          { quoted: message }
        );
      },

      onConnected: async (jid) => {
        await announceConnected(jid);
      },
    });

    // Small follow-up hint (without breaking flow)
    if (!codeSentToUser) {
      await sock.sendMessage(
        chatId,
        {
          text:
            `⚠️ Pairing code not generated yet.\n\nPossible reasons:\n• Network issue\n• Invalid number\n• WhatsApp restrictions\n\nTry again:\n.pair ${alias} ${phone}`,
          ...channelInfo,
        },
        { quoted: message }
      );
    }
  } catch (error) {
    console.error('WhatsApp .pair error:', error);
    await sock.sendMessage(chatId, { text: 'An error occurred. Please try again later.', ...channelInfo }, { quoted: message });
  }
}

module.exports = pairCommand;
