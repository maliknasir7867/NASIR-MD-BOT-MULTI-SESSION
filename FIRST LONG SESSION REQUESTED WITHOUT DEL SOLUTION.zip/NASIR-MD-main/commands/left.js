// leave.js (Rewritten for your bot command structure)
// Command: .left
// Works with your existing main.js switch-case style

module.exports = async function leftCommand(sock, chatId, message) {
    try {
        const sender = message.key.participant || message.key.remoteJid;
        const isGroup = chatId.endsWith('@g.us');

        if (!isGroup) {
            return await sock.sendMessage(chatId, { text: '❌ This command can only be used in groups.' }, { quoted: message });
        }

        // Fetch group metadata
        const groupMetadata = await sock.groupMetadata(chatId);
        const admins = groupMetadata.participants.filter(p => p.admin === 'admin' || p.admin === 'superadmin').map(a => a.id);

        // Check if sender is admin
        const isSenderAdmin = admins.includes(sender);

        if (!isSenderAdmin && !message.key.fromMe) {
            return await sock.sendMessage(chatId, { text: '⚠️ Only group admins can make the bot leave the group.' }, { quoted: message });
        }

        await sock.sendMessage(chatId, { text: '👋 Bot is leaving the group...' }, { quoted: message });
        await sock.groupLeave(chatId);

    } catch (err) {
        console.error('LEFT command error:', err);
        await sock.sendMessage(chatId, { text: '❌ Failed to leave the group.' }, { quoted: message });
    }
};
