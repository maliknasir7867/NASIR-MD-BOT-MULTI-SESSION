const settings = require('../settings');

async function ownerCommand(sock, chatId) {
    const vcard = `
BEGIN:VCARD
VERSION:3.0
FN:${settings.botOwner}
N:${settings.botOwner};;;;
ORG:NASIR-MD BOT
TITLE:Bot Owner • Developer
TEL;type=CELL;type=VOICE;waid=${settings.ownerNumber}:${settings.ownerNumber}
EMAIL:owner@nasirmd.com
URL:https://github.com/
ADR:;;Pakistan;;;;
NOTE:⚡ Official Owner of NASIR-MD WhatsApp Bot\\n💎 Premium Support • Bot Developer
END:VCARD
`;

    // Send contact
    await sock.sendMessage(chatId, {
        contacts: {
            displayName: `👑 ${settings.botOwner}`,
            contacts: [{ vcard }]
        },
    });

    // Stylish panel
    await sock.sendMessage(chatId, {
        text:
`╭━〔 👑 𝗢𝗪𝗡𝗘𝗥 𝗖𝗢𝗡𝗧𝗔𝗖𝗧 〕━╮
┃ 📇 Contact card shared above
┃
┃ 💬 You can message the owner for:
┃ • Bot Access
┃ • Technical Support
┃ • Session Issues
┃ • Setup Help
┃
┃ ⚠️ Important:
┃ Avoid spam — serious queries only
┃
┃ 🤖 𝗕𝗼𝘁: NASIR-MD
┃ 👑 𝗢𝘄𝗻𝗲𝗿: ${settings.botOwner}
╰━━━━━━━━━━━━━━━━━━━━━━╯`
    });
}

module.exports = ownerCommand;
