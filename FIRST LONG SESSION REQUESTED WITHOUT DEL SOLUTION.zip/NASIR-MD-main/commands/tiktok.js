const axios = require('axios');

// Store processed message IDs to prevent duplicates
const processedMessages = new Set();

async function tiktokCommand(sock, chatId, message) {
    try {
        // Check if message has already been processed
        if (processedMessages.has(message.key.id)) {
            return;
        }
        
        // Add message ID to processed set
        processedMessages.add(message.key.id);
        
        // Clean up old message IDs after 5 minutes
        setTimeout(() => {
            processedMessages.delete(message.key.id);
        }, 5 * 60 * 1000);

        const text = message.message?.conversation || message.message?.extendedTextMessage?.text;
        
        if (!text) {
            return await sock.sendMessage(chatId, { 
                text:
`╭━〔 ⚠️ 𝗧𝗜𝗞𝗧𝗢𝗞 𝗟𝗜𝗡𝗞 𝗥𝗘𝗤𝗨𝗜𝗥𝗘𝗗 〕━┈⊷
┃ Please provide a TikTok link for the video.
╰━━━━━━━━━━━━━━━━━━━━━┈⊷`
            });
        }

        // Extract URL from command
        const url = text.split(' ').slice(1).join(' ').trim();
        
        if (!url) {
            return await sock.sendMessage(chatId, { 
                text:
`╭━━〔 ⚠️ 𝗧𝗜𝗞𝗧𝗢𝗞 𝗟𝗜𝗡𝗞 𝗥𝗘𝗤𝗨𝗜𝗥𝗘𝗗 〕━┈⊷
┃ Please provide a TikTok link for the video.
╰━━━━━━━━━━━━━━━━━━━━━┈⊷`
            });
        }

        // Check for various TikTok URL formats
        const tiktokPatterns = [
            /https?:\/\/(?:www\.)?tiktok\.com\//,
            /https?:\/\/(?:vm\.)?tiktok\.com\//,
            /https?:\/\/(?:vt\.)?tiktok\.com\//,
            /https?:\/\/(?:www\.)?tiktok\.com\/@/,
            /https?:\/\/(?:www\.)?tiktok\.com\/t\//
        ];

        const isValidUrl = tiktokPatterns.some(pattern => pattern.test(url));
        
        if (!isValidUrl) {
            return await sock.sendMessage(chatId, { 
                text:
`╭━━〔 ❌ 𝗜𝗡𝗩𝗔𝗟𝗜𝗗 𝗧𝗜𝗞𝗧𝗢𝗞 𝗟𝗜𝗡𝗞 〕━┈⊷
┃ Please provide a valid TikTok video link.
╰━━━━━━━━━━━━━━━━━━━━━━┈⊷`
            });
        }

        await sock.sendMessage(chatId, {
            react: { text: '🔄', key: message.key }
        });

        try {
            // Use new TikTok API
            const apiUrl = `https://tiktok-downloader.apis-bj-devs.workers.dev/?url=${encodeURIComponent(url)}`;

            // Call TikTok API (RESTORED ORIGINAL HEADERS)
            const response = await axios.get(apiUrl, { 
                timeout: 15000,
                headers: {
                    'accept': 'application/json',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            if (!response.data.success) {
                return await sock.sendMessage(chatId, { 
                    text:
`╭━━〔 ❌ 𝗙𝗔𝗜𝗟𝗘𝗗 𝗧𝗢 𝗙𝗘𝗧𝗖𝗛 〕━┈⊷
┃ The link might be invalid or private.
╰━━━━━━━━━━━━━━━━━━━━━┈⊷`
                }, { quoted: message });
            }

            const data = response.data;
            
            // Get HD video URL (prefer HD, fallback to 480p)
            let videoUrl = null;
            for (const download of data.downloads) {
                if (download.type === 'download_video_hd') {
                    videoUrl = download.url;
                    break;
                }
            }
            
            // If no HD video, try 480p
            if (!videoUrl) {
                for (const download of data.downloads) {
                    if (download.type === 'download_video_480p') {
                        videoUrl = download.url;
                        break;
                    }
                }
            }

            if (!videoUrl) {
                return await sock.sendMessage(chatId, { 
                    text:
`╭━━〔 ❌ 𝗡𝗢 𝗩𝗜𝗗𝗘𝗢 𝗨𝗥𝗟 〕━┈⊷
┃ No video URL found in the API response.
╰━━━━━━━━━━━━━━━━━━━━━┈⊷`
                }, { quoted: message });
            }

            // ===== STYLE #1 ULTRA AESTHETIC CAPTION (ONLY DESIGN CHANGED) =====
            let caption =
`╭━━〔 𝗧𝗜𝗞𝗧𝗢𝗞 𝗗𝗢𝗪𝗡𝗟𝗢𝗔𝗗 ✅ 〕━┈⊷
┃ 🤖 𝗕𝗢𝗧: 𝗡𝗔𝗦𝗜𝗥-𝗠𝗗`;

            if (data.caption) caption += `\n┃ 📝 𝗖𝗔𝗣𝗧𝗜𝗢𝗡: ${data.caption}`;
            if (data.author) caption += `\n┃ 👤 𝗔𝗨𝗧𝗛𝗢𝗥: ${data.author}`;
            if (data.username) caption += `\n┃ 📱 𝗨𝗦𝗘𝗥: @${data.username}`;
            if (data.like) caption += `\n┃ ❤️ 𝗟𝗜𝗞𝗘𝗦: ${data.like}`;
            if (data.views) caption += `\n┃ 👀 𝗩𝗜𝗘𝗪𝗦: ${data.views}`;
            if (data.comments) caption += `\n┃ 💬 𝗖𝗢𝗠𝗠𝗘𝗡𝗧𝗦: ${data.comments}`;
            if (data.date) caption += `\n┃ 📅 𝗗𝗔𝗧𝗘: ${data.date}`;

            caption += `\n╰━━━━━━━━━━━━━━━━━━┈⊷`;

            try {
                // Download video as buffer (RESTORED ORIGINAL HEADERS)
                const videoResponse = await axios.get(videoUrl, {
                    responseType: 'arraybuffer',
                    timeout: 60000,
                    maxContentLength: 100 * 1024 * 1024, // 100MB limit
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                        'Accept': 'video/mp4,video/*,*/*;q=0.9',
                        'Accept-Language': 'en-US,en;q=0.9',
                        'Accept-Encoding': 'gzip, deflate, br',
                        'Connection': 'keep-alive',
                        'Referer': 'https://www.tiktok.com/'
                    }
                });
                
                const videoBuffer = Buffer.from(videoResponse.data);
                
                // Validate video buffer
                if (videoBuffer.length === 0) {
                    throw new Error("Video buffer is empty");
                }
                
                await sock.sendMessage(chatId, {
                    video: videoBuffer,
                    mimetype: "video/mp4",
                    caption: caption
                }, { quoted: message });

            } catch (downloadError) {
                console.error(`Failed to download video buffer: ${downloadError.message}`);
                // Fallback to URL method
                try {
                    await sock.sendMessage(chatId, {
                        video: { url: videoUrl },
                        mimetype: "video/mp4",
                        caption: caption
                    }, { quoted: message });
                } catch (urlError) {
                    console.error(`URL method also failed: ${urlError.message}`);
                    return await sock.sendMessage(chatId, { 
                        text:
`╭━━━〔 ❌ 𝗦𝗘𝗡𝗗 𝗙𝗔𝗜𝗟𝗘𝗗 〕━━━┈⊷
┃ Failed to send TikTok video. Please try again.
╰━━━━━━━━━━━━━━━━━━━━━━━┈⊷`
                    }, { quoted: message });
                }
            }

        } catch (error) {
            console.error('Error in TikTok download:', error.message);
            
            // RESTORED ORIGINAL ERROR HANDLING + STYLISH TEXT
            if (error.code === 'ECONNABORTED' || error.code === 'ETIMEDOUT') {
                await sock.sendMessage(chatId, { 
                    text:
`╭━━━〔 ⏱️ 𝗧𝗜𝗠𝗘𝗢𝗨𝗧 〕━━━┈⊷
┃ Request timeout. Please try again with the same link.
╰━━━━━━━━━━━━━━━━━━━━━━━┈⊷`
                }, { quoted: message });
            } else if (error.response && error.response.status === 404) {
                await sock.sendMessage(chatId, { 
                    text:
`╭━━━〔 ❌ 𝗩𝗜𝗗𝗘𝗢 𝗡𝗢𝗧 𝗙𝗢𝗨𝗡𝗗 〕━━━┈⊷
┃ The link might be broken or the video was removed.
╰━━━━━━━━━━━━━━━━━━━━━━━┈⊷`
                }, { quoted: message });
            } else {
                await sock.sendMessage(chatId, { 
                    text:
`╭━━〔 ❌ 𝗗𝗢𝗪𝗡𝗟𝗢𝗔𝗗 𝗘𝗥𝗥𝗢𝗥 〕━┈⊷
┃ Failed to download TikTok video. Please try again with a different link.
╰━━━━━━━━━━━━━━━━━━━━━┈⊷`
                }, { quoted: message });
            }
        }
    } catch (error) {
        console.error('Error in TikTok command:', error);
        await sock.sendMessage(chatId, { 
            text:
`╭━━━〔 ⚠️ 𝗦𝗬𝗦𝗧𝗘𝗠 𝗘𝗥𝗥𝗢𝗥 〕━━━┈⊷
┃ An error occurred while processing. Please try again later.
╰━━━━━━━━━━━━━━━━━━━━━━━┈⊷`
        }, { quoted: message });
    }
}

module.exports = tiktokCommand;
