// gdesc.js
// Command: .gdesc
// Shows group description in a beautiful format

module.exports = async function gdescCommand(sock, chatId, message) {
    try {
        const isGroup = chatId.endsWith("@g.us");
        if (!isGroup) {
            return await sock.sendMessage(chatId, {
                text: "❌ This command only works in group chats."
            }, { quoted: message });
        }

        // Fetch group metadata
        const meta = await sock.groupMetadata(chatId);
        const description = meta.desc || "📭 No group description set.";
        const descId = meta.descId || "N/A";

        const response = `
📜 *Group Description*

📝 *Description:*
${description}

🆔 *Description ID:* ${descId}

👥 *Group:* ${meta.subject}

*✨ Powered by NASIR-MD BOT*
        `;

        await sock.sendMessage(chatId, {
            text: response,
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: "120363404049028072@newsletter",
                    newsletterName: "NASIR-MD BOT",
                    serverMessageId: -1
                }
            }
        });

    } catch (err) {
        console.error("GDESC ERROR:", err);
        await sock.sendMessage(chatId, {
            text: "❌ Failed to fetch group description."
        }, { quoted: message });
    }
};
