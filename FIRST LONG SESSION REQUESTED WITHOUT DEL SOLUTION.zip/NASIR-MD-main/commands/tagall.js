const isAdmin = require('../lib/isAdmin');
const moment = require('moment-timezone');

function extractPhoneNumber(jid = '') {
  return String(jid).split('@')[0] || jid;
}

function safeText(x) {
  return (x === undefined || x === null) ? '' : String(x);
}

// WhatsApp safe chunk size (keep margin for mentions + formatting)
function chunkText(text, maxLen = 3500) {
  const parts = [];
  let cur = '';
  for (const line of text.split('\n')) {
    if ((cur + '\n' + line).length > maxLen) {
      parts.push(cur);
      cur = line;
    } else {
      cur = cur ? (cur + '\n' + line) : line;
    }
  }
  if (cur) parts.push(cur);
  return parts;
}

async function tagAllCommand(sock, chatId, senderId, message) {
  try {
    const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);

    if (!isBotAdmin) {
      await sock.sendMessage(chatId, { text: 'Please make the bot an admin first.' }, { quoted: message });
      return;
    }

    if (!isSenderAdmin) {
      await sock.sendMessage(chatId, { text: 'Only group admins *OR HACKER* can use the .tagall command.' }, { quoted: message });
      return;
    }

    const groupMetadata = await sock.groupMetadata(chatId);
    const participants = groupMetadata?.participants || [];

    if (!participants.length) {
      await sock.sendMessage(chatId, { text: 'No participants found in the group.' }, { quoted: message });
      return;
    }

    // Read custom message after command: ".tagall Attention Everyone"
    const rawText =
      message?.message?.conversation ||
      message?.message?.extendedTextMessage?.text ||
      message?.message?.imageMessage?.caption ||
      message?.message?.videoMessage?.caption ||
      '';

    const customMsg = safeText(rawText).replace(/^(\.tagall|\/tagall)\s*/i, '').trim();
    const attentionLine = customMsg ? customMsg : 'Attention Everyone';

    const groupName = safeText(groupMetadata?.subject) || 'Unknown Group';
    const memberCount = participants.length;

    const admins = participants.filter(p => (p.admin === 'admin' || p.admin === 'superadmin'));
    const adminCount = admins.length;

    // Best-effort owner: prefer superadmin, else first admin, else first participant
    const ownerJid =
      admins.find(a => a.admin === 'superadmin')?.id ||
      admins[0]?.id ||
      participants[0]?.id ||
      '';

    const nowPk = moment().tz('Asia/Karachi').format('hh:mm A');

    // Build mentions list
    const mentionJids = participants.map(p => p.id);
    const mentionLines = participants.map(p => {
      const num = extractPhoneNumber(p.id);
      return `🎧 @${num}`;
    });

    // Header (compact, stylish, limit-friendly)
    const header =
`▢ Group : *${groupName}*
▢ Members : *${memberCount}*
▢ Admins : *${adminCount}*
▢ Time : *${nowPk}*
▢ Message : *${attentionLine}*

┌───⊷ *MENTIONS*`;

    const footer = `└──❖ 𝗡𝗔𝗦𝗜𝗥-𝗠𝗗 ❖──┘`;

    const fullText = [header, ...mentionLines, footer].join('\n');

    // Split into chunks so WhatsApp doesn’t break / look ugly
    const chunks = chunkText(fullText, 3500);

    // Send chunks with mentions (mentions included each time for safety)
    for (let i = 0; i < chunks.length; i++) {
      await sock.sendMessage(
        chatId,
        {
          text: chunks[i],
          mentions: mentionJids
        },
        { quoted: message }
      );
    }

  } catch (error) {
    console.error('Error in tagall command:', error);
    await sock.sendMessage(chatId, { text: 'Failed to tag all members.' }, { quoted: message });
  }
}

module.exports = tagAllCommand;
