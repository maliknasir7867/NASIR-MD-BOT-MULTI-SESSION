const fs = require('fs');

const ANTICALL_STATE_PATH = './data/anticall.json';
const CALL_RECORD_PATH = './data/antiCallRecord.json';
const CHANNEL_JID = "120363404049028072@newsletter";

function forwardedTag() {
  return {
    contextInfo: {
      isForwarded: true,
      forwardingScore: 777,
      forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        serverMessageId: null
      }
    }
  };
}

// ✅ State format (new):
// { mode: "off" | "warn" | "reject" }
// Backward compatible with old: { enabled: true/false }
function readState() {
  try {
    if (!fs.existsSync(ANTICALL_STATE_PATH)) return { mode: "off" };

    const raw = JSON.parse(fs.readFileSync(ANTICALL_STATE_PATH, "utf8")) || {};

    // Backward compat
    if (typeof raw.enabled === "boolean") {
      return { mode: raw.enabled ? "warn" : "off" };
    }

    const mode = (raw.mode || "off").toLowerCase();
    if (["off", "warn", "reject"].includes(mode)) return { mode };

    return { mode: "off" };
  } catch {
    return { mode: "off" };
  }
}

function writeState(mode) {
  if (!fs.existsSync("./data")) fs.mkdirSync("./data", { recursive: true });
  fs.writeFileSync(ANTICALL_STATE_PATH, JSON.stringify({ mode }, null, 2));
}

function loadRecord() {
  try {
    if (!fs.existsSync(CALL_RECORD_PATH)) return {};
    return JSON.parse(fs.readFileSync(CALL_RECORD_PATH, "utf8"));
  } catch {
    return {};
  }
}

function saveRecord(data) {
  if (!fs.existsSync("./data")) fs.mkdirSync("./data", { recursive: true });
  fs.writeFileSync(CALL_RECORD_PATH, JSON.stringify(data, null, 2));
}

function modeLabel(mode) {
  if (mode === "warn") return "🟡 WARN (Block after 3)";
  if (mode === "reject") return "🟣 REJECT (No block)";
  return "🔴 OFF";
}

async function anticallCommand(sock, chatId, message, args) {
  const state = readState();
  const cmdRaw = (args || "").trim().toLowerCase();

  const tokens = cmdRaw.split(/\s+/).filter(Boolean);
  const cmd = tokens[0] || "";

  const isValid =
    cmd === "on" ||
    cmd === "off" ||
    cmd === "status" ||
    (cmd === "set" && ["warn", "reject"].includes(tokens[1]));

  if (!isValid) {
    await sock.sendMessage(chatId, {
      text:
`╭━〔 🛡️ 𝗡𝗔𝗦𝗜𝗥-𝗠𝗗 𝗔𝗡𝗧𝗜𝗖𝗔𝗟𝗟 〕━╮
┃ 📵 Calls are restricted when enabled.
┃
┃ ⚙️ 𝗖𝗼𝗺𝗺𝗮𝗻𝗱𝘀
┃ ▢ .anticall on
┃ ▢ .anticall off
┃ ▢ .anticall status
┃ ▢ .anticall set warn
┃ ▢ .anticall set reject
╰━━━━━━━━━━━━━━━━━━━━━━╯`,
      ...forwardedTag()
    }, { quoted: message });
    return;
  }

  if (cmd === "status") {
    await sock.sendMessage(chatId, {
      text:
`╭━〔 📊 𝗔𝗡𝗧𝗜𝗖𝗔𝗟𝗟 𝗦𝗧𝗔𝗧𝗨𝗦 〕━╮
┃ ▢ *Mode:* ${modeLabel(state.mode)}
╰━━━━━━━━━━━━━━━━━━━━━━╯`,
      ...forwardedTag()
    }, { quoted: message });
    return;
  }

  // ✅ .anticall on  ==> same as "warn"
  if (cmd === "on") {
    writeState("warn");
    await sock.sendMessage(chatId, {
      text:
`╭━〔 🛡️ 𝗔𝗡𝗧𝗜𝗖𝗔𝗟𝗟 𝗘𝗡𝗔𝗕𝗟𝗘𝗗 〕━╮
┃ ▢ Mode: 🟡 WARN
┃ ▢ 📞 Calls will be auto-rejected.
┃ ▢ ⚠️ Block triggers after *3* attempts.
╰━━━━━━━━━━━━━━━━━━━━━━╯`,
      ...forwardedTag()
    }, { quoted: message });
    return;
  }

  // ✅ .anticall set warn / reject
  if (cmd === "set") {
    const mode = tokens[1];

    if (mode === "warn") {
      writeState("warn");
      await sock.sendMessage(chatId, {
        text:
`╭━〔 🟡 𝗔𝗡𝗧𝗜𝗖𝗔𝗟𝗟 𝗠𝗢𝗗𝗘 〕━╮
┃ ▢ Mode set to: *WARN*
┃ ▢ 📞 Calls will be auto-rejected.
┃ ▢ ⚠️ Block after *3* attempts.
╰━━━━━━━━━━━━━━━━━━━━━━╯`,
        ...forwardedTag()
      }, { quoted: message });
      return;
    }

    if (mode === "reject") {
      writeState("reject");
      await sock.sendMessage(chatId, {
        text:
`╭━〔 🟣 𝗔𝗡𝗧𝗜𝗖𝗔𝗟𝗟 𝗠𝗢𝗗𝗘 〕━╮
┃ ▢ Mode set to: *REJECT*
┃ ▢ 📞 Calls will be auto-rejected.
┃ ▢ ✅ User will *NOT* be blocked.
╰━━━━━━━━━━━━━━━━━━━━━━╯`,
        ...forwardedTag()
      }, { quoted: message });
      return;
    }
  }

  // ✅ .anticall off
  writeState("off");
  await sock.sendMessage(chatId, {
    text:
`╭━〔 🟢 𝗔𝗡𝗧𝗜𝗖𝗔𝗟𝗟 𝗗𝗜𝗦𝗔𝗕𝗟𝗘𝗗 〕━╮
┃ ▢ Calling is now allowed again.
╰━━━━━━━━━━━━━━━━━━━━━━╯`,
    ...forwardedTag()
  }, { quoted: message });
}

async function handleIncomingCall(sock, calls) {
  const state = readState();
  if (!state || state.mode === "off") return;

  const list = Array.isArray(calls) ? calls : [calls];

  for (const call of list) {
    if (!call) continue;
    if (call.status !== 'offer') continue;

    const caller =
      call.from ||
      call.peerJid ||
      call.remoteJid ||
      call.chatId ||
      call.participant ||
      null;

    const callId = call.id || null;
    if (!caller || !callId) continue;

    // Always reject when mode is warn/reject
    try { await sock.rejectCall(callId, caller); } catch {}

    // ✅ REJECT MODE: reject only, never block
    if (state.mode === "reject") {
      try {
        await sock.sendMessage(caller, {
          text:
`╭━〔 🚫 𝗖𝗔𝗟𝗟 𝗥𝗘𝗝𝗘𝗖𝗧𝗘𝗗 〕━╮
┃ @${caller.split('@')[0]}, calls are restricted.
┃ ▢ Mode: 🟣 REJECT (No block)
╰━━━━━━━━━━━━━━━━━━━━━╯`,
          mentions: [caller],
          ...forwardedTag()
        });
      } catch {}
      continue;
    }

    // ✅ WARN MODE (same as old .anticall on): warn + block after 3 attempts
    const records = loadRecord();
    records[caller] = (records[caller] || 0) + 1;
    saveRecord(records);

    if (records[caller] < 3) {
      try {
        await sock.sendMessage(caller, {
          text:
`╭━〔 🚫 𝗖𝗔𝗟𝗟 𝗥𝗘𝗝𝗘𝗖𝗧𝗘𝗗 〕━╮
┃ @${caller.split('@')[0]}, calls are restricted.
┃ ▢ ⚠️ *Attempt:* ${records[caller]}/3
╰━━━━━━━━━━━━━━━━━━━━━╯`,
          mentions: [caller],
          ...forwardedTag()
        });
      } catch {}
      continue;
    }

    try {
      await sock.sendMessage(caller, {
        text:
`╭━〔 ⛔ 𝗟𝗜𝗠𝗜𝗧 𝗥𝗘𝗔𝗖𝗛𝗘𝗗 〕━╮
┃ You attempted to call *3 times*.
┃ This is not permitted.
╰━━━━━━━━━━━━━━━━━━━━━╯`,
        ...forwardedTag()
      });
    } catch {}

    try { await sock.updateBlockStatus(caller, "block"); } catch {}

    records[caller] = 0;
    saveRecord(records);
  }
}

module.exports = {
  anticallCommand,
  handleIncomingCall,
  readState
};
