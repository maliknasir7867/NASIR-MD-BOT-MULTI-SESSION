const axios = require('axios');
const yts = require('yt-search');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawn } = require('child_process');

// API configuration
const apis = {
    davidcyril: "https://apis.davidcyril.name.ng/song?query="
};

const AXIOS_DEFAULTS = {
    timeout: 60000,
    headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'application/json, text/plain, */*',
        'Referer': 'https://apis.davidcyril.name.ng/'
    }
};

async function tryRequest(getter, attempts = 3) {
    let lastError;
    for (let attempt = 1; attempt <= attempts; attempt++) {
        try {
            return await getter();
        } catch (err) {
            lastError = err;
            if (attempt < attempts) {
                await new Promise(r => setTimeout(r, 1000 * attempt));
            }
        }
    }
    throw lastError;
}

// Download a file into a Buffer
async function downloadAsBuffer(url) {
    const res = await tryRequest(() => axios.get(url, {
        timeout: 120000,
        responseType: 'arraybuffer',
        headers: AXIOS_DEFAULTS.headers
    }));
    return Buffer.from(res.data);
}

// Convert an MP3 (or any audio buffer ffmpeg can read) into WhatsApp-friendly voice note (OGG/OPUS)
async function toVoiceNoteOggOpus(inputBuffer) {
    const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'nasir-play-'));
    const inFile = path.join(tmpDir, 'in.mp3');
    const outFile = path.join(tmpDir, 'out.ogg');

    fs.writeFileSync(inFile, inputBuffer);

    await new Promise((resolve, reject) => {
        const args = [
            '-y',
            '-i', inFile,
            '-vn',
            '-c:a', 'libopus',
            '-b:a', '48k',
            '-vbr', 'on',
            '-compression_level', '10',
            '-application', 'voip',
            outFile
        ];

        const ff = spawn('ffmpeg', args);
        let errBuf = Buffer.alloc(0);
        ff.stderr.on('data', (d) => (errBuf = Buffer.concat([errBuf, d])));
        ff.on('error', reject);
        ff.on('close', (code) => {
            if (code === 0) return resolve();
            reject(new Error(errBuf.toString() || `ffmpeg exited with code ${code}`));
        });
    });

    const out = fs.readFileSync(outFile);
    // Cleanup
    try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch (_) {}
    return out;
}

// =========================
// Reaction-based downloader
// =========================
// Supports:
// 👍 -> MP3 (ptt: false)
// ❤️ -> Voice Note (ptt: true)
//
// NOTE: This is intentionally in-memory (per running process) to avoid changing your database.
// Pending requests are cleaned automatically by timeout.
function setupPlayReactionListener(sock) {
    if (sock.__nasirPlayReactionListenerAttached) return;
    sock.__nasirPlayReactionListenerAttached = true;

    // Map<messageIdBeingReactedTo, { chatId, userJid, onChoice, timeout }>
    sock.__nasirPlayReactionPending = sock.__nasirPlayReactionPending || new Map();

    sock.ev.on('messages.upsert', async (upsert) => {
        try {
            const msgs = upsert?.messages || [];
            for (const msg of msgs) {
                const reaction = msg?.message?.reactionMessage;
                if (!reaction) continue;

                // Ignore the bot's own reactions (prevents auto-trigger)
                if (msg?.key?.fromMe) continue;

                const reactedMsgId = reaction?.key?.id;
                const emoji = reaction?.text;
                if (!reactedMsgId || !emoji) continue;

                const pending = sock.__nasirPlayReactionPending.get(reactedMsgId);
                if (!pending) continue;

                // Only accept reactions from the same chat & same user who requested
                const remoteJid = msg?.key?.remoteJid;
                if (pending.chatId && remoteJid && pending.chatId !== remoteJid) continue;

                const reactorJid = msg?.key?.participant || msg?.key?.remoteJid;
                if (pending.userJid && reactorJid && pending.userJid !== reactorJid) continue;

                if (emoji !== '👍' && emoji !== '❤️') continue;

                sock.__nasirPlayReactionPending.delete(reactedMsgId);
                if (pending.timeout) clearTimeout(pending.timeout);

                await pending.onChoice(emoji);
            }
        } catch (e) {
            // Never crash global listener
            console.log('Play reaction listener error:', e?.message || e);
        }
    });
}

// Function to get MP3 from David Cyril API
async function getDavidCyrilMp3ByQuery(query) {
    const apiUrl = `${apis.davidcyril}${encodeURIComponent(query)}`;
    const res = await tryRequest(() => axios.get(apiUrl, AXIOS_DEFAULTS));
    
    if (res?.data?.status && res?.data?.result?.audio?.download_url) {
        const result = res.data.result;
        return {
            download: result.audio.download_url,
            title: result.title,
            thumbnail: result.thumbnail,
            duration: result.duration,
            views: result.views,
            published: result.published,
            video_url: result.video_url,
            format: result.audio.format,
            quality: result.audio.quality
        };
    }
    throw new Error("David Cyril API returned no audio");
}

async function songCommand(sock, chatId, message) {
    try {
        const channelJid = "120363404049028072@newsletter";
        const channelName = "NASIR-MD BOT";
        
        const text = message.message?.conversation || message.message?.extendedTextMessage?.text || '';
        const usedCmd = (text.trim().split(/\s+/)[0] || '.play');
        const args = text.split(' ').slice(1);
        
        // Check if song name is provided
        if (args.length === 0) {
            return await sock.sendMessage(chatId, { 
                text:
`╭━〔 ❌ 𝗦𝗢𝗡𝗚 𝗡𝗔𝗠𝗘 𝗥𝗘𝗤𝗨𝗜𝗥𝗘𝗗 〕━┈⊷
┃ Please provide a song name!
┃
┃ ✅ Example:
┃ • *.song excuses*
┃ • *.song shape of you*
╰━━━━━━━━━━━━━━━━━━┈⊷`,
                contextInfo: {
                    forwardingScore: -1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: channelJid,
                        newsletterName: channelName,
                        serverMessageId: -1
                    }
                }
            }, { quoted: message });
        }

        const searchQuery = args.join(' ').trim();
        
        if (!searchQuery) {
            return await sock.sendMessage(chatId, { 
                text:
`╭━〔 ❌ 𝗜𝗡𝗩𝗔𝗟𝗜𝗗 𝗦𝗢𝗡𝗚 〕━┈⊷
┃ Please provide a valid song name!
┃
┃ ✅ Example:
┃ • *.song excuses*
┃ • *.song shape of you*
╰━━━━━━━━━━━━━━━━━━━━┈⊷`,
                contextInfo: {
                    forwardingScore: -1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: channelJid,
                        newsletterName: channelName,
                        serverMessageId: -1
                    }
                }
            }, { quoted: message });
        }

        // Send searching message
        await sock.sendMessage(chatId, {
            text:
`╭━〔 🔍 𝗦𝗘𝗔𝗥𝗖𝗛𝗜𝗡𝗚 〕━┈⊷
┃ 🔍 *Searching for:* ${searchQuery}
┃ *Please wait...*
╰━━━━━━━━━━━━━━━━━━┈⊷`,
            contextInfo: {
                forwardingScore: -1,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: channelJid,
                    newsletterName: channelName,
                    serverMessageId: -1
                }
            }
        }, { quoted: message });

        let video;
        let useDavidCyrilAPI = true;
        
        // Check if it's a YouTube URL
        if (searchQuery.includes('youtube.com') || searchQuery.includes('youtu.be')) {
            useDavidCyrilAPI = false;
            video = { url: searchQuery };
            // For direct links, we need to get video info
            const search = await yts({ videoId: searchQuery.split('v=')[1]?.split('&')[0] || searchQuery.split('/').pop() });
            if (search) {
                video.title = search.title;
                video.thumbnail = search.thumbnail;
                video.timestamp = search.timestamp;
                video.duration = search.duration;
            }
        } else {
            // First try David Cyril API for search queries
            try {
                const davidCyrilData = await getDavidCyrilMp3ByQuery(searchQuery);
                
                // Send downloading message with song info
                await sock.sendMessage(chatId, {
                    image: { url: davidCyrilData.thumbnail },
                    caption:
`╭━〔 🎵 𝗗𝗢𝗪𝗡𝗟𝗢𝗔𝗗𝗜𝗡𝗚 〕┈⊷
┃ *📝 Title*   : ${davidCyrilData.title}
┃ *⏱️ Duration:* ${davidCyrilData.duration}
┃ *👁 Views*   : ${davidCyrilData.views?.toLocaleString()}
┃ *🎯 Quality* : ${davidCyrilData.quality}
┃
┃ *⬇️ Processing your request...*
╰━━━━━━━━━━━━━━━━━┈⊷`,
                    contextInfo: {
                        forwardingScore: -1,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: channelJid,
                            newsletterName: channelName,
                            serverMessageId: -1
                        }
                    }
                }, { quoted: message });

                // --- NEW: Ask user to react for MP3 / Voice Note ---
                // Attach the reaction listener once.
                setupPlayReactionListener(sock);

                const promptMsg = await sock.sendMessage(chatId, {
                    text:
`╭━〔 🎧 𝗗𝗢𝗪𝗡𝗟𝗢𝗔𝗗 𝗢𝗣𝗧𝗜𝗢𝗡𝗦 〕━┈⊷
┃ *📝 Title*   : ${davidCyrilData.title}
┃ *⏱️ Duration:* ${davidCyrilData.duration}
┃ *🎯 Quality* : ${davidCyrilData.quality}
┃
┃ 👍 React to download as *MP3*
┃ ❤️ React to download as *Voice Note*
╰━━━━━━━━━━━━━━━━━━┈⊷`,
                    contextInfo: {
                        forwardingScore: -1,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: channelJid,
                            newsletterName: channelName,
                            serverMessageId: -1
                        }
                    }
                }, { quoted: message });

                // NOTE: We do NOT auto-react here because some clients show it like the bot selected an option.

                const promptId = promptMsg?.key?.id;
                if (!promptId) throw new Error('Could not create download prompt');

                // Store pending reaction (1 minute timeout)
                const userJid = message?.key?.participant || message?.key?.remoteJid;
                const timeout = setTimeout(async () => {
                    try {
                        sock.__nasirPlayReactionPending?.delete(promptId);
                        await sock.sendMessage(chatId, {
                            text:
`╭━〔 ⏳ 𝗧𝗜𝗠𝗘 𝗢𝗨𝗧 〕━┈⊷
┃ No reaction received.
┃ Please use *${usedCmd} ${searchQuery}* again.
╰━━━━━━━━━━━━━━━━━━┈⊷`,
                            contextInfo: {
                                forwardingScore: -1,
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: channelJid,
                                    newsletterName: channelName,
                                    serverMessageId: -1
                                }
                            }
                        }, { quoted: message });
                    } catch (_) {}
                }, 60 * 1000);

                sock.__nasirPlayReactionPending.set(promptId, {
                    chatId,
                    userJid,
                    timeout,
                    onChoice: async (emoji) => {
                        const isVoice = emoji === '❤️';

                        await sock.sendMessage(chatId, {
                            text:
`╭━〔 ✅ 𝗗𝗢𝗪𝗡𝗟𝗢𝗔𝗗 𝗦𝗧𝗔𝗥𝗧𝗘𝗗 〕━┈⊷
┃ *📝 Title* : ${davidCyrilData.title}
┃ *Type*    : ${isVoice ? 'Voice Note' : 'MP3'}
┃
┃ *🎧 Now sending...*
╰━━━━━━━━━━━━━━━━━━┈⊷`,
                            contextInfo: {
                                forwardingScore: -1,
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: channelJid,
                                    newsletterName: channelName,
                                    serverMessageId: -1
                                }
                            }
                        }, { quoted: message });

                        if (isVoice) {
                            // WhatsApp voice notes must be OGG/OPUS to play reliably.
                            const mp3Buf = await downloadAsBuffer(davidCyrilData.download);
                            const oggOpus = await toVoiceNoteOggOpus(mp3Buf);

                            await sock.sendMessage(chatId, {
                                audio: oggOpus,
                                mimetype: 'audio/ogg; codecs=opus',
                                ptt: true,
                                contextInfo: {
                                    forwardingScore: -1,
                                    isForwarded: true,
                                    forwardedNewsletterMessageInfo: {
                                        newsletterJid: channelJid,
                                        newsletterName: channelName,
                                        serverMessageId: -1
                                    }
                                }
                            }, { quoted: message });
                        } else {
                            // Normal MP3
                            await sock.sendMessage(chatId, {
                                audio: { url: davidCyrilData.download },
                                mimetype: 'audio/mpeg',
                                fileName: `${davidCyrilData.title.replace(/[<>:"/\\|?*]/g, '').substring(0, 100)}.mp3`,
                                ptt: false,
                                contextInfo: {
                                    forwardingScore: -1,
                                    isForwarded: true,
                                    forwardedNewsletterMessageInfo: {
                                        newsletterJid: channelJid,
                                        newsletterName: channelName,
                                        serverMessageId: -1
                                    }
                                }
                            }, { quoted: message });
                        }
                    }
                });

                return; // Exit successfully (waits for reaction via global listener)
                
            } catch (davidCyrilError) {
                console.log("David Cyril API failed, falling back to yts:", davidCyrilError.message);
                useDavidCyrilAPI = false;
            }
        }

        // Fallback to yts search if David Cyril API failed or it's a YouTube URL
        if (!useDavidCyrilAPI) {
            const search = await yts(searchQuery);
            if (!search || !search.videos.length) {
                return await sock.sendMessage(chatId, { 
                    text:
`╭━〔 ❌ 𝗡𝗢 𝗥𝗘𝗦𝗨𝗟𝗧𝗦 〕━┈⊷
┃ No results found!
┃ Try a different search term.
╰━━━━━━━━━━━━━━━━━━━┈⊷`,
                    contextInfo: {
                        forwardingScore: -1,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: channelJid,
                            newsletterName: channelName,
                            serverMessageId: -1
                        }
                    }
                }, { quoted: message });
            }
            video = search.videos[0];
            
            // Send downloading message with video info
            await sock.sendMessage(chatId, {
                image: { url: video.thumbnail },
                caption:
`╭━〔 🎵 𝗙𝗢𝗨𝗡𝗗 𝗢𝗡 𝗬𝗢𝗨𝗧𝗨𝗕𝗘 〕┈⊷
┃ 📝 Title   : ${video.title}
┃ ⏱️ Duration: ${video.timestamp || video.duration}
┃
┃ ⬇️ Trying to process...
╰━━━━━━━━━━━━━━━━━━┈⊷`,
                contextInfo: {
                    forwardingScore: -1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: channelJid,
                        newsletterName: channelName,
                        serverMessageId: -1
                    }
                }
            }, { quoted: message });

            // Send error message since no download API is available
            await sock.sendMessage(chatId, {
                text:
`╭━〔 ❌ 𝗗𝗢𝗪𝗡𝗟𝗢𝗔𝗗 𝗨𝗡𝗔𝗩𝗔𝗜𝗟𝗔𝗕𝗟𝗘 〕━┈⊷
┃ 📝 Title   : ${video.title}
┃ ⏱️ Duration: ${video.timestamp || video.duration}
┃
┃ ⚠️ MP3 download is currently unavailable.
╰━━━━━━━━━━━━━━━━━━━┈⊷`,
                contextInfo: {
                    forwardingScore: -1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: channelJid,
                        newsletterName: channelName,
                        serverMessageId: -1
                    }
                }
            }, { quoted: message });
        }

    } catch (err) {
        console.error('Song command error:', err);
        await sock.sendMessage(chatId, { 
            text:
`╭━〔 ❌ 𝗗𝗢𝗪𝗡𝗟𝗢𝗔𝗗 𝗙𝗔𝗜𝗟𝗘𝗗 〕━┈⊷
┃ Please try again later.
╰━━━━━━━━━━━━━━━━━━┈⊷`,
            contextInfo: {
                forwardingScore: -1,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: "120363424158853914@newsletter",
                    newsletterName: "NASIR-MD BOT",
                    serverMessageId: -1
                }
            }
        }, { quoted: message });
    }
}

module.exports = songCommand;
