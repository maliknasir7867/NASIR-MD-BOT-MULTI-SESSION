const fs = require('fs');
const path = require('path');
const { tmpdir } = require('os');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const { writeFile } = fs.promises;

const messageStore = new Map();
const CONFIG_PATH = path.join(__dirname, '../data/antidelete.json');
const TEMP_MEDIA_DIR = path.join(__dirname, '../tmp');

// Ensure tmp dir exists
if (!fs.existsSync(TEMP_MEDIA_DIR)) {
    fs.mkdirSync(TEMP_MEDIA_DIR, { recursive: true });
}

// Track message deletions to avoid duplicates
const recentDeletions = new Set();
const DELETION_COOLDOWN = 5000; // 5 seconds

// Function to get folder size in MB
const getFolderSizeInMB = (folderPath) => {
    try {
        const files = fs.readdirSync(folderPath);
        let totalSize = 0;

        for (const file of files) {
            const filePath = path.join(folderPath, file);
            if (fs.statSync(filePath).isFile()) {
                totalSize += fs.statSync(filePath).size;
            }
        }

        return totalSize / (1024 * 1024); // Convert bytes to MB
    } catch (err) {
        console.error('Error getting folder size:', err);
        return 0;
    }
};

// Function to clean temp folder if size exceeds 200MB
const cleanTempFolderIfLarge = () => {
    try {
        const sizeMB = getFolderSizeInMB(TEMP_MEDIA_DIR);
        
        if (sizeMB > 200) {
            const files = fs.readdirSync(TEMP_MEDIA_DIR);
            for (const file of files) {
                const filePath = path.join(TEMP_MEDIA_DIR, file);
                fs.unlinkSync(filePath);
            }
            console.log(`Cleaned temp folder (was ${sizeMB.toFixed(2)}MB)`);
        }
    } catch (err) {
        console.error('Temp cleanup error:', err);
    }
};

// Start periodic cleanup check every 1 minute
setInterval(cleanTempFolderIfLarge, 60 * 1000);

// Load config
function loadAntideleteConfig() {
    try {
        if (!fs.existsSync(CONFIG_PATH)) return { enabled: false };
        return JSON.parse(fs.readFileSync(CONFIG_PATH));
    } catch {
        return { enabled: false };
    }
}

// Save config
function saveAntideleteConfig(config) {
    try {
        fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2));
    } catch (err) {
        console.error('Config save error:', err);
    }
}

const isOwnerOrSudo = require('../lib/isOwner');

// Helper function to unwrap view-once messages ONLY when explicitly view-once
const isViewOnceMessage = (msg) => {
    if (!msg) return false;
    return (
        msg.viewOnceMessage !== undefined ||
        msg.viewOnceMessageV2 !== undefined ||
        msg.viewOnceMessageV2Extension !== undefined
    );
};

const unwrapViewOnce = (msg) => {
    if (!msg) return null;
    return (
        msg?.viewOnceMessage?.message ||
        msg?.viewOnceMessageV2?.message ||
        msg?.viewOnceMessageV2Extension?.message ||
        msg
    );
};

// Helper to download media to buffer
const downloadToBuffer = async (mediaMsg, type) => {
    try {
        const stream = await downloadContentFromMessage(mediaMsg, type);
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }
        return buffer;
    } catch (err) {
        console.error('Download error:', err);
        return null;
    }
};

// Get readable file size
const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

// Get message type name
const getMessageTypeName = (message) => {
    if (message.message?.imageMessage) return 'Image';
    if (message.message?.videoMessage) return 'Video';
    if (message.message?.audioMessage) return {
        'audio/mpeg': 'Audio',
        'audio/ogg; codecs=opus': 'Voice Note',
        'audio/ogg': 'Voice Note',
        'audio/aac': 'Audio'
    }[message.message.audioMessage.mimetype] || 'Audio';
    if (message.message?.stickerMessage) return 'Sticker';
    if (message.message?.documentMessage) return 'Document';
    if (message.message?.conversation) return 'Text';
    if (message.message?.extendedTextMessage?.text) return 'Text';
    if (message.message?.viewOnceMessage || message.message?.viewOnceMessageV2) return 'View Once Media';
    return 'Unknown';
};

// Command Handler
async function handleAntideleteCommand(sock, chatId, message, match) {
    const senderId = message.key.participant || message.key.remoteJid;
    const isOwner = await isOwnerOrSudo(senderId, sock, chatId);
    
    if (!message.key.fromMe && !isOwner) {
        return sock.sendMessage(chatId, { text: '*Only the bot owner can use this command.*' }, { quoted: message });
    }

    const config = loadAntideleteConfig();

    if (!match) {
        return sock.sendMessage(chatId, {
            text: `*ANTIDELETE SETUP*\n\nCurrent Status: ${config.enabled ? '✅ Enabled' : '❌ Disabled'}\n\n*.antidelete on* - Enable\n*.antidelete off* - Disable`
        }, {quoted: message});
    }

    if (match === 'on') {
        config.enabled = true;
    } else if (match === 'off') {
        config.enabled = false;
    } else {
        return sock.sendMessage(chatId, { text: '*Invalid command. Use .antidelete to see usage.*' }, {quoted:message});
    }

    saveAntideleteConfig(config);
    return sock.sendMessage(chatId, { text: `*Antidelete ${match === 'on' ? 'enabled' : 'disabled'}*` }, {quoted:message});
}

// Store incoming messages
async function storeMessage(sock, message) {
    try {
        const config = loadAntideleteConfig();
        if (!config.enabled) return;

        if (!message.key?.id) return;

        const messageId = message.key.id;
        let content = '';
        let mediaType = '';
        let mediaPath = '';
        let isViewOnce = false;
        let fileSize = 0;
        let mimeType = '';
        let fileName = '';

        const sender = message.key.participant || message.key.remoteJid;

        // Check if this is ACTUALLY a view-once message
        isViewOnce = isViewOnceMessage(message.message);
        
        if (isViewOnce) {
            // Handle view-once messages
            const viewOnceUnwrapped = unwrapViewOnce(message.message);
            
            if (viewOnceUnwrapped?.imageMessage) {
                mediaType = 'image';
                content = viewOnceUnwrapped.imageMessage.caption || '';
                mimeType = viewOnceUnwrapped.imageMessage.mimetype || 'image/jpeg';
                fileSize = viewOnceUnwrapped.imageMessage.fileLength || 0;
                const buffer = await downloadToBuffer(viewOnceUnwrapped.imageMessage, 'image');
                if (buffer) {
                    mediaPath = path.join(TEMP_MEDIA_DIR, `${messageId}_viewonce.jpg`);
                    await writeFile(mediaPath, buffer);
                    fileSize = buffer.length;
                }
            }
            else if (viewOnceUnwrapped?.videoMessage) {
                mediaType = 'video';
                content = viewOnceUnwrapped.videoMessage.caption || '';
                mimeType = viewOnceUnwrapped.videoMessage.mimetype || 'video/mp4';
                fileSize = viewOnceUnwrapped.videoMessage.fileLength || 0;
                const buffer = await downloadToBuffer(viewOnceUnwrapped.videoMessage, 'video');
                if (buffer) {
                    mediaPath = path.join(TEMP_MEDIA_DIR, `${messageId}_viewonce.mp4`);
                    await writeFile(mediaPath, buffer);
                    fileSize = buffer.length;
                }
            }
            else if (viewOnceUnwrapped?.audioMessage) {
                mediaType = 'audio';
                content = viewOnceUnwrapped.audioMessage.caption || '';
                mimeType = viewOnceUnwrapped.audioMessage.mimetype || 'audio/ogg; codecs=opus';
                fileSize = viewOnceUnwrapped.audioMessage.fileLength || 0;
                const ext = mimeType.includes('mpeg') ? 'mp3' : (mimeType.includes('ogg') ? 'ogg' : 'mp3');
                const buffer = await downloadToBuffer(viewOnceUnwrapped.audioMessage, 'audio');
                if (buffer) {
                    mediaPath = path.join(TEMP_MEDIA_DIR, `${messageId}_viewonce.${ext}`);
                    await writeFile(mediaPath, buffer);
                    fileSize = buffer.length;
                }
            }
        }
        // Handle REGULAR (non-view-once) messages
        else if (message.message?.conversation) {
            content = message.message.conversation;
        }
        else if (message.message?.extendedTextMessage?.text) {
            content = message.message.extendedTextMessage.text;
        }
        else if (message.message?.imageMessage) {
            mediaType = 'image';
            content = message.message.imageMessage.caption || '';
            mimeType = message.message.imageMessage.mimetype || 'image/jpeg';
            fileSize = message.message.imageMessage.fileLength || 0;
            fileName = message.message.imageMessage.fileName || '';
            const buffer = await downloadToBuffer(message.message.imageMessage, 'image');
            if (buffer) {
                mediaPath = path.join(TEMP_MEDIA_DIR, `${messageId}.jpg`);
                await writeFile(mediaPath, buffer);
                fileSize = buffer.length;
            }
        }
        else if (message.message?.stickerMessage) {
            mediaType = 'sticker';
            mimeType = message.message.stickerMessage.mimetype || 'image/webp';
            fileSize = message.message.stickerMessage.fileLength || 0;
            const buffer = await downloadToBuffer(message.message.stickerMessage, 'sticker');
            if (buffer) {
                mediaPath = path.join(TEMP_MEDIA_DIR, `${messageId}.webp`);
                await writeFile(mediaPath, buffer);
                fileSize = buffer.length;
            }
        }
        else if (message.message?.videoMessage) {
            mediaType = 'video';
            content = message.message.videoMessage.caption || '';
            mimeType = message.message.videoMessage.mimetype || 'video/mp4';
            fileSize = message.message.videoMessage.fileLength || 0;
            fileName = message.message.videoMessage.fileName || '';
            const buffer = await downloadToBuffer(message.message.videoMessage, 'video');
            if (buffer) {
                mediaPath = path.join(TEMP_MEDIA_DIR, `${messageId}.mp4`);
                await writeFile(mediaPath, buffer);
                fileSize = buffer.length;
            }
        }
        else if (message.message?.audioMessage) {
            mediaType = 'audio';
            content = message.message.audioMessage.caption || '';
            mimeType = message.message.audioMessage.mimetype || '';
            fileSize = message.message.audioMessage.fileLength || 0;
            const ext = mimeType.includes('mpeg') ? 'mp3' : (mimeType.includes('ogg') ? 'ogg' : 'mp3');
            const buffer = await downloadToBuffer(message.message.audioMessage, 'audio');
            if (buffer) {
                mediaPath = path.join(TEMP_MEDIA_DIR, `${messageId}.${ext}`);
                await writeFile(mediaPath, buffer);
                fileSize = buffer.length;
            }
        }
        else if (message.message?.documentMessage) {
            mediaType = 'document';
            content = message.message.documentMessage.caption || message.message.documentMessage.fileName || '';
            mimeType = message.message.documentMessage.mimetype || 'application/octet-stream';
            fileSize = message.message.documentMessage.fileLength || 0;
            fileName = message.message.documentMessage.fileName || '';
            const buffer = await downloadToBuffer(message.message.documentMessage, 'document');
            if (buffer) {
                fileName = message.message.documentMessage.fileName || `${messageId}_document`;
                mediaPath = path.join(TEMP_MEDIA_DIR, fileName);
                await writeFile(mediaPath, buffer);
                fileSize = buffer.length;
            }
        }

        // Only store if we have content or media
        if (content || mediaType) {
            messageStore.set(messageId, {
                content,
                mediaType,
                mediaPath,
                sender,
                isViewOnce,
                mimeType,
                fileSize,
                fileName,
                group: message.key.remoteJid.endsWith('@g.us') ? message.key.remoteJid : null,
                timestamp: new Date().toISOString(),
                messageType: getMessageTypeName(message)
            });
        }

    } catch (err) {
        console.error('storeMessage error:', err);
    }
}

// Handle message deletion (FOR EVERYONE)
async function handleMessageRevocation(sock, revocationMessage) {
    try {
        const config = loadAntideleteConfig();
        if (!config.enabled) return;

        // Check if this is a "deleted for everyone" message
        const protocolMsg = revocationMessage.message.protocolMessage;
        if (!protocolMsg || protocolMsg.type !== 0) {
            return; // Not a deletion for everyone
        }

        const messageId = protocolMsg.key.id;
        const deletedBy = revocationMessage.participant || revocationMessage.key.participant || revocationMessage.key.remoteJid;
        const ownerNumber = sock.user.id.split(':')[0] + '@s.whatsapp.net';

        // Avoid self-deletions and duplicates
        if (deletedBy.includes(sock.user.id) || deletedBy === ownerNumber) return;
        if (recentDeletions.has(messageId)) return;
        
        // Add to recent deletions to prevent duplicates
        recentDeletions.add(messageId);
        setTimeout(() => recentDeletions.delete(messageId), DELETION_COOLDOWN);

        const original = messageStore.get(messageId);
        if (!original) return;

        const sender = original.sender;
        const senderName = sender.split('@')[0];
        let groupName = '';
        let groupParticipants = 0;
        
        // Get group name if it's a group message
        if (original.group) {
            try {
                const metadata = await sock.groupMetadata(original.group);
                groupName = metadata.subject;
                groupParticipants = metadata.participants.length;
            } catch (err) {
                console.error('Error getting group metadata:', err);
            }
        }

        const time = new Date().toLocaleString('en-US', {
            timeZone: 'Asia/Karachi',
            hour12: true,
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            day: '2-digit',
            month: '2-digit',
            year: 'numeric'
        });

        // Create detailed report text
        let text = `╔═════════════════════╗\n`;
        text += `║    🚨 *DELETION ALERT* 🚨    ║\n`;
        text += `╚════════════════════╝\n\n`;
        
        text += `📊 *Message Type:* ${original.messageType}\n`;
        if (original.isViewOnce) text += `🔒 *Privacy:* View Once\n`;
        
        text += `\n👤 *Sender Details:*\n`;
        text += `   ├─ Name: @${senderName}\n`;
        text += `   └─ Number: ${sender}\n`;
        
        text += `\n🗑️ *Deleted By:*\n`;
        text += `   ├─ Name: @${deletedBy.split('@')[0]}\n`;
        text += `   └─ Number: ${deletedBy}\n`;
        
        text += `\n🕒 *Timestamps:*\n`;
        text += `   ├─ Sent: ${new Date(original.timestamp).toLocaleString('en-US', {timeZone: 'Asia/Karachi'})}\n`;
        text += `   └─ Deleted: ${time}\n`;
        
        if (original.group) {
            text += `\n👥 *Group Information:*\n`;
            text += `   ├─ Name: ${groupName || 'Unknown'}\n`;
            text += `   ├─ ID: ${original.group}\n`;
            text += `   └─ Members: ${groupParticipants}\n`;
        } else {
            text += `\n💬 *Chat Type:* Private Chat\n`;
        }
        
        if (original.mediaType) {
            text += `\n📁 *Media Details:*\n`;
            text += `   ├─ Type: ${original.mediaType.toUpperCase()}\n`;
            if (original.mimeType) text += `   ├─ Format: ${original.mimeType}\n`;
            if (original.fileSize > 0) text += `   ├─ Size: ${formatFileSize(original.fileSize)}\n`;
            if (original.fileName) text += `   └─ Filename: ${original.fileName}\n`;
        }
        
        if (original.content) {
            text += `\n💬 *Message Content:*\n`;
            text += `\`\`\`\n${original.content}\n\`\`\`\n`;
        }
        
        text += `\n╔═════════════════════╗\n`;
        text += `║   🔰 *ANTIDELETE ACTIVE*   ║\n`;
        text += `╚═════════════════════╝`;

        // Send text report
        await sock.sendMessage(ownerNumber, {
            text,
            mentions: [deletedBy, sender]
        });

        // Send media if exists (for both view-once and regular)
        if (original.mediaType && fs.existsSync(original.mediaPath)) {
            try {
                const mediaOptions = {
                    caption: `🗑️ *Deleted ${original.mediaType.toUpperCase()}*\n\n` +
                            `👤 *From:* @${senderName}\n` +
                            `🗑️ *Deleted by:* @${deletedBy.split('@')[0]}\n` +
                            (original.group ? `👥 *Group:* ${groupName}\n` : '') +
                            (original.content ? `📝 *Caption:* ${original.content}\n` : '') +
                            (original.fileSize > 0 ? `📊 *Size:* ${formatFileSize(original.fileSize)}\n` : '') +
                            `🕒 *Deleted at:* ${time}`,
                    mentions: [sender, deletedBy]
                };

                switch (original.mediaType) {
                    case 'image':
                        await sock.sendMessage(ownerNumber, {
                            image: { url: original.mediaPath },
                            ...mediaOptions
                        });
                        break;
                    case 'sticker':
                        await sock.sendMessage(ownerNumber, {
                            sticker: { url: original.mediaPath },
                            ...mediaOptions
                        });
                        break;
                    case 'video':
                        await sock.sendMessage(ownerNumber, {
                            video: { url: original.mediaPath },
                            ...mediaOptions
                        });
                        break;
                    case 'audio':
                        await sock.sendMessage(ownerNumber, {
                            audio: { url: original.mediaPath },
                            mimetype: 'audio/mpeg',
                            ptt: original.mimeType?.includes('ogg') ? true : false,
                            ...mediaOptions
                        });
                        break;
                    case 'document':
                        await sock.sendMessage(ownerNumber, {
                            document: { url: original.mediaPath },
                            fileName: original.fileName || path.basename(original.mediaPath),
                            mimetype: original.mimeType,
                            ...mediaOptions
                        });
                        break;
                }
                
                console.log(`✅ Sent deleted ${original.mediaType} to owner`);
            } catch (err) {
                console.error('Error sending media:', err);
                await sock.sendMessage(ownerNumber, {
                    text: `⚠️ Error sending ${original.mediaType}: ${err.message}\n\n` +
                          `📄 *File path:* ${original.mediaPath}\n` +
                          `📊 *File size:* ${formatFileSize(original.fileSize)}`
                });
            }

            // Cleanup
            try {
                fs.unlinkSync(original.mediaPath);
                console.log(`🧹 Cleaned up: ${original.mediaPath}`);
            } catch (err) {
                console.error('Media cleanup error:', err);
            }
        }

        // Remove from store
        messageStore.delete(messageId);

    } catch (err) {
        console.error('handleMessageRevocation error:', err);
    }
}

module.exports = {
    handleAntideleteCommand,
    handleMessageRevocation,
    storeMessage
};