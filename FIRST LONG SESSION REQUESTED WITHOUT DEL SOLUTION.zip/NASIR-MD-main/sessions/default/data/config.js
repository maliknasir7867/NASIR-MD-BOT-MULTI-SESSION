module.exports = {
    owner: "923001234567",   // your number option A
    botname: "NASIR-MD BOT"
};
